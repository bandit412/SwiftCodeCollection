//
//  Draw2D.swift
//  Draw2D
//
//  Created by Allan Anderson on 2016-Jan-12.
//  Copyright © 2016 Allan Anderson. All rights reserved.
//

import UIKit

class Draw2D: UIView {

    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    */
    override func drawRect(rect: CGRect) {
        // Drawing code
//        // draw a straight line
//        let context = UIGraphicsGetCurrentContext()
//        CGContextSetLineWidth(context, 2.0)
//        let colorSpace = CGColorSpaceCreateDeviceRGB()
//        let components : [CGFloat] = [0.0,0.0,1.0,1.0]
//        let color = CGColorCreate(colorSpace, components)
//        CGContextSetStrokeColorWithColor(context, color)
//        CGContextMoveToPoint(context, 30, 30)
//        CGContextAddLineToPoint(context, 300, 400)
//        CGContextStrokePath(context)
        // draw a cubic Bezier curve
        let context = UIGraphicsGetCurrentContext()
        CGContextSetLineWidth(context, 4.0)
        CGContextSetStrokeColorWithColor(context, UIColor.blueColor().CGColor)
        CGContextMoveToPoint(context, 10, 10)
        CGContextAddCurveToPoint(context, 0, 50, 300, 250, 300, 400)
        CGContextStrokePath(context)
        // draw a qaudratic bezier curve
        //let context = UIGraphicsGetCurrentContext()
        CGContextSetLineWidth(context, 2.0)
        CGContextSetStrokeColorWithColor(context, UIColor.redColor().CGColor)
        CGContextMoveToPoint(context, 10, 200)
        CGContextAddQuadCurveToPoint(context, 150, 10, 300, 200)
        CGContextStrokePath(context)
    }


}
