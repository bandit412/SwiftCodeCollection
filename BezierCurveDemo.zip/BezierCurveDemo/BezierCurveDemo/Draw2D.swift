//
//  Draw2D.swift
//  BezierCurveDemo
//
//  Created by Allan Anderson on 2016-Mar-08.
//  Copyright © 2016 Allan Anderson. All rights reserved.
//

import UIKit

class Draw2D: UIView {

    override func draw(_ rect: CGRect)
    {
        let p0 = CGPoint(x: 985, y: 459)
        let p1 = CGPoint(x: 726, y: 193)
        let p2 = CGPoint(x: 449, y: 638)
        let context = UIGraphicsGetCurrentContext()
        context!.setLineWidth(3.0)
        context!.setStrokeColor(UIColor.red.cgColor)
        context!.move(to: p0, control1: p1, control2: p2)
        context!.strokePath()
    }
    
//    override func draw(_ rect: CGRect)
//    {
//        let p0 = CGPoint(x: 985, y: 459)
//        let p1 = CGPoint(x: 726, y: 193)
//        let p2 = CGPoint(x: 449, y: 638)
//        let p3 = CGPoint(x: 253, y: 196)
//        let context = UIGraphicsGetCurrentContext()
//        context!.setLineWidth(3.0)
//        context!.setStrokeColor(UIColor.red.cgColor)
//        context!.move(to: p0)
//        //let path: CGPath!
//        //let path = UIBezierPath()
//        var t : Float = 0.0
//        var pointPosition : CGPoint
//        while (t <= 1.0)
//        {
//            pointPosition = cubicBezier(t: t, andP0: p0, andP1: p1, andP2: p2, andP3: p3)
//            context!.move(to: pointPosition)
//            context!.strokePath()
//            context!.addLine(to: pointPosition)
//            t = t + 0.01
//        }
//        
//        
////        path.move(to: CGPoint(x: 985, y: 459))
////        path.addCurveToPoint(CGPoint(x: 253, y: 196), controlPoint1: CGPoint(x: 726, y: 193), controlPoint2: CGPoint(x: 449, y: 638))
////        path.lineWidth = 3.0
////        path.lineJoinStyle = CGLineJoin.Round
//    }
    
    func drawBezier()-> UIBezierPath
    {
        let path = UIBezierPath()
        path.move(to: CGPoint(x: 985, y: 459))
        path.addCurve(to: CGPoint(x: 253, y: 196), controlPoint1: CGPoint(x: 726, y: 193), controlPoint2: CGPoint(x: 449, y: 638))
        path.lineWidth = 4.0
        path.lineJoinStyle = CGLineJoin.round
        path.lineCapStyle = CGLineCap.round
        return path
    }
    
    func cubicBezier(t: Float, andP0 p0 : CGPoint, andP1 p1:CGPoint, andP2 p2:CGPoint, andP3 p3:CGPoint)->CGPoint
    {
        let ts = 1 - t
        let ts2 = ts * ts
        let ts3 = ts2 * ts
        let t2 = t * t
        let t3 = t2 * t
        let x = Float(p0.x) * ts3 + 3.0 * t * Float(p1.x) * ts2 + 3.0 * Float(p2.x) * t2 * ts + Float(p3.x) * t3
        let y = Float(p0.y) * ts3 + 3.0 * t * Float(p1.y) * ts2 + 3.0 * Float(p2.y) * t2 * ts + Float(p3.y) * t3
        return CGPoint(x: CGFloat(x), y: CGFloat(y))
    }

}
