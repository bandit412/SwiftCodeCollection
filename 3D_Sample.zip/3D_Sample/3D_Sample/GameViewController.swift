//
//  GameViewController.swift
//  3D_Sample
//
//  Created by Allan Anderson on 2015-Mar-06.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import UIKit
import QuartzCore
import SceneKit

class GameViewController: UIViewController {

    @IBOutlet var sceneView: SCNView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // create a new scene
        let scene = SCNScene(named: "art.scnassets/F18Jet.dae")!
        
        
        // create and add a camera to the scene
        let cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        scene.rootNode.addChildNode(cameraNode)
        
        // place the camera
        cameraNode.position = SCNVector3(x: 0, y: 5, z: 25)
        
        // create and add a light to the scene
        let lightNode = SCNNode()
        lightNode.light = SCNLight()
        lightNode.light!.type = SCNLightTypeOmni
        lightNode.light!.color = UIColor(white: 0.8, alpha: 1.0)
        lightNode.position = SCNVector3(x: 0, y: 10, z: 50)
        scene.rootNode.addChildNode(lightNode)
        
        // create and add an ambient light to the scene
        let ambientLightNode = SCNNode()
        ambientLightNode.light = SCNLight()
        ambientLightNode.light!.type = SCNLightTypeAmbient
        ambientLightNode.light!.color = UIColor(white: 0.75, alpha: 1.0)
        scene.rootNode.addChildNode(ambientLightNode)
        
        // retrieve the ship node
        //let suvNode = createSUVNode(scene)
        let jetNode = createJetNode(scene)
        
        //suvNode.position = SCNVector3Make(-1, 1, -1)
        //scene.rootNode.addChildNode(suvNode)
        //let suv = scene.rootNode.childNodeWithName("SUV", recursively: true)!
        scene.rootNode.addChildNode(jetNode)

        // animate the 3d object
        //suvNode.runAction(SCNAction.repeatActionForever(SCNAction.rotateByX(0, y: 1, z: 0, duration: 1)))
        //jetNode.runAction(SCNAction.repeatActionForever(SCNAction.rotateByX(0, y: 1, z: 0, duration: 1)))

        // retrieve the SCNView
        let scnView = self.view as SCNView
        
        // set the scene to the view
        scnView.scene = scene
        
        // allows the user to manipulate the camera
        scnView.allowsCameraControl = true
        
        // show statistics such as fps and timing information
        scnView.showsStatistics = true
        
        // configure the view
        scnView.backgroundColor = UIColor(red: 135, green: 206, blue: 250, alpha: 0.8)
        
        // add a tap gesture recognizer
        let tapGesture = UITapGestureRecognizer(target: self, action: "handleTap:")
        let gestureRecognizers = NSMutableArray()
        gestureRecognizers.addObject(tapGesture)
        if let existingGestureRecognizers = scnView.gestureRecognizers {
            gestureRecognizers.addObjectsFromArray(existingGestureRecognizers)
        }
        scnView.gestureRecognizers = gestureRecognizers
    }
    
    func handleTap(gestureRecognize: UIGestureRecognizer) {
        // retrieve the SCNView
        let scnView = self.view as SCNView
        
        // check what nodes are tapped
        let p = gestureRecognize.locationInView(scnView)
        if let hitResults = scnView.hitTest(p, options: nil) {
            // check that we clicked on at least one object
            if hitResults.count > 0 {
                // retrieved the first clicked object
                let result: AnyObject! = hitResults[0]
                
                // get its material
                let material = result.node!.geometry!.firstMaterial!
                
                // highlight it
                SCNTransaction.begin()
                SCNTransaction.setAnimationDuration(0.5)
                
                // on completion - unhighlight
                SCNTransaction.setCompletionBlock {
                    SCNTransaction.begin()
                    SCNTransaction.setAnimationDuration(0.5)
                    
                    material.emission.contents = UIColor.blackColor()
                    
                    SCNTransaction.commit()
                }
                
                material.emission.contents = UIColor.redColor()
                
                SCNTransaction.commit()
            }
        }
    }
    
    override func shouldAutorotate() -> Bool {
        return true
    }
    
    override func prefersStatusBarHidden() -> Bool {
        return true
    }
    
    override func supportedInterfaceOrientations() -> Int {
        if UIDevice.currentDevice().userInterfaceIdiom == .Phone {
            return Int(UIInterfaceOrientationMask.AllButUpsideDown.rawValue)
        } else {
            return Int(UIInterfaceOrientationMask.All.rawValue)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Release any cached data, images, etc that aren't in use.
    }

//    func createSUVNode(scene: SCNScene)->SCNNode{
//        let suvNode = SCNNode()
//        suvNode.name = "SUV"
//        let bodyNode: SCNNode = scene.rootNode.childNodeWithName("pCube1", recursively: true)!
//        let pCube2: SCNNode = scene.rootNode.childNodeWithName("pCube2", recursively: true)!
//        let pCube3 : SCNNode = scene.rootNode.childNodeWithName("pCube3", recursively: true)!
//        let wheel1Node: SCNNode = scene.rootNode.childNodeWithName("Wheel1", recursively: true)!
//        let wheel2Node: SCNNode = scene.rootNode.childNodeWithName("Wheel2", recursively: true)!
//        let wheel3Node: SCNNode = scene.rootNode.childNodeWithName("Wheel3", recursively: true)!
//        let wheel4Node: SCNNode = scene.rootNode.childNodeWithName("Wheel4", recursively: true)!
//        let wheel5Node: SCNNode = scene.rootNode.childNodeWithName("Wheel5", recursively: true)!
//        let fog1: SCNNode = scene.rootNode.childNodeWithName("FogLight1", recursively: true)!
//        let fog2: SCNNode = scene.rootNode.childNodeWithName("FogLight2", recursively: true)!
//        let pPlane1 :SCNNode = scene.rootNode.childNodeWithName("pPlane1", recursively: true)!
//        suvNode.addChildNode(bodyNode)
//        suvNode.addChildNode(pCube2)
//        suvNode.addChildNode(pCube3)
//        suvNode.addChildNode(wheel1Node)
//        suvNode.addChildNode(wheel2Node)
//        suvNode.addChildNode(wheel3Node)
//        suvNode.addChildNode(wheel4Node)
//        suvNode.addChildNode(wheel5Node)
//        suvNode.addChildNode(fog1)
//        suvNode.addChildNode(fog2)
//        suvNode.addChildNode(pPlane1)
//        return suvNode
//    }
    
    func createJetNode(scene: SCNScene)->SCNNode{
        let f18Node = SCNNode()
        f18Node.name = "F18"
        //let pilotNode: SCNNode = scene.rootNode.childNodeWithName("Pilot", recursively: true)!
        let ambientLightNode: SCNNode = scene.rootNode.childNodeWithName("ambientLight1", recursively: true)!
        let jet18Node: SCNNode = scene.rootNode.childNodeWithName("Jet01", recursively: true)!
        let missilesNode: SCNNode = scene.rootNode.childNodeWithName("Missiles1", recursively: true)!
        let canopyNode: SCNNode = scene.rootNode.childNodeWithName("Canopy01", recursively: true)!
        //f18Node.addChildNode(pilotNode)
        f18Node.addChildNode(ambientLightNode)
        f18Node.addChildNode(jet18Node)
        f18Node.addChildNode(missilesNode)
        f18Node.addChildNode(canopyNode)
        return f18Node
    }
}
