//
//  GameScene.swift
//  CollisionDemo
//
//  Created by Allan Anderson on 2015-Feb-24.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import SpriteKit

// struct to identify collisions
struct CollisionCategory{
    static let Ball : UInt32 = 1
    static let Wall : UInt32 = 1 << 1
    static let Block : UInt32 = 1 << 2 // 4
}

// global properties
private let numberOfBalls = 5

class GameScene: SKScene, SKPhysicsContactDelegate {
    
    private var gameBalls = [Ball]()
    private var velocityLabels = [SKLabelNode]()
    private var ballLabels = [SKLabelNode]()
    private var masslabels = [SKLabelNode]()
    
    override func didMove(to view: SKView) {
        /* Setup your scene here */
        self.backgroundColor = SKColor.white
        let velocity = self.size.width / self.size.height * 3.0
        // configure the physics world
        self.physicsWorld.gravity = CGVector(dx: 0.0, dy: 0.0)
        self.physicsWorld.contactDelegate = self
        // create the border (Wall)
        self.physicsBody = SKPhysicsBody(edgeLoopFrom: self.frame)
        self.physicsBody?.friction = 0.0
        self.physicsBody?.categoryBitMask = CollisionCategory.Wall
        self.physicsBody?.contactTestBitMask = CollisionCategory.Ball
        
        // create and attach balls
        let ball_x_Separation = CGFloat(5.0)
        var ballX = size.width / 4 + CGFloat(arc4random_uniform(UInt32(ball_x_Separation)))
        var ballY = size.height / 4 + CGFloat(arc4random_uniform(UInt32(ball_x_Separation)))
        for _ in 1 ... numberOfBalls{
            let ball = Ball(sceneSize: self.frame.size)
            ball.position =  CGPoint(x: ballX, y: ballY)
            ballX = ball.position.x + ball.size.width
            ballY = ball.position.y + ball.size.height
            self.addChild(ball)
            ball.startMoving(velocity: velocity)
            gameBalls.append(ball)
        }
        
        // create labels
        createLabels(numberOfBalls: numberOfBalls)
        for i in 0...gameBalls.count - 1{
            let mass = Double(round(gameBalls[i].physicsBody!.mass * 1000) / 1000)
            let mString = String(format: "%.02f kg", mass)
            masslabels[i].text = mString
        }
    }
    
    func touchesBegan(touches: NSSet, withEvent event: UIEvent) {
        /* Called when a touch begins */
        for touch in touches.allObjects as! [UITouch]{
            _ = touch.location(in: self)
        }
    }

    override func update(_ currentTime: CFTimeInterval) {
        let max = gameBalls.count
        for i in 0...max - 1{
            let vX = Double(round(gameBalls[i].physicsBody!.velocity.dx * 1000) / 1000)
            let vY = Double(round(gameBalls[i].physicsBody!.velocity.dy * 1000) / 1000)
            let vString = String(format: "[ %.04f   %.04f ] m/s", vX, vY)
            velocityLabels[i].text = vString
            ballLabels[i].position = gameBalls[i].position
        }
    }
    
    // MARK: - CreateLabels
    func createLabels(numberOfBalls: Int){
        // constants related to displaying text
        let edgeDistance = CGFloat(20.0)
        let labelSpacing = CGFloat(5.0)
        let fontSize = CGFloat(22.0)
        let statFontSize = CGFloat(18.0)
        let alpha = CGFloat(0.5)
        var xP0 = CGFloat(0.0)
        var xP1 = CGFloat(0.0)
        var yP0 = CGFloat(0.0)
        var yP1 = CGFloat(0.0)
        let cornerColor = SKColor.lightGray
        let blockLabelColor = SKColor.black
        let shapeHeight = edgeDistance * 2 + (fontSize + labelSpacing) * CGFloat(numberOfBalls)
        
        // configure the stats background
        var statsBlockPoints = [CGPoint]()
        statsBlockPoints.append(CGPoint(x: 0.0, y: self.size.height - shapeHeight))
        statsBlockPoints.append(CGPoint(x: self.size.width, y: self.size.height - shapeHeight))
        statsBlockPoints.append(CGPoint(x: self.size.width, y: self.size.height))
        statsBlockPoints.append(CGPoint(x: 0.0, y: self.size.height))
        let statsPath = CGMutablePath()
        statsPath.move(to: (CGPoint(x:0.0, y:self.size.height)))
        for p in statsBlockPoints{
            //CGPathAddLineToPoint(statsPath, nil, p.x, p.y)
            statsPath.addLine(to: CGPoint(x:p.x, y:p.y))
        }
        statsPath.closeSubpath()
        let statsBlock = SKShapeNode(path: statsPath)
        statsBlock.fillColor = SKColor.clear
        statsBlock.strokeColor = SKColor.clear
        /* this code is not necessary unless you want the stats block to be a physics body
        
        statsBlock.physicsBody = SKPhysicsBody(rectangleOfSize: CGSizeMake(self.size.width / 2, shapeHeight))
        statsBlock.physicsBody?.restitution = 1.0
        statsBlock.physicsBody?.friction = 0.0
        statsBlock.physicsBody?.linearDamping = 0.0
        statsBlock.physicsBody?.dynamic = false
        statsBlock.physicsBody?.usesPreciseCollisionDetection = true
        statsBlock.physicsBody?.categoryBitMask = CollisionCategory.Block
        statsBlock.physicsBody?.contactTestBitMask = CollisionCategory.Ball
        
        */
        self.addChild(statsBlock)
        
        // add lower left triangle block
        var lowerLeftTrianglePoints = [CGPoint]()
        //trianglePoints.append(CGPoint(x: 0.0, y: 0.0))
        lowerLeftTrianglePoints.append(CGPoint(x: 0.0, y: self.size.width / 8))
        lowerLeftTrianglePoints.append(CGPoint(x: self.size.width / 3, y: 0.0))
        lowerLeftTrianglePoints.append(CGPoint(x: 0.0, y: 0.0))
        let llPath = CGMutablePath()
        llPath.move(to: CGPoint(x:0.0, y:0.0))
        for p in lowerLeftTrianglePoints{
            //CGPathAddLineToPoint(llPath, nil, p.x, p.y)
            llPath.addLine(to: CGPoint(x:p.x, y:p.y))
        }
        llPath.closeSubpath()
        let lowerLeftBlock = SKShapeNode(path: llPath)
        lowerLeftBlock.fillColor = cornerColor
        lowerLeftBlock.strokeColor = cornerColor
        lowerLeftBlock.alpha = alpha
        lowerLeftBlock.physicsBody = SKPhysicsBody(polygonFrom: llPath)
        lowerLeftBlock.physicsBody?.restitution = 1.0
        lowerLeftBlock.physicsBody?.friction = 0.0
        lowerLeftBlock.physicsBody?.linearDamping = 0.0
        lowerLeftBlock.physicsBody?.isDynamic = false
        lowerLeftBlock.physicsBody?.usesPreciseCollisionDetection = true
        lowerLeftBlock.physicsBody?.categoryBitMask = CollisionCategory.Block
        lowerLeftBlock.physicsBody?.contactTestBitMask = CollisionCategory.Ball
        self.addChild(lowerLeftBlock)
        
        // add lower right triangle block
        var lowerRightTrianglePoints = [CGPoint]()
        lowerRightTrianglePoints.append(CGPoint(x: self.size.width - self.size.width / 3, y: 0.0))
        lowerRightTrianglePoints.append(CGPoint(x: self.size.width, y: self.size.height / 9))
        lowerRightTrianglePoints.append(CGPoint(x: self.size.width, y: 0.0))
        let lrPath = CGMutablePath()
        lrPath.move(to: CGPoint(x:self.size.width, y: 0.0))
        for p in lowerRightTrianglePoints{
            //CGPathAddLineToPoint(lrPath, nil, p.x, p.y)
            lrPath.addLine(to: CGPoint(x:p.x, y:p.y))
        }
        lrPath.closeSubpath()
        let lowerRightBlock = SKShapeNode(path: lrPath)
        lowerRightBlock.fillColor = cornerColor
        lowerRightBlock.strokeColor = cornerColor
        lowerRightBlock.alpha = alpha
        lowerRightBlock.physicsBody = SKPhysicsBody(polygonFrom: lrPath)
        lowerRightBlock.physicsBody?.restitution = 1.0
        lowerRightBlock.physicsBody?.friction = 0.0
        lowerRightBlock.physicsBody?.linearDamping = 0.0
        lowerRightBlock.physicsBody?.isDynamic = false
        lowerRightBlock.physicsBody?.usesPreciseCollisionDetection = true
        lowerRightBlock.physicsBody?.categoryBitMask = CollisionCategory.Block
        lowerRightBlock.physicsBody?.contactTestBitMask = CollisionCategory.Ball
        self.addChild(lowerRightBlock)
        
        // add upper right corner block
        var upperRightTranglePoints = [CGPoint]()
        upperRightTranglePoints.append(CGPoint(x: self.size.width - self.size.width / 10, y: self.size.height))
        upperRightTranglePoints.append(CGPoint(x: self.size.width, y:  self.size.height - self.size.height / 10))
        upperRightTranglePoints.append(CGPoint(x: self.size.width, y: self.size.height))
        let urPath = CGMutablePath()
        urPath.move(to: CGPoint(x:self.size.width, y: self.size.height))
        for p in upperRightTranglePoints{
            //CGPathAddLineToPoint(urPath, nil, p.x, p.y)
            urPath.addLine(to: CGPoint(x:p.x, y: p.y))
        }
        urPath.closeSubpath()
        let upperRightCorner = SKShapeNode(path: urPath)
        upperRightCorner.fillColor = cornerColor
        upperRightCorner.strokeColor = cornerColor
        upperRightCorner.alpha = alpha
        upperRightCorner.physicsBody = SKPhysicsBody(polygonFrom: urPath)
        upperRightCorner.physicsBody?.restitution = 1.0
        upperRightCorner.physicsBody?.friction = 0.0
        upperRightCorner.physicsBody?.linearDamping = 0.0
        upperRightCorner.physicsBody?.isDynamic = false
        upperRightCorner.physicsBody?.usesPreciseCollisionDetection = true
        upperRightCorner.physicsBody?.categoryBitMask = CollisionCategory.Block
        upperRightCorner.physicsBody?.contactTestBitMask = CollisionCategory.Ball
        self.addChild(upperRightCorner)
        
        // add upper left arc
        var upplerLeftTrianglePoints = [CGPoint]()
        upplerLeftTrianglePoints.append(CGPoint(x: 0.0, y: self.size.height - self.size.height / 8))
        upplerLeftTrianglePoints.append(CGPoint(x: self.size.width / 8, y: self.size.height))
        upplerLeftTrianglePoints.append(CGPoint(x: 0.0, y: self.size.height))
        let arcPath = CGMutablePath()
        arcPath.move(to: CGPoint(x:0.0, y:self.size.height))
        for p in upplerLeftTrianglePoints{
            //CGPathAddLineToPoint(arcPath, nil, p.x, p.y)
            arcPath.addLine(to: CGPoint(x:p.x, y:p.y))
        }
        arcPath.closeSubpath()
        let upperleftBlock = SKShapeNode(path: arcPath)
        upperleftBlock.fillColor = cornerColor
        upperleftBlock.strokeColor = cornerColor
        upperleftBlock.alpha = alpha
        upperleftBlock.physicsBody = SKPhysicsBody(polygonFrom: arcPath)
        upperleftBlock.physicsBody?.restitution = 1.0
        upperleftBlock.physicsBody?.friction = 0.0
        upperleftBlock.physicsBody?.linearDamping = 0.0
        upperleftBlock.physicsBody?.isDynamic = false
        upperleftBlock.physicsBody?.usesPreciseCollisionDetection = true
        upperleftBlock.physicsBody?.categoryBitMask = CollisionCategory.Block
        upperleftBlock.physicsBody?.contactTestBitMask = CollisionCategory.Ball
        self.addChild(upperleftBlock)
        
        // configure the info label
        let infoLabel = SKLabelNode(fontNamed: "Chalkduster")
        infoLabel.text = "Ball Collision Demo"
        infoLabel.fontSize = fontSize
        infoLabel.fontColor = SKColor.blue
        infoLabel.horizontalAlignmentMode = .left
        let y = self.frame.height - infoLabel.fontSize - edgeDistance
        infoLabel.position = CGPoint(x: edgeDistance, y: y)
        self.addChild(infoLabel)
        
        // loop through the count of how many balls are to be displayed
        for i in 1...numberOfBalls{
            // labels for the balls
            let ballLabel = SKLabelNode(fontNamed: "Courier")
            ballLabel.text = String(format: "Ball %d: ", i)
            ballLabel.fontSize = statFontSize
            ballLabel.fontColor = SKColor.black
            ballLabel.horizontalAlignmentMode = .left
            ballLabel.position = CGPoint(x:infoLabel.position.x, y: infoLabel.position.y - edgeDistance * CGFloat(i))
            self.addChild(ballLabel)
            // labels for the mass of each ball
            let massLabel = SKLabelNode(fontNamed: "Courier")
            massLabel.fontColor = SKColor.brown
            massLabel.fontSize = statFontSize
            massLabel.text = "0.0 kg"
            massLabel.horizontalAlignmentMode = .left
            massLabel.position = CGPoint(x:ballLabel.calculateAccumulatedFrame().width + edgeDistance + labelSpacing, y:ballLabel.position.y)
            masslabels.append(massLabel)
            self.addChild(massLabel)
            // labels for the velocity of each ball
            let velocityLabel = SKLabelNode(fontNamed: "Courier")
            velocityLabel.text = "[ 0.0   0.0 ] m/s"
            velocityLabel.fontSize = statFontSize
            velocityLabel.fontColor = SKColor.purple
            
            velocityLabel.horizontalAlignmentMode = .left
            velocityLabel.position = CGPoint(x:massLabel.calculateAccumulatedFrame().maxX + edgeDistance + labelSpacing, y:ballLabel.position.y)
            velocityLabels.append(velocityLabel)
            self.addChild(velocityLabel)
            // labels for the ID of each ball
            let ballIDLabel = SKLabelNode(fontNamed: "Arial")
            ballIDLabel.fontColor = SKColor.white
            ballIDLabel.text = String(format: "%d", i)
            ballIDLabel.fontSize = CGFloat(32.0)
            ballIDLabel.position = CGPoint(x:0, y:0)
            ballLabels.append(ballIDLabel)
            self.addChild(ballIDLabel)
        }
        
        // label for lower left block
        let llBlocklabel = SKLabelNode(fontNamed: "Courier")
        xP0 = CGFloat(round(lowerLeftTrianglePoints[0].x * 1000) / 1000)
        yP0 = CGFloat(round(lowerLeftTrianglePoints[0].y * 1000) / 1000)
        xP1 = CGFloat(round(lowerLeftTrianglePoints[1].x * 1000) / 1000)
        yP1 = CGFloat(round(lowerLeftTrianglePoints[1].y * 1000) / 1000)
        llBlocklabel.text = "LL Block: (\(xP0), \(yP0))to (\(xP1), \(yP1))"
        llBlocklabel.fontSize = statFontSize
        llBlocklabel.fontColor = blockLabelColor
        llBlocklabel.horizontalAlignmentMode = .left
        llBlocklabel.position = CGPoint(x: self.size.width / 2 + edgeDistance, y: infoLabel.position.y - edgeDistance)
        self.addChild(llBlocklabel)
        
        // label for lower right block
        let lrBlocklabel = SKLabelNode(fontNamed: "Courier")
        xP0 = CGFloat(round(lowerRightTrianglePoints[0].x * 1000) / 1000)
        yP0 = CGFloat(round(lowerRightTrianglePoints[0].y * 1000) / 1000)
        xP1 = CGFloat(round(lowerRightTrianglePoints[1].x * 1000) / 1000)
        yP1 = CGFloat(round(lowerRightTrianglePoints[1].y * 1000) / 1000)
        lrBlocklabel.text = "LR Block: (\(xP0), \(yP0)) to (\(xP1), \(yP1))"
        lrBlocklabel.fontSize = statFontSize
        lrBlocklabel.fontColor = blockLabelColor
        lrBlocklabel.horizontalAlignmentMode = .left
        lrBlocklabel.position = CGPoint(x:self.size.width / 2 + edgeDistance, y:llBlocklabel.position.y - edgeDistance)
        self.addChild(lrBlocklabel)
        
        // label for upper left block
        let ulBlocklabel = SKLabelNode(fontNamed: "Courier")
        xP0 = CGFloat(round(upplerLeftTrianglePoints[0].x * 1000) / 1000)
        yP0 = CGFloat(round(upplerLeftTrianglePoints[0].y * 1000) / 1000)
        xP1 = CGFloat(round(upplerLeftTrianglePoints[1].x * 1000) / 1000)
        yP1 = CGFloat(round(upplerLeftTrianglePoints[1].y * 1000) / 1000)
        ulBlocklabel.text = "UL Block: (\(xP0), \(yP0)) to (\(xP1), \(yP1))"
        ulBlocklabel.fontSize = statFontSize
        ulBlocklabel.fontColor = blockLabelColor
        ulBlocklabel.horizontalAlignmentMode = .left
        ulBlocklabel.position = CGPoint(x:self.size.width / 2 + edgeDistance, y:lrBlocklabel.position.y - edgeDistance)
        self.addChild(ulBlocklabel)
        
        // label for upper right block
        let urBlocklabel = SKLabelNode(fontNamed: "Courier")
        xP0 = CGFloat(round(upperRightTranglePoints[0].x * 1000) / 1000)
        yP0 = CGFloat(round(upperRightTranglePoints[0].y * 1000) / 1000)
        xP1 = CGFloat(round(upperRightTranglePoints[1].x * 1000) / 1000)
        yP1 = CGFloat(round(upperRightTranglePoints[1].y * 1000) / 1000)
        urBlocklabel.text = "UR Block: (\(xP0), \(yP0)) to (\(xP1), \(yP1))"
        urBlocklabel.fontSize = statFontSize
        urBlocklabel.fontColor = blockLabelColor
        urBlocklabel.horizontalAlignmentMode = .left
        urBlocklabel.position = CGPoint(x:self.size.width / 2 + edgeDistance, y:ulBlocklabel.position.y - edgeDistance)
        self.addChild(urBlocklabel)
    }
    
    // MARK: - Test type of contact
    func isBall(body: SKPhysicsBody) -> Bool{
        return body.categoryBitMask & CollisionCategory.Ball != 0
    }
    
    func isWall(body: SKPhysicsBody) -> Bool{
        return body.categoryBitMask & CollisionCategory.Wall != 0
    }
    
    func isBlock(body: SKPhysicsBody) -> Bool{
        return body.categoryBitMask & CollisionCategory.Block != 0
    }
    
    // MARK: - Physics Contact Delegate Methods
    func didBeginContact(contact: SKPhysicsContact) {
        var ball: SKPhysicsBody
        var otherBody : SKPhysicsBody
        if isBall(body: contact.bodyA){
            ball = contact.bodyA
            otherBody = contact.bodyB
        } else {
            ball = contact.bodyB
            otherBody = contact.bodyA
        }
        if isBall(body: otherBody){
            /*
            // This code is unnecessary as the Physics Engine already does these calculations
            let lhsX = ball.mass * ball.velocity.dx + otherBody.mass * otherBody.velocity.dx
            let lhsY = ball.mass * ball.velocity.dy + otherBody.mass * otherBody.velocity.dy
            
            let deltaVX = (ball.velocity.dx - otherBody.velocity.dx)
            let deltaVY = (ball.velocity.dy - otherBody.velocity.dy)
            
            let sumMass = ball.mass + otherBody.mass
            
            otherBody.velocity.dx = (lhsX - ball.mass * deltaVX) / sumMass
            otherBody.velocity.dy = (lhsY - ball.mass * deltaVY) / sumMass
            
            ball.velocity.dx = deltaVX + otherBody.velocity.dx
            ball.velocity.dy = deltaVY + otherBody.velocity.dy
            
            //ballTwo.playHitSound()
            */
            bounceSound.play()
        } else {
            wallSound.play()
        }
        
        if isBlock(body: otherBody){
            wallSound.play()
        }
    }
}
