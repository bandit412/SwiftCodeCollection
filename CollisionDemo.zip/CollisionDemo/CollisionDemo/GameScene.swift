//
//  GameScene.swift
//  CollisionDemo
//
//  Created by Allan Anderson on 2015-Dec-15.
//  Copyright © 2015 Allan Anderson. All rights reserved.
//

import SpriteKit

// struct to identify collisions
struct CollisionCategory{
    static let Ball : UInt32 = 1
    static let Wall : UInt32 = 1 << 1
    static let Block : UInt32 = 1 << 2 // 4
}

// global properties
private let numberOfBalls = 6

class GameScene: SKScene { //, SKPhysicsContactDelegate {
    private var gameBalls = [Ball]()
    private var obstacles = [SKShapeNode]()
    
    
    override func didMoveToView(view: SKView) {
        /* Setup your scene here */
        self.backgroundColor = SKColor.whiteColor()
        let velocity = (self.size.width / self.size.height) * 3.0
        // configure the physics world
        self.physicsWorld.gravity = CGVectorMake(0.0, 0.0)
        //self.physicsWorld.contactDelegate = self
        // create the border (Wall)
        self.physicsBody = SKPhysicsBody(edgeLoopFromRect: self.frame)
        self.physicsBody?.friction = 0.0
        self.physicsBody?.categoryBitMask = CollisionCategory.Wall
        self.physicsBody?.contactTestBitMask = CollisionCategory.Ball
        let ball_x_Separation = CGFloat(2.5)
        var ballX = size.width / 8 + CGFloat(arc4random_uniform(UInt32(ball_x_Separation)))
        var ballY = size.height / 6 + CGFloat(arc4random_uniform(UInt32(ball_x_Separation)))
        for id in 1 ... numberOfBalls{
            let ball = Ball(sceneSize: self.frame.size)
            ball.position = CGPointMake(ballX, ballY)
            ballX = ball.position.x + ball.size.width
            ballY = ball.position.y + ball.size.height
            createBallLabel(ball, ballID:id)
            self.addChild(ball)
            if id == 1 || id == numberOfBalls {
                ball.startMoving(velocity)
            }
            gameBalls.append(ball)
        }
        createObsatacles()
        for obstacle in obstacles{
            self.addChild(obstacle)
        }
    }
    
    func createBallLabel(aBall: Ball, ballID: Int){
        let ballLabel = SKLabelNode(fontNamed: "Arial")
        ballLabel.fontColor = SKColor.yellowColor()
        ballLabel.fontSize = CGFloat(30.0)
        ballLabel.text = String(format: "%d",ballID)
        ballLabel.position = CGPointMake(0, 0)
        aBall.addChild(ballLabel)
    }
    
    override func update(currentTime: CFTimeInterval) {
        let max = gameBalls.count
        var pX = 0.0
        var pY = 0.0
        var ke = 0.0
        for (var i = 0; i < max; i++){
            let vX = Double(gameBalls[i].physicsBody!.velocity.dx)
            let vY = Double(gameBalls[i].physicsBody!.velocity.dy)
            let mass = Double(gameBalls[i].physicsBody!.mass)
            pX += vX * mass
            pY += vY * mass
            ke += 0.5 * mass * sqrt(vX * vX + vY * vY)
            //let vString = String(format: "[ %.04f   %.04f ] m/s", vX, vY)
            //velocityLabels[i].text = vString
            //ballLabels[i].position = gameBalls[i].position
        }
        //totalMomentumLabel.text = String(format: "P = [ %.04f   %.04f ] kg m/s", pX, pY)
        //totalKELabel.text = String(format: "E = %.04f J", ke)
    }
    
    func createObsatacles(){
        let obstacleColor = SKColor.lightGrayColor()
        let alpha = CGFloat(0.5)
        let width = scene?.frame.size.width
        let height = scene?.frame.size.height
        let xValue = width! / 8
        let yValue = xValue * CGFloat(tan(M_PI / 6))
        var blPoints = [CGPoint]()
        var bRPoints = [CGPoint]()
        var tlPoints = [CGPoint]()
        var trPoints = [CGPoint]()
        var paths = [CGPathRef]()
        
        // bottom left triangle
        blPoints.append(CGPoint(x: 0, y: 0))
        blPoints.append(CGPoint(x: xValue , y: 0.0))
        blPoints.append(CGPoint(x: 0 / 3, y: yValue))
        let blPath = CGPathCreateMutable()
        CGPathMoveToPoint(blPath, nil, blPoints[0].x, blPoints[0].y)
        for p in blPoints {
            CGPathAddLineToPoint(blPath, nil, p.x, p.y)
        }
        CGPathCloseSubpath(blPath)
        var obstacle = SKShapeNode(path: blPath)
        obstacles.append(obstacle)
        paths.append(blPath)
        
        // bottom right triangle
        bRPoints.append(CGPoint(x: width!, y: 0))
        bRPoints.append(CGPoint(x: width! - xValue, y: 0))
        bRPoints.append(CGPoint(x: width!, y: yValue))
        let brPath = CGPathCreateMutable()
        CGPathMoveToPoint(brPath, nil, bRPoints[0].x, bRPoints[0].y)
        for p in bRPoints {
            CGPathAddLineToPoint(brPath, nil, p.x, p.y)
        }
        CGPathCloseSubpath(brPath)
        obstacle = SKShapeNode(path: brPath)
        obstacles.append(obstacle)
        paths.append(brPath)
        
        // top left triangle
        tlPoints.append(CGPoint(x: 0, y: height!))
        tlPoints.append(CGPoint(x: xValue, y: height!))
        tlPoints.append(CGPoint(x: 0, y: height! - yValue))
        let tlPath = CGPathCreateMutable()
        CGPathMoveToPoint(tlPath, nil, tlPoints[0].x, tlPoints[0].y)
        for p in tlPoints {
            CGPathAddLineToPoint(tlPath, nil, p.x, p.y)
        }
        CGPathCloseSubpath(tlPath)
        obstacle = SKShapeNode(path: tlPath)
        obstacles.append(obstacle)
        paths.append(tlPath)
        
        // top right triangle
        trPoints.append(CGPoint(x: width!, y: height!))
        trPoints.append(CGPoint(x: width! - xValue, y: height!))
        trPoints.append(CGPoint(x: width!, y: height! - yValue))
        let trPath = CGPathCreateMutable()
        CGPathMoveToPoint(trPath, nil, trPoints[0].x, trPoints[0].y)
        for p in trPoints {
            CGPathAddLineToPoint(trPath, nil, p.x, p.y)
        }
        CGPathCloseSubpath(trPath)
        obstacle = SKShapeNode(path: trPath)
        obstacles.append(obstacle)
        paths.append(trPath)
        
        // set obstacle properties
        for p in 0 ... obstacles.count - 1{
            obstacles[p].fillColor = obstacleColor
            obstacles[p].strokeColor = obstacleColor
            obstacles[p].alpha = alpha
//            obstacles[p].physicsBody = SKPhysicsBody(polygonFromPath: paths[p])
//            obstacles[p].physicsBody?.restitution = 1.0
//            obstacles[p].physicsBody?.friction = 0.0
//            obstacles[p].physicsBody?.linearDamping = 0.0
//            obstacles[p].physicsBody?.angularDamping = 0.0
//            obstacles[p].physicsBody?.dynamic = false
//            obstacles[p].physicsBody?.mass = CGFloat(Double.infinity)
//            obstacles[p].physicsBody?.usesPreciseCollisionDetection = true
//            obstacles[p].physicsBody?.categoryBitMask = CollisionCategory.Block
//            obstacles[p].physicsBody?.contactTestBitMask = CollisionCategory.Ball
        }
    }
    
    
}
