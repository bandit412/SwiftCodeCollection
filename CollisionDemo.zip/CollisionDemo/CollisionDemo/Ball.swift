//
//  Ball.swift
//  CollisionDemo
//
//  Created by Allan Anderson on 2015-Feb-24.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import SpriteKit
import AVFoundation

// enums
enum BallSize: CGFloat{
    case Small = 1.0
    case Medium = 1.5
    case Large = 2.0
}

enum BallColor: String{
    case Red = "RedBall"
    case Blue = "BlueBall"
}

// global properties
private let ballColors = [BallColor.Red, BallColor.Blue]
private let ballSizes = [BallSize.Small, BallSize.Medium, BallSize.Large]
private let minV = -15
private let maxV: UInt32 = 15
private let massSeed: UInt32 = 5

class Ball: SKSpriteNode {
    // constants
    private let ballVelocity = CGVector(dx: 0.0, dy: 0.0)
    private let ballSizePercentage = CGFloat(0.1)
    private let ballSize : BallSize
    private let ballColor : BallColor

    init(sceneSize: CGSize){
        ballSize = ballSizes[Int(arc4random_uniform(UInt32(ballSizes.count)))]
        let mass = CGFloat(arc4random_uniform(massSeed)) * ballSize.rawValue + ballSize.rawValue / 2.0
        if mass < 5.0{
            ballColor = BallColor.Blue
        } else {
            ballColor = BallColor.Red
        }
        super.init(texture: SKTexture(imageNamed: ballColor.rawValue), color: UIColor.white, size: CGSize(width: sceneSize.height * ballSizePercentage * ballSize.rawValue, height: sceneSize.height * ballSizePercentage * ballSize.rawValue))
        // set ball's physical properties
        self.physicsBody = SKPhysicsBody(texture: self.texture!, size: self.size)
        self.physicsBody?.friction = 0.0
        self.physicsBody?.restitution = 1.0
        self.physicsBody?.linearDamping = 0.0
        self.physicsBody?.mass = mass
        self.physicsBody?.allowsRotation = false
        self.physicsBody?.usesPreciseCollisionDetection = true
        self.physicsBody?.categoryBitMask = CollisionCategory.Ball
        self.physicsBody?.contactTestBitMask = CollisionCategory.Ball | CollisionCategory.Wall | CollisionCategory.Block
    }
    
    // not called but required if subclass defines an init()
    required init?(coder aDecoder: NSCoder){
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - StartMoving
    func startMoving(velocity: CGFloat){
        let vxModifier = CGFloat(Int(arc4random_uniform(maxV)) - minV)
        let vyModifier = CGFloat(Int(arc4random_uniform(maxV)) - minV)
        let ballVelVector = CGVector(dx: velocity * ballSize.rawValue * (ballVelocity.dx + vxModifier), dy: velocity * ballSize.rawValue * (ballVelocity.dy + vyModifier))
        self.physicsBody?.applyImpulse(ballVelVector)
    }
    
    // MARK: - Play Sounds
    func playHitSound(){
        bounceSound.play()
    }
    
    
}
