//
//  GameViewController.swift
//  CollisionDemo
//
//  Created by Allan Anderson on 2015-Dec-15.
//  Copyright © 2015 Allan Anderson. All rights reserved.
//

import UIKit
import SpriteKit
import AVFoundation

class GameViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // load sounds
        //bounceSound = try? AVAudioPlayer(contentsOfURL: NSURL(fileURLWithPath: NSBundle.mainBundle().pathForResource("bump-2", ofType: "wav")!))
        //wallSound = try? AVAudioPlayer(contentsOfURL: NSURL(fileURLWithPath: NSBundle.mainBundle().pathForResource("ping", ofType: "wav")!))
        // create the scene
        let scene = GameScene(size: view.bounds.size)
        scene.scaleMode = .AspectFill
        // create the SKView
        let skView = view as! SKView
        skView.showsFPS = true
        skView.showsNodeCount = true
        skView.ignoresSiblingOrder = true
        skView.presentScene(scene)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
