//
//  GameViewController.swift
//  CollisionDemo
//
//  Created by Allan Anderson on 2015-Feb-24.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import UIKit
import SpriteKit
import AVFoundation

var bounceSound: AVAudioPlayer!
var wallSound: AVAudioPlayer!

class GameViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // load sounds
        do {
            bounceSound =  try AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: Bundle.main.path(forResource: "bump-2", ofType: "wav")!) as URL)
        } catch let error{
            print(error)
        }
        
        do{
            wallSound = try AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: Bundle.main.path(forResource: "ping", ofType: "wav")!) as URL)
        } catch let error{
            print (error)
        }
        
        // create the scene
        let scene = GameScene(size: view.bounds.size)
        scene.scaleMode = .aspectFill
        // create the SKView
        let skView = view as! SKView
        skView.showsFPS = true
        skView.showsNodeCount = true
        skView.ignoresSiblingOrder = true
        skView.presentScene(scene)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Release any cached data, images, etc that aren't in use.
    }

}
