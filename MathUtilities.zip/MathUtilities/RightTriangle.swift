//
//  RightTriangle.swift
//  MathUtilities
//
//  Created by Allan Anderson on 13/11/2014.
//  Copyright (c) 2014 Allan Anderson. All rights reserved.
//

import Foundation

enum TriangleType{
    case OppositeHypotenuse
    case AdjacentHypotenuse
    case OppositeAdjacent
    case ThetaHypotenuse
    case ThetaOpposite
    case ThetaAdjacent
    
    func toString() -> String{
        var typeString = ""
        switch self{
        case .OppositeHypotenuse:
            typeString = "Opposite & Hypotenuse"
        case .AdjacentHypotenuse:
            typeString = "Adjacent & Hypotenuse"
        case .OppositeAdjacent:
            typeString = "Opposite & Adjacent"
        case .ThetaAdjacent:
            typeString = "Adjacent & Theta"
        case .ThetaOpposite:
            typeString = "Opposite & Theta"
        case .ThetaHypotenuse:
            typeString = "Hypotenuse & Theta"
        }
        return typeString
    }
}

struct RightTriangle {
    var type:TriangleType
    var hyp: Double
    var opp: Double
    var adj: Double
    var theta: Double
    
    init(opposite:Double, adjacent:Double){
        opp = opposite
        adj = adjacent
        hyp = sqrt(opp * opp + adj * adj)
        theta = atan(opp / adj)
        type = TriangleType.OppositeAdjacent
    }
    
    init(opposite:Double, hypotenuse:Double){
        opp = opposite
        hyp = hypotenuse
        adj = sqrt(hyp * hyp - opp * opp)
        theta = asin(opp / hyp)
        type = TriangleType.OppositeHypotenuse
    }
    
    init(adjacent:Double, hypotenuse:Double){
        adj = adjacent
        hyp = hypotenuse
        opp = sqrt(hyp * hyp - adj * adj)
        theta = acos(adj / hyp)
        type = TriangleType.AdjacentHypotenuse
    }
    
    init(theta:Double, hypotenuse:Double){
        self.theta = theta
        hyp = hypotenuse
        opp = sin(theta) * hyp
        adj = cos(theta) * hyp
        type = TriangleType.ThetaHypotenuse
    }
    
    init(theta:Double, opposite:Double){
        self.theta = theta
        opp = opposite
        hyp = opp / sin(theta)
        adj = opp / tan(theta)
        type = TriangleType.ThetaOpposite
    }
    
    init(theta:Double, adjacent:Double){
        self.theta = theta
        adj = adjacent
        opp = adj * tan(theta)
        hyp = adj / cos(theta)
        type = TriangleType.ThetaAdjacent
    }
	
	func toString() -> String{
		return "Adj = \(adj), Opp = \(opp), Hyp = \(hyp), θ = \(theta) radians, Type = \(type.toString())"
	}
}