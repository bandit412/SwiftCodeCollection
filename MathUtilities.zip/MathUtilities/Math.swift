//
//  Math.swift
//  MathUtilities
//
//  Created by Allan Anderson on 07/11/2014.
//  Copyright (c) 2014 Allan Anderson. All rights reserved.
//

import Cocoa

/*
Some basic math functions
*/
func greatestCommonDenominator (numerator:Double, denominator:Double) -> Double{
    if denominator != 0{
        if numerator % denominator == 0{
            return denominator
        } else {
            return greatestCommonDenominator(denominator, numerator % denominator)
        }
    } else {
        return Double.infinity
    }
}

func toDegrees (radians:Double) -> Double{
    return radians * 180 / M_PI
}

func toRadians (degrees:Double) -> Double{
    return degrees * M_PI / 180
}

func quadraticPositive(a:Double, b:Double, c:Double) -> Double{
    let b2 = b * b
    let ac4 = 4 * a * c
    let a2 = 2 * a
    let root = b2 - ac4
    return (-1 * b + sqrt(root)) / a2
}

func quadraticNegative(a:Double, b:Double, c:Double) -> Double{
    let b2 = b * b
    let ac4 = 4 * a * c
    let a2 = 2 * a
    let root = b2 - ac4
    return (-1 * b - sqrt(root)) / a2
}

func createArray(rows:Int, columns:Int) -> [[Double]]{
    var array2D = Array<Array<Double>>()
    for column in 0...rows - 1 {
        array2D.append(Array(count:columns, repeatedValue:Double()))
    }
    for row in 0...rows - 1{
        for col in 0...columns - 1{
            array2D[row][col] = 0.0
        }
    }
    return array2D
}



