//
//  PlaneWall.swift
//  CollisionWorld
//
//  Created by Allan Anderson on 2015-May-01.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import Foundation
import SceneKit

class PlaneWall{
    class func planeWall()->SCNGeometry{
        let wall = SCNPlane(width: 50, height: 50)
        wall.firstMaterial!.diffuse.contents = UIColor(red: 100/255, green: 100/255, blue: 100/255, alpha: 0.0)
        wall.firstMaterial!.specular.contents = UIColor(red: 0, green: 0, blue: 0, alpha: 0.0)
        wall.firstMaterial!.reflective.contents = UIColor(red: 0, green: 0, blue: 0, alpha: 0.0)
        return wall
    }
    
    class func wallNode()->SCNNode{
        let wallNode = SCNNode(geometry: planeWall())
        wallNode.physicsBody = SCNPhysicsBody(type: SCNPhysicsBodyType.dynamic, shape: SCNPhysicsShape(geometry: planeWall(), options: nil))
        wallNode.physicsBody?.categoryBitMask = CollisionCategory.Wall
        wallNode.physicsBody?.restitution = 1.0
        wallNode.physicsBody?.damping = 0.0
        wallNode.physicsBody?.friction = 0.0
        wallNode.physicsBody?.angularDamping = 0.0
        wallNode.physicsBody?.mass = CGFloat(0.0)
        wallNode.physicsBody?.collisionBitMask = CollisionCategory.Ball
        wallNode.physicsBody?.velocity = SCNVector3Zero
        wallNode.physicsBody?.rollingFriction = 0.0
        return wallNode
    }
    
    class func box()->SCNNode{
        let box = SCNNode()
        let back = wallNode()
        box.addChildNode(back)
        back.position = SCNVector3Make(0, 0, -25)
        let front = wallNode()
        box.addChildNode(front)
        front.position = SCNVector3Make(0, 0, 25)
        let left = wallNode()
        left.transform = SCNMatrix4MakeRotation(Float(Double.pi/2), Float(0), Float(1), Float(0))
        box.addChildNode(left)
        left.position = SCNVector3Make(-25, 0, 0)
        let right = wallNode()
        right.transform = SCNMatrix4MakeRotation(Float(Double.pi/2), Float(0), Float(1), Float(0))
        box.addChildNode(right)
        right.position = SCNVector3Make(25, 0, 0)
        let top = wallNode()
        top.transform = SCNMatrix4MakeRotation(Float(Double.pi/2), Float(1), Float(0), Float(0))
        box.addChildNode(top)
        top.position = SCNVector3Make(0, 25, 0)
        let bottom = wallNode()
        bottom.transform = SCNMatrix4MakeRotation(Float(Double.pi/2), Float(1), Float(0), Float(0))
        box.addChildNode(bottom)
        bottom.position = SCNVector3Make(0, -25, 0)
        return box
    }

}
