//
//  ViewController.swift
//  CollisionWorld
//
//  Created by Allan Anderson on 2015-May-01.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import UIKit
import SceneKit
import SpriteKit

class ViewController: UIViewController, SCNSceneRendererDelegate{

    var delegate: SCNSceneRendererDelegate?
    
    @IBOutlet var sceneView: SCNView!
    
    var rVelocity = SCNVector3Zero
    var bVelocity = SCNVector3Zero
    var gVelocity = SCNVector3Zero
    var rVelocity2 = SCNVector3Zero
    var bVelocity2 = SCNVector3Zero
    var gVelocity2 = SCNVector3Zero
    var momentum = SCNVector3Zero
    var rMag: Float = 0.0
    var bMag: Float = 0.0
    var gMag: Float = 0.0
    var rMag2: Float = 0.0
    var bMag2: Float = 0.0
    var gMag2: Float = 0.0
    var pMag: Float = 0.0
    
    var parentNode: SCNNode = SCNNode()
    var boxNode: SCNNode = SCNNode()
    var redBallNode: SCNNode = SCNNode()
    var blueBallNode: SCNNode = SCNNode()
    var greenBallNode: SCNNode = SCNNode()
    var redBallNode2: SCNNode = SCNNode()
    var blueBallNode2: SCNNode = SCNNode()
    var greenBallNode2: SCNNode = SCNNode()
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        sceneSetup()
        sceneView.delegate = self
        sceneView.scene?.physicsWorld.gravity = SCNVector3Make(0, 0, 0)
        boxNode = PlaneWall.box()
        redBallNode = Sphere.redNode()
        blueBallNode = Sphere.blueNode()
        greenBallNode = Sphere.greenNode()
        redBallNode2 = Sphere.redNode2()
        blueBallNode2 = Sphere.blueNode2()
        greenBallNode2 = Sphere.greenNode2()
        //sceneView.showsStatistics = true
        sceneView.scene!.rootNode.addChildNode(boxNode)
        sceneView.scene!.rootNode.addChildNode(redBallNode)
        sceneView.scene!.rootNode.addChildNode(blueBallNode)
        sceneView.scene!.rootNode.addChildNode(greenBallNode)
        sceneView.scene!.rootNode.addChildNode(redBallNode2)
        sceneView.scene!.rootNode.addChildNode(blueBallNode2)
        sceneView.scene!.rootNode.addChildNode(greenBallNode2)
        sceneView.overlaySKScene = hudSetup()
        Sphere.startMoving(ballNode: redBallNode)
        Sphere.startMoving(ballNode: blueBallNode)
        Sphere.startMoving(ballNode: greenBallNode)
        Sphere.startMoving(ballNode: redBallNode2)
        Sphere.startMoving(ballNode: blueBallNode2)
        Sphere.startMoving(ballNode: greenBallNode2)

    }
    
    func sceneSetup(){
        let scene = SCNScene()
        let ambientLightNode = SCNNode()
        ambientLightNode.light = SCNLight()
        ambientLightNode.light!.type = SCNLight.LightType.ambient
        ambientLightNode.light!.color = UIColor(white: 0.75, alpha: 1.0)
        scene.rootNode.addChildNode(ambientLightNode)
        let omniLightNode = SCNNode()
        omniLightNode.light = SCNLight()
        omniLightNode.light!.type = SCNLight.LightType.omni
        omniLightNode.light!.color = UIColor(white: 0.5, alpha: 1.0)
        omniLightNode.position = SCNVector3Make(0, 25, 25)
        scene.rootNode.addChildNode(omniLightNode)
        let spotLightNode = SCNNode()
        spotLightNode.light = SCNLight()
        spotLightNode.light!.type = SCNLight.LightType.spot
        spotLightNode.light!.color = UIColor(white: 1.0, alpha: 1.0)
        spotLightNode.position = SCNVector3Make(0, 50, 0)
        scene.rootNode.addChildNode(spotLightNode)
        let cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        cameraNode.position = SCNVector3Make(0, 0, 70)
        scene.rootNode.addChildNode(cameraNode)
        //let panRecognizer = UIPanGestureRecognizer(target: self, action: "panGesture:")
        //sceneView.addGestureRecognizer(panRecognizer)
        sceneView.scene = scene
        //sceneView.autoenablesDefaultLighting = true
        sceneView.allowsCameraControl = false
    }
    
    func hudSetup()->SKScene{
        let fontSize = CGFloat(18.0)
        //let labelSpacing = CGFloat(5.0)
        let edgeDistance = CGFloat(10.0)
        let hud = SKScene()
        hud.size = CGSize(width: 25, height: edgeDistance * 4 + fontSize * 3)
        hud.scaleMode = SKSceneScaleMode.resizeFill
        hud.backgroundColor = SKColor.white
        let lightNode = SKLightNode()
        lightNode.ambientColor = UIColor.white
        hud.addChild(lightNode)
        
        let redVelocityLabel = SKLabelNode(fontNamed: "Courier")
        redVelocityLabel.fontColor = SKColor.red
        redVelocityLabel.fontSize = fontSize
        redVelocityLabel.text = String(format:"R1: [%.04f   %.04f   %.04f] m/s", rVelocity.x, rVelocity.y, rVelocity.z)
        redVelocityLabel.horizontalAlignmentMode = .left
        redVelocityLabel.position = CGPoint(x:edgeDistance * 2, y:edgeDistance * 3)
        redVelocityLabel.name = "red"
        hud.addChild(redVelocityLabel)
        
        let blueVelocityLabel = SKLabelNode(fontNamed: "Courier")
        blueVelocityLabel.fontColor = SKColor.cyan
        blueVelocityLabel.fontSize = fontSize
        blueVelocityLabel.text = String(format:"B1: [%.04f   %.04f   %.04f] m/s", bVelocity.x, bVelocity.y, bVelocity.z)
        blueVelocityLabel.horizontalAlignmentMode = .left
        blueVelocityLabel.position = CGPoint(x:edgeDistance * 2, y:edgeDistance + redVelocityLabel.calculateAccumulatedFrame().maxY)
        blueVelocityLabel.name = "blue"
        hud.addChild(blueVelocityLabel)
        
        let greenVelocityLabel = SKLabelNode(fontNamed: "Courier")
        greenVelocityLabel.fontColor = SKColor.purple
        greenVelocityLabel.fontSize = fontSize
        greenVelocityLabel.text = String(format:"G1: [%.04f   %.04f   %.04f] m/s", gVelocity.x, gVelocity.y, gVelocity.z)
        greenVelocityLabel.horizontalAlignmentMode = .left
        greenVelocityLabel.position = CGPoint(x:edgeDistance * 2, y:edgeDistance + blueVelocityLabel.calculateAccumulatedFrame().maxY)
        greenVelocityLabel.name = "green"
        hud.addChild(greenVelocityLabel)
        
        let redVelocityLabel2 = SKLabelNode(fontNamed: "Courier")
        redVelocityLabel2.fontColor = SKColor.brown
        redVelocityLabel2.fontSize = fontSize
        redVelocityLabel2.text = String(format:"R2: [%.04f   %.04f   %.04f] m/s", rVelocity2.x, rVelocity2.y, rVelocity2.z)
        redVelocityLabel2.horizontalAlignmentMode = .left
        redVelocityLabel2.position = CGPoint(x:edgeDistance * 2, y:edgeDistance + greenVelocityLabel.calculateAccumulatedFrame().maxY)
        redVelocityLabel2.name = "red2"
        hud.addChild(redVelocityLabel2)
        
        let blueVelocityLabel2 = SKLabelNode(fontNamed: "Courier")
        blueVelocityLabel2.fontColor = SKColor.blue
        blueVelocityLabel2.fontSize = fontSize
        blueVelocityLabel2.text = String(format:"B2: [%.04f   %.04f   %.04f] m/s", bVelocity2.x, bVelocity2.y, bVelocity2.z)
        blueVelocityLabel2.horizontalAlignmentMode = .left
        blueVelocityLabel2.position = CGPoint(x:edgeDistance * 2, y:edgeDistance + redVelocityLabel2.calculateAccumulatedFrame().maxY)
        blueVelocityLabel2.name = "blue2"
        hud.addChild(blueVelocityLabel2)
        
        let greenVelocityLabel2 = SKLabelNode(fontNamed: "Courier")
        greenVelocityLabel2.fontColor = SKColor.green
        greenVelocityLabel2.fontSize = fontSize
        greenVelocityLabel2.text = String(format:"G2: [%.04f   %.04f   %.04f] m/s", gVelocity2.x, gVelocity2.y, gVelocity2.z)
        greenVelocityLabel2.horizontalAlignmentMode = .left
        greenVelocityLabel2.position = CGPoint(x:edgeDistance * 2, y:edgeDistance + blueVelocityLabel2.calculateAccumulatedFrame().maxY)
        greenVelocityLabel2.name = "green2"
        hud.addChild(greenVelocityLabel2)
        
        let momentumLabel = SKLabelNode(fontNamed: "Courier")
        momentumLabel.fontColor = SKColor.black
        momentumLabel.fontSize = fontSize
        momentumLabel.text = String(format:"P = [%.04f   %.04f   %.04f] kg m/s", momentum.x, momentum.y, momentum.z)
        momentumLabel.horizontalAlignmentMode = .left
        momentumLabel.position = CGPoint(x:edgeDistance * 2, y:edgeDistance + greenVelocityLabel2.calculateAccumulatedFrame().maxY)
        momentumLabel.name = "momentum"
        hud.addChild(momentumLabel)
        
        hud.name = "hud"
        return hud
    }
    
    // MARK: SCNSceneRendererDelegate Methods
    func renderer(_ renderer: SCNSceneRenderer, updateAtTime time: TimeInterval) {
        rMag = sqrt(rVelocity.x * rVelocity.x + rVelocity.y * rVelocity.y + rVelocity.z * rVelocity.z)
        bMag = sqrt(bVelocity.x * bVelocity.x + bVelocity.y * bVelocity.y + bVelocity.z * bVelocity.z)
        gMag = sqrt(gVelocity.x * gVelocity.x + gVelocity.y * gVelocity.y + gVelocity.z * gVelocity.z)
        
        rMag2 = sqrt(rVelocity2.x * rVelocity2.x + rVelocity2.y * rVelocity2.y + rVelocity2.z * rVelocity2.z)
        bMag2 = sqrt(bVelocity2.x * bVelocity2.x + bVelocity2.y * bVelocity2.y + bVelocity2.z * bVelocity2.z)
        gMag2 = sqrt(gVelocity2.x * gVelocity2.x + gVelocity2.y * gVelocity2.y + gVelocity2.z * gVelocity2.z)
        
        pMag = sqrt(momentum.x * momentum.x + momentum.y * momentum.y + momentum.z * momentum.z)
        
        let redNode: SKLabelNode = sceneView.overlaySKScene!.childNode(withName: "red") as! SKLabelNode
        redNode.text = String(format:"R1: [%.04f   %.04f   %.04f] m/s |%.04f|", rVelocity.x, rVelocity.y, rVelocity.z, rMag)
        let blueNode: SKLabelNode = sceneView.overlaySKScene!.childNode(withName: "blue") as! SKLabelNode
        blueNode.text = String(format:"B1: [%.04f   %.04f   %.04f] m/s |%.04f|", bVelocity.x, bVelocity.y, bVelocity.z, bMag)
        let greenNode: SKLabelNode = sceneView.overlaySKScene!.childNode(withName: "green") as! SKLabelNode
        greenNode.text = String(format:"G1: [%.04f   %.04f   %.04f] m/s |%.04f|", gVelocity.x, gVelocity.y, gVelocity.z, gMag)
        
        let redNode2: SKLabelNode = sceneView.overlaySKScene!.childNode(withName: "red2") as! SKLabelNode
        redNode2.text = String(format:"R2: [%.04f   %.04f   %.04f] m/s |%.04f|", rVelocity2.x, rVelocity2.y, rVelocity2.z, rMag2)
        let blueNode2: SKLabelNode = sceneView.overlaySKScene!.childNode(withName: "blue2") as! SKLabelNode
        blueNode2.text = String(format:"B2: [%.04f   %.04f   %.04f] m/s |%.04f|", bVelocity2.x, bVelocity2.y, bVelocity2.z, bMag2)
        let greenNode2: SKLabelNode = sceneView.overlaySKScene!.childNode(withName: "green2") as! SKLabelNode
        greenNode2.text = String(format:"G2: [%.04f   %.04f   %.04f] m/s |%.04f|", gVelocity2.x, gVelocity2.y, gVelocity2.z, gMag2)
        
        let momentumNode: SKLabelNode = sceneView.overlaySKScene!.childNode(withName: "momentum") as! SKLabelNode
        momentumNode.text = String(format:"P = [%.02f   %.02f   %.02f] kg m/s |%.04f|", momentum.x, momentum.y, momentum.z, pMag)

    }
    
    func renderer(_ renderer: SCNSceneRenderer, willRenderScene scene: SCNScene, atTime time: TimeInterval) {
    }
    
    func renderer(_ renderer: SCNSceneRenderer, didSimulatePhysicsAtTime time: TimeInterval) {
        rVelocity = redBallNode.physicsBody!.velocity
        bVelocity = blueBallNode.physicsBody!.velocity
        gVelocity = greenBallNode.physicsBody!.velocity
        rVelocity2 = redBallNode2.physicsBody!.velocity
        bVelocity2 = blueBallNode2.physicsBody!.velocity
        gVelocity2 = greenBallNode2.physicsBody!.velocity
        // calculate total momentum of the system
        let r1mass = Float(redBallNode.physicsBody!.mass)
        let r1P = SCNVector3Make(rVelocity.x * r1mass, rVelocity.y * r1mass, rVelocity.z * r1mass)
        let b1mass = Float(blueBallNode.physicsBody!.mass)
        let b1P = SCNVector3Make(bVelocity.x * b1mass, bVelocity.y * b1mass, bVelocity.z * b1mass)
        let g1mass = Float(greenBallNode.physicsBody!.mass)
        let g1P = SCNVector3Make(gVelocity.x * g1mass, gVelocity.y * g1mass, gVelocity.z * g1mass)
        let r2mass = Float(redBallNode2.physicsBody!.mass)
        let r2P = SCNVector3Make(rVelocity2.x * r2mass, rVelocity2.y * r2mass, rVelocity2.z * r2mass)
        let b2mass = Float(blueBallNode2.physicsBody!.mass)
        let b2P = SCNVector3Make(bVelocity2.x * b2mass, bVelocity2.y * b2mass, bVelocity2.z * b2mass)
        let g2mass = Float(greenBallNode2.physicsBody!.mass)
        let g2P = SCNVector3Make(gVelocity2.x * g2mass, gVelocity2.y * g2mass, gVelocity2.z * g2mass)
        
        momentum.x = r1P.x + b1P.x + g1P.x + r2P.x + b2P.x + g2P.x
        momentum.y = r1P.y + b1P.y + g1P.y + r2P.y + b2P.y + g2P.y
        momentum.z = r1P.z + b1P.z + g1P.z + r2P.z + b2P.z + g2P.z
        
    }
    
    func renderer(aRenderer: SCNSceneRenderer, didRenderScene scene: SCNScene, atTime time: TimeInterval) {
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

