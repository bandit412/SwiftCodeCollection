//
//  Sphere.swift
//  CollisionWorld
//
//  Created by Allan Anderson on 2015-May-01.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import Foundation
import SceneKit

// struct to identify collisions
struct CollisionCategory{
    static let Ball : Int = 1
    static let Wall : Int = 1 << 0
}

private let velocity = SCNVector3Make(0.0, 0.0, 0.0)
private let minV: Float = -40.0
private let maxV = 40

class Sphere{
    class func redSphere()-> SCNGeometry{
        let redSphere = SCNSphere(radius: 3.0)
        redSphere.firstMaterial!.diffuse.contents = "Ball3.png"
        redSphere.firstMaterial!.specular.contents = UIColor.white
        return redSphere
    }
    
    class func blueSphere() -> SCNGeometry{
        let blueSphere = SCNSphere(radius: 3.0)
        blueSphere.firstMaterial!.diffuse.contents = "Ball2.png"
        blueSphere.firstMaterial!.specular.contents = UIColor.white
        return blueSphere
    }
    
    class func greenSphere() -> SCNGeometry{
        let greenSphere = SCNSphere(radius: 3.0)
        greenSphere.firstMaterial!.diffuse.contents = "Ball6.png"
        greenSphere.firstMaterial!.specular.contents = UIColor.white
        return greenSphere
    }
    
    class func redSphere2()-> SCNGeometry{
        let redSphere = SCNSphere(radius: 3.0)
        redSphere.firstMaterial!.diffuse.contents = "Ball11.png"
        redSphere.firstMaterial!.specular.contents = UIColor.white
        return redSphere
    }
    
    class func blueSphere2() -> SCNGeometry{
        let blueSphere = SCNSphere(radius: 3.0)
        blueSphere.firstMaterial!.diffuse.contents = "Ball10.png"
        blueSphere.firstMaterial!.specular.contents = UIColor.white
        return blueSphere
    }
    
    class func greenSphere2() -> SCNGeometry{
        let greenSphere = SCNSphere(radius: 3.0)
        greenSphere.firstMaterial!.diffuse.contents = "Ball14.png"
        greenSphere.firstMaterial!.specular.contents = UIColor.white
        return greenSphere
    }

    
    // test for generic SCNNode:Sphere
    class func sphereNode()-> SCNNode{
        let sphereNode = SCNNode(geometry: SCNSphere())
        sphereNode.physicsBody = SCNPhysicsBody(type: SCNPhysicsBodyType.dynamic, shape: SCNPhysicsShape(geometry: redSphere(), options: nil))
        sphereNode.physicsBody?.damping = 0.0
        sphereNode.physicsBody?.restitution = 1.0
        sphereNode.physicsBody?.friction = 0.0
        sphereNode.physicsBody?.mass = 2.0
        sphereNode.physicsBody?.angularDamping = 0.0
        sphereNode.physicsBody?.velocity = velocity
        sphereNode.physicsBody?.velocityFactor = SCNVector3Make(1, 1, 1)
        sphereNode.physicsBody?.angularVelocityFactor = SCNVector3Make(1, 1, 1)
        sphereNode.physicsBody?.allowsResting = false
        sphereNode.physicsBody?.applyTorque(SCNVector4Make(1.0, 1.0, 1.0, 1.0), asImpulse: true)
        sphereNode.physicsBody?.categoryBitMask = CollisionCategory.Ball
        sphereNode.physicsBody?.collisionBitMask = CollisionCategory.Ball | CollisionCategory.Wall
        return sphereNode
    }
    
    
    class func redNode() -> SCNNode{
        let redNode = sphereNode()
        redNode.geometry = redSphere()
        redNode.position = SCNVector3Make(0, 0, 0)
        redNode.name = "redBall"
        return redNode
    }
    
    class func blueNode() -> SCNNode{
        let blueNode = sphereNode()
        blueNode.geometry = blueSphere()
        blueNode.position = SCNVector3Make(5, 5, 5)
        blueNode.name = "blueBall"
        return blueNode
    }
    
    class func greenNode() -> SCNNode{
        let greenNode = sphereNode()
        greenNode.geometry = greenSphere()
        greenNode.position = SCNVector3Make(-5, -5, -5)
        greenNode.name = "greenBall"
        return greenNode
    }
    
    class func redNode2() -> SCNNode{
        let redNode = sphereNode()
        redNode.geometry = redSphere2()
        redNode.position = SCNVector3Make(10,-10, 10)
        redNode.name = "redBall"
        return redNode
    }
    
    class func blueNode2() -> SCNNode{
        let blueNode = sphereNode()
        blueNode.geometry = blueSphere2()
        blueNode.position = SCNVector3Make(15, 0, -15)
        blueNode.name = "blueBall"
        return blueNode
    }
    
    class func greenNode2() -> SCNNode{
        let greenNode = sphereNode()
        greenNode.geometry = greenSphere2()
        greenNode.position = SCNVector3Make(5, -15, 5)
        greenNode.name = "greenBall"
        return greenNode
    }

    
    class func startMoving(ballNode: SCNNode){
        var vxModifier = Float(arc4random_uniform(UInt32(maxV)))
        vxModifier = vxModifier - minV
        var vyModifier = Float(arc4random_uniform(UInt32(maxV)))
        vyModifier = vxModifier - minV
        var vzModifier = Float(arc4random_uniform(UInt32(maxV)))
        vzModifier = vxModifier - minV
        let ballVector = SCNVector3Make(velocity.x + vxModifier, velocity.y + vyModifier, velocity.z + vzModifier)
        ballNode.physicsBody?.applyForce(ballVector, asImpulse: true)
    }
}
