# Calculator-Swift
OS X Version of the C# Calculator. This version uses the same type of classes as the MathPhysicsCalculator, only coded in Swift.

## Project Update - November 8, 2016
I recently upgraded to the latest version of Xcode. As a result this project has been updated to the latest version of Swift, which is Swift 3.

## Project Update - September 24, 2016
I have not dedicated much time to this project lately as other projects have been given higher priority. I hope to return to this project in 2017.
