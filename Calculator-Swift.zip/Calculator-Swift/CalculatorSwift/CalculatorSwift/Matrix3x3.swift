//
//  Matrix3x3.swift
//  MathPhysicsCalculator
//
//  Created by Allan Anderson on 2015-Apr-23.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import Foundation

open class Matrix3x3{
    // MARK : Properties
    var m11:Double
    var m12:Double
    var m13:Double
    var m21:Double
    var m22:Double
    var m23:Double
    var m31:Double
    var m32:Double
    var m33:Double
    
    // MARK: Init
    init(){
        m11 = 0
        m12 = 0
        m13 = 0
        m21 = 0
        m22 = 0
        m23 = 0
        m31 = 0
        m32 = 0
        m33 = 0
    }
    init(m11:Double, andM12 m12:Double, andM13 m13:Double,
        andM21 m21:Double, andM22 m22:Double, andM23 m23:Double,
        andM31 m31:Double, andM32 m32:Double, andM33 m33:Double){
        self.m11 = m11
        self.m12 = m12
        self.m13 = m13
        self.m21 = m21
        self.m22 = m22
        self.m23 = m23
        self.m31 = m31
        self.m32 = m32
        self.m33 = m33
    }
    init(p:Vector3D, withQ q: Vector3D, andR r:Vector3D){
        // this is a Column Majo matrix
        m11 = p.x
        m12 = q.x
        m13 = r.x
        m21 = p.y
        m22 = q.y
        m23 = r.y
        m31 = p.z
        m32 = q.z
        m33 = r.z
    }
}
