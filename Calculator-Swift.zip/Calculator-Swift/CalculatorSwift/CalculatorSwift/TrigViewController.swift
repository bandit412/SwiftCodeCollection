//
//  TrigViewController.swift
//  CalculatorSwift
//
//  Created by Allan Anderson on 2016-04-06.
//  Copyright © 2016 Allan Anderson. All rights reserved.
//

import Cocoa

class TrigViewController: NSViewController {

    // MARK: Adjacent and Hypotenuse
    @IBOutlet weak var OA_Adj: NSTextField!
    @IBOutlet weak var OA_Opp: NSTextField!
    @IBOutlet weak var OA_Hyp: NSTextField!
    @IBOutlet weak var OA_Rad: NSTextField!
    @IBOutlet weak var OA_Deg: NSTextField!
    
    @IBAction func OA_Solve(_ sender: NSButton) {
        let adj = OA_Adj.doubleValue
        let opp = OA_Opp.doubleValue
        let results = Calculator.calcHypThetaRThetaD(adj, opp: opp)
        // display
        OA_Hyp.stringValue = String(format: "%.4f", results.hyp)
        OA_Rad.stringValue = String(format: "%.4f", results.thetaR)
        OA_Deg.stringValue = String(format: "%.4f", results.thetaD)
    }
    
    @IBAction func OA_Export(_ sender: NSButton) {
        
    }
    
    @IBAction func OA_Reset(_ sender: NSButton) {
        OA_Hyp.stringValue = ""
        OA_Rad.stringValue = ""
        OA_Deg.stringValue = ""
        OA_Adj.stringValue = ""
        OA_Opp.stringValue = ""
    }
    
    // MARK: Adjacent and Hypotenuse
    @IBOutlet weak var AH_Adj: NSTextField!
    @IBOutlet weak var AH_Hyp: NSTextField!
    @IBOutlet weak var AH_Opp: NSTextField!
    @IBOutlet weak var AH_Rad: NSTextField!
    @IBOutlet weak var AH_Deg: NSTextField!
    
    @IBAction func AH_Solve(_ sender: NSButton) {
        let adj = AH_Adj.doubleValue
        let hyp = AH_Hyp.doubleValue
        let results = Calculator.calcOppThetaRThetaD(adj, hyp: hyp)
        // display
        AH_Opp.stringValue = String(format: "%.4f", results.opp)
        AH_Rad.stringValue = String(format: "%.4f", results.thetaR)
        AH_Deg.stringValue = String(format: "%.4f", results.thetaD)
    }
    
    @IBAction func AH_Export(_ sender: NSButton) {
        
    }
    
    @IBAction func AH_Reset(_ sender: NSButton) {
        AH_Adj.stringValue = ""
        AH_Hyp.stringValue = ""
        AH_Opp.stringValue = ""
        AH_Rad.stringValue = ""
        AH_Deg.stringValue = ""
    }
    
    // MARK: Opposite and Hypotenuse
    @IBOutlet weak var OH_Opp: NSTextField!
    @IBOutlet weak var OH_Hyp: NSTextField!
    @IBOutlet weak var OH_Adj: NSTextField!
    @IBOutlet weak var OH_Rad: NSTextField!
    @IBOutlet weak var OH_Deg: NSTextField!
    
    @IBAction func OH_Solve(_ sender: NSButton) {
        let opp = OH_Opp.doubleValue
        let hyp = OH_Hyp.doubleValue
        let results = Calculator.calcAdjThetaRThetaD(opp, hyp: hyp)
        // display
        OH_Adj.stringValue = String(format: "%.4f", results.adj)
        OH_Rad.stringValue = String(format: "%.4f", results.thetaR)
        OH_Deg.stringValue = String(format: "%.4f", results.thetaD)
    }
    
    @IBAction func OH_Export(_ sender: NSButton) {
        
    }
    
    @IBAction func OH_Reset(_ sender: NSButton) {
        OH_Opp.stringValue = ""
        OH_Hyp.stringValue = ""
        OH_Adj.stringValue = ""
        OH_Rad.stringValue = ""
        OH_Deg.stringValue = ""
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
    }
    
}
