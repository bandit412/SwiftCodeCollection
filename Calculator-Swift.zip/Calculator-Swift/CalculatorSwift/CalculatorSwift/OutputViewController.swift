//
//  OutputViewController.swift
//  CalculatorSwift
//
//  Created by Allan Anderson on 2016-04-09.
//  Copyright © 2016 Allan Anderson. All rights reserved.
//

import Cocoa

class OutputViewController: NSViewController {

    @IBOutlet weak var OutoutTF: NSTextField!
    
    @IBAction func CloseView(_ sender: NSButton) {
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
    }
    
}
