//
//  Force2D.swift
//  MathPhysicsCalculator
//
//  Created by Allan Anderson on 2015-Apr-24.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import Foundation

open class Force2D{
    // MARK: Properties
    var g:Vector2D
    var m:Double
    var appliedForce:Vector2D
    var mu:Double
    var rampRadians:Double
    
    // MARK: Init
    init(){
        g = Vector2D(x: 0,andY: -9.81)
        m = 0
        appliedForce = Vector2D()
        mu = 0
        rampRadians = 0
    }
    init(gravity:Vector2D, andMass mass:Double, withAppliedForce applied:PolarVector, andMu mu:Double, andRampDegrees ramp:Double){
        g = gravity
        m = mass
        appliedForce = Vector2D(p: applied)
        self.mu = mu
        rampRadians = Calculator.toRadians(ramp)
    }
    // MARK: Private Methods

}
