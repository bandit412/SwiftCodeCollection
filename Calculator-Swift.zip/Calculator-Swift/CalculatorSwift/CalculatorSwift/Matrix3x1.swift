//
//  Matrix3x1.swift
//  MathPhysicsCalculator
//
//  Created by Allan Anderson on 2015-Apr-23.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import Foundation

open class Matrix3x1{
    // MARK : Properties
    var m11:Double
    var m21:Double
    var m31:Double = 1
    
    // MARK: Init
    init(){
        m11 = 0
        m21 = 0
    }
    init(m11:Double, andM21 m21:Double){
        self.m11 = m11
        self.m21 = m21
    }
    init(vector2:Vector2D){
        m11 = vector2.x
        m21 = vector2.y
    }
    init(vector v:Vector3D){
        m11 = v.x
        m21 = v.y
        m31 = v.z
    }
}
