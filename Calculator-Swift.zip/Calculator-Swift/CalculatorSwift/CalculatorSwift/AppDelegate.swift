//
//  AppDelegate.swift
//  CalculatorSwift
//
//  Created by Allan Anderson on 2016-04-06.
//  Copyright © 2016 Allan Anderson. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {



    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }


}

