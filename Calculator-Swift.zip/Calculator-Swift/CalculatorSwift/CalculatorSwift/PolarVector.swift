//
//  PolarVector.swift
//  MathPhysicsCalculator
//
//  Created by Allan Anderson on 2015-Apr-23.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import Foundation

open class PolarVector{
    // MARK: Properties
    var magnitude:Double
    var degrees:Double
    var radians:Double
    var x:Double
    var y:Double
    
    // MARK: Init
    init(){
        magnitude = 0
        degrees = 0
        radians = 0
        x = 0
        y = 0
    }
    init(magnitude:Double, andDegrees degrees:Double){
        self.magnitude = magnitude
        self.degrees = degrees
        radians = Calculator.toRadians(degrees)
        x = cos(radians) * magnitude
        y = sin(radians) * magnitude
    }
}
