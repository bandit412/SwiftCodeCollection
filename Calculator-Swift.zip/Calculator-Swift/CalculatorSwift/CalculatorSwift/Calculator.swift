//
//  Calculator.swift
//  MathPhysicsCalculator
//
//  Created by Allan Anderson on 2015-Apr-23.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import Foundation

open class Calculator{
    // properties (none initially)
    static let G = 6.67e-11
    // init (not initially required
    
    // functions
    
    // MARK: Math Utilities
    static func toDegrees(_ radians:Double)->Double{
        return radians * 180 / M_PI
    }
    static func toRadians(_ degrees:Double)->Double{
        return degrees * M_PI / 180
    }
    
    // the two functions below use the quadratic formula
    //     -b ± √(b^2 - 4ac)
    // x = -----------------
    //           2a
    static func quadraticPostive(inA a:Double, andB b: Double, andC c:Double)->Double{
        let b2 = b * b;
        let ac4 = 4 * a * c;
        let a2 = 2 * a;
        let root = b2 - ac4;
        return (-1 * b + sqrt(root)) / a2;
    }
    static func quadraticNegative(inA a:Double, andB b: Double, andC c:Double)->Double{
        let b2 = b * b;
        let ac4 = 4 * a * c;
        let a2 = 2 * a;
        let root = b2 - ac4;
        return (-1 * b - sqrt(root)) / a2;
    }
    
    // MARK: Trigonometry
    static func calcHypThetaRThetaD(_ adj:Double, opp:Double)->(hyp:Double, thetaR:Double, thetaD:Double){
        let hyp = sqrt(adj * adj + opp * opp)
        let thetaR = atan(opp / adj)
        let thetaD = toDegrees(thetaR)
        return (hyp, thetaR, thetaD)
    }
    
    static func calcOppThetaRThetaD(_ adj:Double, hyp:Double)->(opp:Double, thetaR:Double, thetaD:Double){
        let opp = sqrt(hyp * hyp - adj * adj)
        let thetaR = acos(adj / hyp)
        let thetaD = toDegrees(thetaR)
        return (opp, thetaR, thetaD)
    }
    
    static func calcAdjThetaRThetaD(_ opp:Double, hyp:Double)->(adj:Double, thetaR:Double, thetaD:Double){
        let adj = sqrt(hyp * hyp - opp * opp)
        let thetaR = asin(opp / hyp)
        let thetaD = toDegrees(thetaR)
        return (adj, thetaR, thetaD)
    }
    
    static func calcOppAdjThetaR(_ hyp:Double, thetaD:Double)->(opp:Double, adj:Double, thetaR:Double){
        let opp = sin(toRadians(thetaD)) * hyp
        let adj = cos(toRadians(thetaD)) * hyp
        let thetaR = toRadians(thetaD)
        return (opp, adj, thetaR)
    }
    
    static func calcOppHypThetaR(_ adj:Double, thetaD:Double)->(opp:Double, hyp:Double, thetaR:Double){
        let opp = tan(toRadians(thetaD)) * adj
        let hyp = adj / cos(toRadians(thetaD))
        let thetaR = toRadians(thetaD)
        return (opp, hyp, thetaR)
    }
    
    static func calcAdjHypThetaR(_ opp:Double, thetaD:Double)->(adj:Double, hyp:Double, thetaR:Double){
        let adj = opp / tan(toRadians(thetaD))
        let hyp = opp / sin(toRadians(thetaD))
        let thetaR = toRadians(thetaD)
        return (adj, hyp, thetaR)
    }
    
    
    // MARK: Vector2D
    static func addVector(vectA a:Vector2D, vectB b:Vector2D)->Vector2D{
        return Vector2D(x: a.x + b.x, andY: a.y + b.y)
    }
    static func subtractVector(vectA a:Vector2D, minusVectB b:Vector2D)->Vector2D{
        return Vector2D(x: a.x - b.x, andY: a.y - b.y)
    }
    static func scaleVector(vectA a:Vector2D, andScale scale:Double)->Vector2D{
        return Vector2D(x: a.x * scale, andY: a.y * scale)
    }
    static func squareVector(vector a:Vector2D)->Vector2D{
        return Vector2D(x: a.x * a.x, andY: a.y * a.y)
    }
    static func dotProduct(vectA a:Vector2D, vectB b:Vector2D)->Double{
        return a.x * b.x + a.y * b.y
    }
    static func normalize(vector a:Vector2D)->Vector2D{
        return Vector2D(x: a.x / a.magnitude, andY: a.y / a.magnitude)
    }
    static func angleBetweenVector(vectA a:Vector2D, andVectB b:Vector2D)->Double{
        return acos(self.dotProduct(vectA: a, vectB: b) / (a.magnitude * b.magnitude))
    }
    static func createVectors(matrix m:Matrix2x2)->(p:Vector2D, q:Vector2D){
        // this uses Column Major matrices
        let p = Vector2D(x: m.m11, andY: m.m21)
        let q = Vector2D(x: m.m12, andY: m.m22)
        return (p, q)
    }
    
    // MARK: Vector3D
    static func addVector(vectA a:Vector3D, vectB b:Vector3D)->Vector3D{
        return Vector3D(x: a.x + b.x, andY: a.y + b.y, andZ: a.z + b.z)
    }
    static func subtractVector(vectA a:Vector3D, minusVectB b:Vector3D)->Vector3D{
        return Vector3D(x: a.x - b.x, andY: a.y - b.y, andZ: a.z - b.z)
    }
    static func scaleVector(vectA a:Vector3D, andScale scale:Double)->Vector3D{
        return Vector3D(x: a.x * scale, andY: a.y * scale, andZ: a.z * scale)
    }
    static func squareVector(vector a:Vector3D)->Vector3D{
        return Vector3D(x: a.x * a.x, andY: a.y * a.y, andZ: a.z * a.z)
    }
    static func dotProduct(vectA a:Vector3D, vectB b:Vector3D)->Double{
        return a.x * b.x + a.y * b.y + a.z * b.z
    }
    static func normalize(vector a:Vector3D)->Vector3D{
        return Vector3D(x: a.x / a.magnitude, andY: a.y / a.magnitude, andZ: a.z / a.magnitude)
    }
    static func angleBetweenVector(vectA a:Vector3D, andVectB b:Vector3D)->Double{
        return acos(dotProduct(vectA: a, vectB: b) / (a.magnitude * b.magnitude))
    }
    static func crossProduct(vectA a:Vector3D, vectB b:Vector3D)->Vector3D{
        return Vector3D(x: a.y * b.z - a.z * b.y, andY: a.z * b.x - a.x * b.z, andZ: a.x * b.y - a.y * b.x)
    }
    static func surfaceNormal(vectA a:Vector3D, vectB b:Vector3D)->Vector3D{
        return scaleVector(vectA: crossProduct(vectA: a, vectB: b), andScale: a.magnitude * b.magnitude)
    }
    static func createVectors(matrix m:Matrix3x3)->(p:Vector3D, q:Vector3D, r:Vector3D){
        // this uses a Column Major matrix
        let p = Vector3D(x: m.m11, andY: m.m21, andZ: m.m31)
        let q = Vector3D(x: m.m12, andY: m.m22, andZ: m.m32)
        let r = Vector3D(x: m.m13, andY: m.m23, andZ: m.m33)
        return (p, q, r)
    }
    static func createVectors(matrix m:Matrix4x4)->(p:Vector3D, q:Vector3D, r:Vector3D){
        // this uses a Column Major matrix
        let p = Vector3D(x: m.m11, andY: m.m21, andZ: m.m31)
        let q = Vector3D(x: m.m12, andY: m.m22, andZ: m.m32)
        let r = Vector3D(x: m.m13, andY: m.m23, andZ: m.m33)
        return (p, q, r)
    }
    
    // MARK: Quaternions
    static func createQuaternionToMatrix(quat q:Quaternion)->Matrix4x4{
        return Matrix4x4(m11: 1 - 2 * (q.qY * q.qY + q.qZ * q.qZ), andM12: 2 * (q.qX * q.qY - q.qW * q.qZ), andM13: 2 * (q.qX * q.qZ + q.qW * q.qY), andM14: 0, andM21: 2 * (q.qX * q.qY + q.qZ * q.qW), andM22: 1 - 2 * (q.qX * q.qX + q.qZ * q.qZ), andM23: 2 * (q.qY * q.qZ - q.qX * q.qW), andM24: 0, andM31: 2 * (q.qX * q.qZ - q.qY * q.qW), andM32: 2 * (q.qY * q.qZ + q.qX * q.qW), andM33: 1 - 2 * (q.qX * q.qX + q.qW * q.qW), andM34: 0, andM41: 0, andM42: 0, andM43: 0, andM44: 1)
    }
    static func quaternionToEuler(quat q:Quaternion)->(roll:Double, pitch:Double, yaw:Double){
        let r = atan2(2 * (q.qX * q.qY + q.qW * q.qZ), 1 - 2 * (q.qX * q.qX + q.qZ * q.qZ))
        let p = asin(-2 * (q.qY * q.qZ - q.qW * q.qX))
        let y = atan2(2 * (q.qX * q.qZ + q.qW * q.qY), 1 - 2 * (q.qX * q.qX + q.qY * q.qY))
        return (r, p, y)
    }
    static func matrixToQuaternion(matrix r:Matrix3x3)->Quaternion{
        let q:Quaternion = Quaternion()
        let tw = r.m11 + r.m22 + r.m33
        let tx = r.m11 - r.m22 - r.m33
        let ty = r.m22 - r.m11 - r.m33
        let tz = r.m33 - r.m11 - r.m22
        var biggestSquared = tw
        var biggest:Int = 0
        if tx > biggestSquared{
            biggestSquared = tx
            biggest = 1
        }
        if ty > biggestSquared{
            biggestSquared = ty
            biggest = 2
        }
        if tz > biggestSquared{
            biggestSquared = tz
            biggest = 3
        }
        let biggestVal = sqrt(biggestSquared + 1) / 2.0
        let multValue = 0.25 / biggestVal
        switch (biggest){
        case 0:
            q.qW = biggestVal
            q.qX = (r.m32 - r.m23) * multValue
            q.qY = (r.m13 - r.m31) * multValue
            q.qZ = (r.m21 - r.m12) * multValue
        case 1:
            q.qW = (r.m32 - r.m23) * multValue
            q.qX = biggestVal
            q.qY = (r.m12 + r.m21) * multValue
            q.qZ = (r.m31 + r.m13) * multValue
        case 2:
            q.qW = (r.m13 - r.m31) * multValue
            q.qX = (r.m12 + r.m21) * multValue
            q.qY = biggestVal
            q.qZ = (r.m23 + r.m32) * multValue
        case 3:
            q.qW = (r.m21 - r.m12) * multValue
            q.qX = (r.m31 + r.m13) * multValue
            q.qY = (r.m23 + r.m32) * multValue
            q.qZ = biggestVal
        default:
            q.qW = 1
            q.qX = 0
            q.qY = 0
            q.qZ = 0
        }
        return q
    }
    static func quaternionSlerp(quat1 q1:Quaternion, quat2 q2:Quaternion, andT t:Double)->Quaternion{
        // this method is a Swift conversion of coe listing 8.3 of the textbook
        var cosOmega = q1.qW * q2.qW + q1.qX * q2.qX + q1.qY * q2.qY + q1.qZ * q2.qZ
        if cosOmega < 0{
            q2.qW *= -1
            q2.qX *= -1
            q2.qY *= -1
            q2.qZ *= -1
            cosOmega *= -1
        }
        var k0:Double
        var k1:Double
        if cosOmega > 0.9999{
            k0 = 1.0 - t
            k1 = t
        } else {
            let sinOmega = sqrt(1.0 - cosOmega * cosOmega)
            let omega = atan2(sinOmega, cosOmega)
            let oneOverSinOmega = 1.0 / sinOmega
            k0 = sin((1.0 - t) * omega) * oneOverSinOmega
            k1 = sin(t * omega) * oneOverSinOmega
        }
        return Quaternion(qW: q1.qW * k0 + q2.qW * k1, andX: q1.qX * k0 + q2.qX * k1, andY: q1.qY * k0 + q2.qY * k1, andZ: q1.qZ * k0 + q2.qZ * k1)
    }
    
    // MARK: Matrices - Multiplication
    static func multiplyMatrices(matrixA a:Matrix2x2, andMatrixB b:Matrix2x2)->Matrix2x2{
        let p = Matrix2x2()
        p.m11 = a.m11 * b.m11 + a.m12 * b.m21
        p.m12 = a.m11 * b.m12 + a.m12 * b.m22
        p.m21 = a.m21 * b.m11 + a.m22 * b.m21
        p.m22 = a.m21 * b.m12 + a.m22 * b.m22
        return p
    }
    static func scaleMatrix(matrixA a:Matrix2x2, withScale s:Double)->Matrix2x2{
        let sm = Matrix2x2()
        sm.m11 = a.m11 * s
        sm.m12 = a.m12 * s
        sm.m21 = a.m21 * s
        sm.m22 = a.m22 * s
        return sm
    }
    static func multiplyMatrices(matrixA a:Matrix3x3, andMatrixB b:Matrix3x3)->Matrix3x3{
        let p = Matrix3x3()
        p.m11 = a.m11 * b.m11 + a.m12 * b.m21 + a.m13 * b.m31
        p.m12 = a.m11 * b.m12 + a.m12 * b.m22 + a.m13 * b.m32
        p.m13 = a.m11 * b.m13 + a.m12 * b.m23 + a.m13 * b.m33
        p.m21 = a.m21 * b.m11 + a.m22 * b.m21 + a.m23 * b.m31
        p.m22 = a.m21 * b.m12 + a.m22 * b.m22 + a.m23 * b.m32
        p.m23 = a.m21 * b.m13 + a.m22 * b.m23 + a.m23 * b.m33
        p.m31 = a.m31 * b.m11 + a.m32 * b.m21 + a.m33 * b.m31
        p.m32 = a.m31 * b.m12 + a.m32 * b.m22 + a.m33 * b.m32
        p.m33 = a.m31 * b.m13 + a.m32 * b.m23 + a.m33 * b.m33
        return p
    }
    static func scaleMatrix(matrixA a:Matrix3x3, withScale s:Double)->Matrix3x3{
        let sm = Matrix3x3()
        sm.m11 = a.m11 * s
        sm.m12 = a.m12 * s
        sm.m13 = a.m13 * s
        sm.m21 = a.m21 * s
        sm.m22 = a.m22 * s
        sm.m23 = a.m23 * s
        sm.m31 = a.m31 * s
        sm.m32 = a.m32 * s
        sm.m33 = a.m33 * s
        return sm
    }
    static func multiplyMatrices(matrixA a:Matrix3x3, andMatrixB b:Matrix3x1)->Matrix3x1{
        let p = Matrix3x1()
        p.m11 = a.m11 * b.m11 + a.m12 * b.m21 + a.m13 * b.m31
        p.m21 = a.m21 * b.m11 + a.m22 * b.m21 + a.m13 * b.m31
        p.m31 = a.m31 * b.m11 + a.m32 * b.m21 + a.m33 * b.m31
        return p
    }
    static func multiplyMatrices(matrixA a:Matrix4x4, andMatrixB b:Matrix4x4)->Matrix4x4{
        let p = Matrix4x4()
        p.m11 = a.m11 * b.m11 + a.m12 * b.m21 + a.m13 * b.m31 + a.m14 * b.m41
        p.m12 = a.m11 * b.m12 + a.m12 * b.m22 + a.m13 * b.m32 + a.m14 * b.m42
        p.m13 = a.m11 * b.m13 + a.m12 * b.m23 + a.m13 * b.m33 + a.m14 * b.m43
        p.m14 = a.m11 * b.m14 + a.m12 * b.m24 + a.m13 * b.m34 + a.m14 * b.m44
        p.m21 = a.m21 * b.m11 + a.m22 * b.m21 + a.m23 * b.m31 + a.m24 * b.m41
        p.m22 = a.m21 * b.m12 + a.m22 * b.m22 + a.m23 * b.m32 + a.m24 * b.m42
        p.m23 = a.m21 * b.m13 + a.m22 * b.m23 + a.m23 * b.m33 + a.m24 * b.m43
        p.m24 = a.m21 * b.m14 + a.m22 * b.m24 + a.m23 * b.m34 + a.m24 * b.m44
        p.m31 = a.m31 * b.m11 + a.m32 * b.m21 + a.m33 * b.m31 + a.m34 * b.m41
        p.m32 = a.m31 * b.m12 + a.m32 * b.m22 + a.m33 * b.m32 + a.m34 * b.m42
        p.m33 = a.m31 * b.m13 + a.m32 * b.m23 + a.m33 * b.m33 + a.m34 * b.m43
        p.m34 = a.m31 * b.m14 + a.m32 * b.m14 + a.m33 * b.m34 + a.m34 * b.m44
        p.m41 = a.m41 * b.m11 + a.m42 * b.m21 + a.m43 * b.m31 + a.m44 * b.m41
        p.m42 = a.m41 * b.m12 + a.m42 * b.m22 + a.m43 * b.m32 + a.m44 * b.m42
        p.m43 = a.m41 * b.m13 + a.m42 * b.m23 + a.m43 * b.m33 + a.m44 * b.m43
        p.m44 = a.m41 * b.m14 + a.m42 * b.m24 + a.m43 * b.m34 + a.m44 * b.m44
        return p
    }
    static func scaleMatrix(matrixA a:Matrix4x4, withScale s:Double)->Matrix4x4{
        let sm = Matrix4x4()
        sm.m11 = a.m11 * s
        sm.m12 = a.m12 * s
        sm.m13 = a.m13 * s
        sm.m14 = a.m14 * s
        sm.m21 = a.m21 * s
        sm.m22 = a.m22 * s
        sm.m23 = a.m23 * s
        sm.m24 = a.m24 * s
        sm.m31 = a.m31 * s
        sm.m32 = a.m32 * s
        sm.m33 = a.m33 * s
        sm.m34 = a.m34 * s
        sm.m41 = a.m41 * s
        sm.m42 = a.m42 * s
        sm.m43 = a.m43 * s
        sm.m44 = a.m44 * s
        return sm
    }
    static func multiplyMatrices(matrixA a:Matrix4x4, andMatrixB b:Matrix4x1)->Matrix4x1{
        let p = Matrix4x1()
        p.m11 = a.m11 * b.m11 + a.m12 * b.m21 + a.m13 * b.m31 + a.m14 * b.m41
        p.m21 = a.m21 * b.m11 + a.m22 * b.m21 + a.m23 * b.m31 + a.m24 * b.m41
        p.m31 = a.m31 * b.m11 + a.m32 * b.m21 + a.m33 * b.m31 + a.m34 * b.m41
        p.m41 = a.m41 * b.m11 + a.m42 * b.m21 + a.m43 * b.m31 + a.m44 * b.m41
        return p
    }
    
    // MARK: Multiply Vector by Matrix
    static func MultiplyVectorByMatrix(vector v:Vector2D, matrix m:Matrix2x2)->Vector2D{
        return Vector2D(x: m.m11 * v.x + m.m12 * v.y, andY: m.m21 * v.x + m.m22 * v.y)
    }
    static func MultiplyVectorByMatrix(vector v:Vector3D, matrix m:Matrix3x3)->Vector3D{
        return Vector3D(x: m.m11 * v.x + m.m12 * v.y + m.m13 * v.z, andY: m.m21 * v.x + m.m22 * v.y + m.m23 * v.z, andZ: m.m31 * v.x + m.m32 * v.y + m.m33 * v.z)
    }
    static func MultiplyVectorByMatrix(vector v:Vector4D, matrix m:Matrix4x4)->Vector4D{
        return Vector4D(x: m.m11 * v.x + m.m12 * v.y + m.m13 * v.z + m.m14 * v.w,
            andY: m.m21 * v.x + m.m22 * v.y + m.m23 * v.z + m.m24 * v.w,
            andZ: m.m31 * v.x + m.m32 * v.y + m.m33 * v.z + m.m34 * v.w,
            andW: m.m41 * v.x + m.m42 * v.y + m.m43 * v.z + m.m44 * v.w)
    }
    
    // MARK: Matrices - Determinants & Inverses
    static func determinant(matrix a:Matrix2x2)->Double{
        return a.m11 * a.m22 - a.m12 * a.m21
    }
    static func determinant(matrix a:Matrix3x3)->Double{
        let c1 = Matrix2x2(m11: a.m22, andM12: a.m23, andM21: a.m32, andM22: a.m33)
        let c2 = Matrix2x2(m11: a.m21, andM12: a.m23, andM21: a.m31, andM22: a.m33)
        let c3 = Matrix2x2(m11: a.m21, andM12: a.m22, andM21: a.m31, andM22: a.m32)
        return a.m11 * determinant(matrix: c1) - a.m12 * determinant(matrix: c2) + a.m13 * determinant(matrix: c3)
    }
    static func determinant(matrix a:Matrix4x4)->Double{
        let c1 = Matrix3x3(m11: a.m22, andM12: a.m23, andM13: a.m24, andM21: a.m32, andM22: a.m33, andM23: a.m34, andM31: a.m42, andM32: a.m43, andM33: a.m44)
        let c2 = Matrix3x3(m11: a.m21, andM12: a.m23, andM13: a.m24, andM21: a.m31, andM22: a.m33, andM23: a.m34, andM31: a.m41, andM32: a.m43, andM33: a.m44)
        let c3 = Matrix3x3(m11: a.m21, andM12: a.m22, andM13: a.m24, andM21: a.m31, andM22: a.m32, andM23: a.m34, andM31: a.m41, andM32: a.m42, andM33: a.m44)
        let c4 = Matrix3x3(m11: a.m21, andM12: a.m22, andM13: a.m23, andM21: a.m31, andM22: a.m32, andM23: a.m34, andM31: a.m41, andM32: a.m42, andM33: a.m43)
        return a.m11 * determinant(matrix: c1) - a.m12 * determinant(matrix: c2) + a.m13 * determinant(matrix: c3) - a.m14 * determinant(matrix: c4)
    }
    static func inverse(matrix a:Matrix2x2)->Matrix2x2{
        let det = determinant(matrix: a)
        let i = Matrix2x2()
        i.m11 = a.m22 / det
        i.m12 = -1 * a.m12 / det
        i.m21 = -1 * a.m21 / det
        i.m22 = a.m11 / det
        return i
    }
    static func inverse(matrix a:Matrix3x3)->Matrix3x3{
        let det = determinant(matrix: a)
        let i = Matrix3x3()
        let c = Matrix3x3()
        c.m11 = determinant(matrix: Matrix2x2(m11: a.m22, andM12: a.m23, andM21: a.m32, andM22: a.m33))
        c.m12 = determinant(matrix: Matrix2x2(m11: a.m21, andM12: a.m23, andM21: a.m31, andM22: a.m33)) * -1
        c.m13 = determinant(matrix: Matrix2x2(m11: a.m21, andM12: a.m22, andM21: a.m31, andM22: a.m32))
        c.m21 = determinant(matrix: Matrix2x2(m11: a.m12, andM12: a.m13, andM21: a.m32, andM22: a.m33)) * -1
        c.m22 = determinant(matrix: Matrix2x2(m11: a.m11, andM12: a.m13, andM21: a.m31, andM22: a.m33))
        c.m23 = determinant(matrix: Matrix2x2(m11: a.m11, andM12: a.m12, andM21: a.m31, andM22: a.m32)) * -1
        c.m31 = determinant(matrix: Matrix2x2(m11: a.m12, andM12: a.m13, andM21: a.m22, andM22: a.m23))
        c.m32 = determinant(matrix: Matrix2x2(m11: a.m11, andM12: a.m13, andM21: a.m21, andM22: a.m23)) * -1
        c.m33 = determinant(matrix: Matrix2x2(m11: a.m11, andM12: a.m12, andM21: a.m21, andM22: a.m22))
        // matrix c has to be transposed and each cell divided by the determinant
        i.m11 = c.m11 / det
        i.m12 = c.m21 / det
        i.m13 = c.m31 / det
        i.m21 = c.m12 / det
        i.m22 = c.m22 / det
        i.m23 = c.m32 / det
        i.m31 = c.m13 / det
        i.m32 = c.m23 / det
        i.m33 = c.m33 / det
        return i
    }
    static func inverse(matrix a:Matrix4x4)->Matrix4x4{
        let det = determinant(matrix: a)
        let i = Matrix4x4()
        let c = Matrix4x4()
        c.m11 = determinant(matrix: Matrix3x3(m11: a.m22, andM12: a.m23, andM13: a.m24, andM21: a.m32, andM22: a.m33, andM23: a.m34, andM31: a.m42, andM32: a.m43, andM33: a.m44))
        c.m12 = determinant(matrix: Matrix3x3(m11: a.m21, andM12: a.m23, andM13: a.m24, andM21: a.m31, andM22: a.m33, andM23: a.m34, andM31: a.m41, andM32: a.m43, andM33: a.m44)) * -1
        c.m13 = determinant(matrix: Matrix3x3(m11: a.m21, andM12: a.m22, andM13: a.m24, andM21: a.m31, andM22: a.m32, andM23: a.m34, andM31: a.m41, andM32: a.m42, andM33: a.m44))
        c.m14 = determinant(matrix: Matrix3x3(m11: a.m21, andM12: a.m22, andM13: a.m23, andM21: a.m31, andM22: a.m32, andM23: a.m33, andM31: a.m41, andM32: a.m42, andM33: a.m43)) * -1
        c.m21 = determinant(matrix: Matrix3x3(m11: a.m12, andM12: a.m13, andM13: a.m14, andM21: a.m32, andM22: a.m33, andM23: a.m34, andM31: a.m42, andM32: a.m43, andM33: a.m44)) * -1
        c.m22 = determinant(matrix: Matrix3x3(m11: a.m11, andM12: a.m13, andM13: a.m14, andM21: a.m31, andM22: a.m33, andM23: a.m34, andM31: a.m41, andM32: a.m43, andM33: a.m44))
        c.m23 = determinant(matrix: Matrix3x3(m11: a.m11, andM12: a.m12, andM13: a.m14, andM21: a.m31, andM22: a.m32, andM23: a.m34, andM31: a.m41, andM32: a.m42, andM33: a.m44)) * -1
        c.m24 = determinant(matrix: Matrix3x3(m11: a.m11, andM12: a.m12, andM13: a.m13, andM21: a.m31, andM22: a.m32, andM23: a.m33, andM31: a.m41, andM32: a.m42, andM33: a.m43))
        c.m31 = determinant(matrix: Matrix3x3(m11: a.m12, andM12: a.m13, andM13: a.m14, andM21: a.m22, andM22: a.m23, andM23: a.m24, andM31: a.m42, andM32: a.m43, andM33: a.m44))
        c.m32 = determinant(matrix: Matrix3x3(m11: a.m11, andM12: a.m13, andM13: a.m14, andM21: a.m21, andM22: a.m23, andM23: a.m24, andM31: a.m41, andM32: a.m43, andM33: a.m44)) * -1
        c.m33 = determinant(matrix: Matrix3x3(m11: a.m11, andM12: a.m12, andM13: a.m14, andM21: a.m21, andM22: a.m22, andM23: a.m24, andM31: a.m41, andM32: a.m42, andM33: a.m44))
        c.m34 = determinant(matrix: Matrix3x3(m11: a.m11, andM12: a.m12, andM13: a.m13, andM21: a.m21, andM22: a.m22, andM23: a.m23, andM31: a.m41, andM32: a.m42, andM33: a.m43)) * -1
        c.m41 = determinant(matrix: Matrix3x3(m11: a.m12, andM12: a.m13, andM13: a.m14, andM21: a.m22, andM22: a.m23, andM23: a.m24, andM31: a.m32, andM32: a.m33, andM33: a.m34)) * -1
        c.m42 = determinant(matrix: Matrix3x3(m11: a.m11, andM12: a.m13, andM13: a.m14, andM21: a.m21, andM22: a.m23, andM23: a.m24, andM31: a.m31, andM32: a.m33, andM33: a.m34))
        c.m43 = determinant(matrix: Matrix3x3(m11: a.m11, andM12: a.m12, andM13: a.m14, andM21: a.m21, andM22: a.m22, andM23: a.m24, andM31: a.m31, andM32: a.m32, andM33: a.m34)) * -1
        c.m44 = determinant(matrix: Matrix3x3(m11: a.m11, andM12: a.m12, andM13: a.m13, andM21: a.m21, andM22: a.m22, andM23: a.m23, andM31: a.m31, andM32: a.m32, andM33: a.m33))
        // matrix c has to be transposed and each cell divided by the determinant
        i.m11 = c.m11 / det
        i.m12 = c.m21 / det
        i.m13 = c.m31 / det
        i.m14 = c.m41 / det
        i.m21 = c.m12 / det
        i.m22 = c.m22 / det
        i.m23 = c.m32 / det
        i.m24 = c.m42 / det
        i.m31 = c.m13 / det
        i.m32 = c.m23 / det
        i.m33 = c.m33 / det
        i.m34 = c.m43 / det
        i.m41 = c.m14 / det
        i.m42 = c.m24 / det
        i.m43 = c.m34 / det
        i.m44 = c.m44 / det
        return i
    }
    static func transpose(matrix a:Matrix2x2)->Matrix2x2{
        let t = Matrix2x2(m11: a.m11, andM12: a.m21, andM21: a.m12, andM22: a.m22)
        return t
    }
    static func transpose(matrix a:Matrix3x3)->Matrix3x3{
        let t = Matrix3x3(m11: a.m11, andM12: a.m21, andM13: a.m31, andM21: a.m12, andM22: a.m11, andM23: a.m32, andM31: a.m13, andM32: a.m23, andM33: a.m33)
        return t
    }
    static func transpose(matrix a:Matrix4x4)->Matrix4x4{
        let t = Matrix4x4(m11: a.m11, andM12: a.m21, andM13: a.m31, andM14: a.m41, andM21: a.m12, andM22: a.m22, andM23: a.m32, andM24: a.m42, andM31: a.m13, andM32: a.m23, andM33: a.m33, andM34: a.m43, andM41: a.m14, andM42: a.m24, andM43: a.m34, andM44: a.m44)
        return t
    }
    
    // MARK: Matrices - 2D Rotations
    // by default Point2D p should be (0,0)
    static func create2DRotationMatrix(angle degrees:Double, andPoint p:Point2D)->Matrix3x3{
        let rot = Matrix3x3()
        let radians = toRadians(degrees)
        let sine = sin(radians)
        let cosine = cos(radians)
        rot.m11 = cosine
        rot.m12 = sine * -1
        rot.m13 = p.x - p.x * cosine + p.y * sine
        rot.m21 = sine
        rot.m22 = cosine
        rot.m23 = p.y - p.x * sine - p.y * cosine
        rot.m33 = 1
        return rot
    }
    // by default the scale vector should be [1   1]
    // by default the shift vector should be [0   0]
    static func create2DTransformationMatrix(scaleBy scale:Vector2D, andShiftBy shift:Vector2D)->Matrix3x3{
        let t = Matrix3x3()
        t.m11 = scale.x
        t.m22 = scale.y
        t.m13 = shift.x
        t.m23 = shift.y
        t.m33 = 1
        return t
    }
    
    // MARK: Matrices - 3D Rotations
    // by default the scale vector should be [1   1   1]
    // by default the shift vector should be [0   0   0]
    static func create3DTransformationMatrix(scaleBy scale:Vector3D, andShiftBy shift:Vector3D)->Matrix4x4{
        let t = Matrix4x4()
        t.m11 = scale.x
        t.m22 = scale.y
        t.m33 = scale.z
        t.m14 = shift.x
        t.m24 = shift.y
        t.m34 = shift.z
        t.m44 = 1
        return t
    }
    static func createRollMatrix(angle degrees:Double)->Matrix4x4{
        let p = Matrix4x4()
        let radians = toRadians(degrees)
        let sine = sin(radians)
        let cosine = cos(radians)
        p.m11 = cosine
        p.m12 = sine * -1
        p.m21 = sine
        p.m22 = cosine
        p.m33 = 1
        p.m44 = 1
        return p
    }
    static func createYawMatrix(angle degrees:Double)->Matrix4x4{
        let y = Matrix4x4()
        let radians = toRadians(degrees)
        let sine = sin(radians)
        let cosine = cos(radians)
        y.m11 = cosine
        y.m13 = sine
        y.m22 = 1
        y.m31 = sine * -1
        y.m33 = cosine
        y.m44 = 1
        return y
    }
    static func createPitchMatrix(angle degrees:Double)->Matrix4x4{
        let r = Matrix4x4()
        let radians = toRadians(degrees)
        let sine = sin(radians)
        let cosine = cos(radians)
        r.m11 = 1
        r.m22 = cosine
        r.m23 = sine * -1
        r.m32 = sine
        r.m33 = cosine
        r.m44 = 1
        return r
    }
    static func create3DRotationMatrix(rotMatrix rm:Matrix4x4, andPoint p:Point3D)->Matrix4x4{
        let m = Matrix4x4()
        m.m11 = rm.m11
        m.m12 = rm.m12
        m.m13 = rm.m13
        m.m14 = rm.m11 * p.x * -1 + rm.m12 * p.y * -1 + rm.m13 * p.z * -1 + p.x
        m.m21 = rm.m21
        m.m22 = rm.m22
        m.m23 = rm.m23
        m.m24 = rm.m21 * p.x * -1 + rm.m22 * p.y * -1 + rm.m23 * p.z * -1 + p.y
        m.m31 = rm.m31
        m.m32 = rm.m32
        m.m33 = rm.m33
        m.m24 = rm.m31 * p.x * -1 + rm.m32 * p.y * -1 + rm.m33 * p.z * -1 + p.z
        m.m44 = 1
        return m
    }
    static func getEulerAnglesFromMatrix(matrix m:Matrix3x3)->(rollDegrees:Double, pitchDegrees:Double, yawDegrees:Double){
        var roll:Double
        var pitch:Double
        var yaw:Double
        let invSine:Double = m.m32
        if invSine <= -1.0{
            pitch = M_PI / -2.0
        } else if invSine >= 1.0 {
            pitch = M_PI / 2.0
        } else {
            pitch = asin(invSine)
        }
        // check for Gimbal Lock
        if abs(invSine) > 0.9999{
            roll = 0.0
            yaw = atan2(m.m13, m.m22)
        } else {
            yaw = atan2(m.m31 * -1, m.m33)
            roll = atan2(m.m12 * -1, m.m22)
        }
        return (self.toDegrees(roll), self.toDegrees(pitch), self.toDegrees(yaw))
    }
    static func rotateAboutArbitraryAxis(vector n:Vector3D, andTheta theta:Double)->Matrix4x4{
        let nN = self.normalize(vector: n)
        let radians = self.toRadians(theta)
        let c = cos(radians)
        let s = sin(radians)
        let cM1 = 1 - c
        return Matrix4x4(m11: nN.x * nN.x * cM1 + c, andM12: nN.x * nN.y * cM1 - nN.z * s, andM13: nN.x * nN.z * cM1 + nN.y * s, andM14: 0,
            andM21: nN.x * nN.y * cM1 + nN.z * s, andM22: nN.y * nN.y * cM1 + c, andM23: nN.y * nN.z * cM1 - nN.x * s, andM24: 0,
            andM31: nN.x * nN.z * cM1 - nN.y * s, andM32: nN.y * nN.z * cM1 + nN.x * s, andM33: nN.z * nN.z * cM1 + c, andM34: 0,
            andM41: 0, andM42: 0, andM43: 0, andM44: 1)
    }
    
    // MARK: Linear Motion
    static func calculateForce(mass m:Double, andA a:Vector2D)->Vector2D{
        return self.scaleVector(vectA: a, andScale: m)
    }
    static func calculateForce(mass m:Double, andA a:Vector3D)->Vector3D{
        return self.scaleVector(vectA: a, andScale: m)
    }
    static func calculateDisplacement(initialV vI:Vector2D, andA a:Vector2D, andT t:Double)->Vector2D{
        let deltaD = Vector2D()
        deltaD.x = vI.x * t + 0.5 * a.x * t * t
        deltaD.y = vI.y * t + 0.5 * a.y * t * t
        return deltaD
    }
    static func calculateDisplacement(initialV vI:Vector3D, andA a:Vector3D, andT t:Double)->Vector3D{
        let deltaD = Vector3D()
        deltaD.x = vI.x * t + 0.5 * a.x * t * t
        deltaD.y = vI.y * t + 0.5 * a.y * t * t
        deltaD.z = vI.z * t + 0.5 * a.z * t * t
        return deltaD
    }
    static func calculateFinalVelocity(initialV vI:Vector2D, andA a:Vector2D, andT t:Double)->Vector2D{
        let vF = Vector2D()
        vF.x = vI.x + a.x * t
        vF.y = vI.y + a.y * t
        return vF
    }
    static func calculateFinalVelocity(initialV vI:Vector3D, andA a:Vector3D, andT t:Double)->Vector3D{
        let vF = Vector3D()
        vF.x = vI.x + a.x * t
        vF.y = vI.y + a.y * t
        vF.z = vI.z + a.z * t
        return vF
    }
    
    // MARK: Rotational Motion
    static func calculateAngularVelocity(_ rpm:Double)->Double{
        return (rpm / 60) * 2 * M_PI
    }
    static func calculateAngularVelocity(_ angle:Double, andTime time:Double)->Double{
        return angle / time
    }
    static func calculateTangentialVelocity(angle omega:Double, andRadius r:Double)->Double{
        return omega * r
    }
    static func calculateAngularAcceleration1(radius r:Double, andOmega omega:Double)->Double{
        return r * omega * omega
    }
    static func calculateAngularAcceleration2(_ omega:Double, andTime t:Double)->Double{
        return omega / t
    }
    static func calculateAngularDisplacement( _ arc:Double, andRadius r:Double)->(radians:Double, degrees:Double){
        let theta = arc / r
        return (theta, self.toDegrees(theta))
    }
    
    // MARK: Linear Kinematics
//    static func calculateNetForce(force:Force2D)->(weight:Vector2D, forceNormal:Vector2D, maxFriction:Vector2D, netForce:Vector2D, acceleration:Vector2D){
//        let weight = scaleVector(vectA: force.g, andScale: force.m)
//        let componentWeight = Vector2D(x: weight.y * cos(force.rampRadians), andY: weight.y * sin(force.rampRadians))
//        let forceNormal = Vector2D(x: 0, andY: -1 * (weight.x + force.appliedForce.y))
//        var maxFriction = Vector2D(x: forceNormal.y * force.mu * -1, andY: 0)
//        var netForce = Vector2D()
//        if componentWeight.y < 0 && (componentWeight.y + force.appliedForce.x < 0){
//            maxFriction.x *= -1
//        }
//        netForce = addVector(vectA: addVector(vectA: componentWeight, vectB: forceNormal), vectB: addVector(vectA: maxFriction, vectB: force.appliedForce))
//        if netForce.x < 0 && force.rampRadians == 0 || (abs(componentWeight.y + force.appliedForce.x) <= abs(maxFriction.x)){
//            netForce.x = 0
//        }
//        let acceleration = scaleVector(vectA: netForce, andScale: 1 / force.m)
//        return (weight, forceNormal, maxFriction, netForce, acceleration)
//    }
//    static func calculateNetForce(force:Force3D)->(weight:Vector3D, forceNormal:Vector3D, maxFriction:Vector3D, netForce:Vector3D, acceleration:Vector3D){
//        let weight = scaleVector(vectA: force.g, andScale: force.m)
//        let forceNormal = scaleVector(vectA: weight, andScale: -1)
//        let maxFriction = Vector3D(x: forceNormal.y * force.mu * -1, andY: 0, andZ: forceNormal.y * force.mu * -1)
//        var netForce = Vector3D()
//        if maxFriction.magnitude < force.appliedForce.magnitude{
//            netForce = addVector(vectA: addVector(vectA: weight, vectB: forceNormal), vectB: addVector(vectA: maxFriction, vectB: force.appliedForce))
//        }
//        let acceleration = scaleVector(vectA: netForce, andScale: 1 / force.m)
//        return (weight, forceNormal, maxFriction, netForce, acceleration)
//    }
    
    // MARK: Collisions
    static func circleCenterDistance(_ a:Circle, b:Circle)->Double
    {
        return sqrt(pow(b.h - a.h, 2) + pow(b.k - a.k, 2))
    }
    
    static func circleCollision(_ a:Circle, b:Circle, aVi:Vector2D, bVi:Vector2D, mA:Double, mB:Double)-> (aVf:Vector2D, bVf:Vector2D)
    {
        let aCenter = Vector2D(x: a.h, andY: a.k)
        let bCenter = Vector2D(x: b.h, andY: b.k)
        let n = normalize(vector: subtractVector(vectA: aCenter, minusVectB: bCenter))
        let a1 = dotProduct(vectA: aVi, vectB: n)
        let a2 = dotProduct(vectA: bVi, vectB: n)
        let optP = (2.0 * (a1 - a2)) / (mA + mB)
        let aVf = subtractVector(vectA: aVi, minusVectB: scaleVector(vectA: n, andScale: optP * mB))
        let bVf = addVector(vectA: bVi, vectB: scaleVector(vectA: n, andScale: optP * mA))
        return (aVf, bVf)
    }
    
    static func sphereCenterDistance(_ a:Sphere, b:Sphere)->Double
    {
        return sqrt(pow(b.h - a.h, 2) + pow(b.k - a.k, 2) + pow(b.l - a.l, 2))
    }
    
    static func sphereCollision(_ a:Sphere, b:Sphere, aVi:Vector3D, bVi:Vector3D, mA:Double, mB:Double)-> (aVf:Vector3D, bVf:Vector3D)
    {
        let aCenter = Vector3D(x: a.h, andY: a.k, andZ: a.l)
        let bCenter = Vector3D(x: b.h, andY: b.k, andZ: b.l)
        let n = normalize(vector: subtractVector(vectA: aCenter, minusVectB: bCenter))
        let a1 = dotProduct(vectA: aVi, vectB: n)
        let a2 = dotProduct(vectA: bVi, vectB: n)
        let optP = (2.0 * (a1 - a2)) / (mA + mB)
        let aVf = subtractVector(vectA: aVi, minusVectB: scaleVector(vectA: n, andScale: optP * mB))
        let bVf = addVector(vectA: bVi, vectB: scaleVector(vectA: n, andScale: optP * mA))
        return (aVf, bVf)
    }
    
    // MARK: Rotational Kinematics
    
    // MARK: 3D Curves
    
    // MARK: Universal Gravitation
    static func calculateGravitationalForce( _ mass1: Double, mass2: Double, d: Double)->Double
    {
        return G * mass1 * mass2 / (d * d)
    }
    
    static func calculateGravity(_ mass: Double, radius:Double)->Double
    {
        return G * mass / (radius * radius)
    }
    
}
