//
//  Vector2D.swift
//  MathPhysicsCalculator
//
//  Created by Allan Anderson on 2015-Apr-23.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import Foundation

open class Vector2D{
    // MARK: Properties
    var x:Double
    var y:Double
    var magnitude:Double
    
    // MARK: Init
    init(){
        x = 0
        y = 0
        magnitude = 0
    }
    init(x:Double, andY y:Double){
        self.x = x
        self.y = y
        self.magnitude = sqrt(x * x + y * y)
    }
    init(p:PolarVector){
        x = p.x
        y = p.y
        magnitude = p.magnitude
    }
}
