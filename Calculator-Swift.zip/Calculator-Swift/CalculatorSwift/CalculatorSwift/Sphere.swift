//
//  Sphere.swift
//  MathPhysicsCalculator
//
//  Created by Allan Anderson on 2016-Mar-30.
//  Copyright © 2016 Allan Anderson. All rights reserved.
//

import Foundation

open class Sphere{
    // MARK: Properties
    var h:Double
    var k:Double
    var l:Double
    var r:Double
    // MARK: init
    init(){
        h = 0
        k = 0
        l = 0
        r = 0
    }
    init(h:Double, k:Double, l:Double, r:Double){
        self.h = h
        self.k = k
        self.l = l
        self.r = r
    }
}

