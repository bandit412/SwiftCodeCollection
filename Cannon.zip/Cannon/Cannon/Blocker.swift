//
//  Blocker.swift
//  Cannon
//
//  Created by Allan Anderson on 2015-Feb-12.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import SpriteKit
import AVFoundation

// enum for different size of Blockers
enum BlockerSize: CGFloat{
    case Small = 1.0
    case Medium = 2.0
    case Large = 3.0
}

class Blocker: SKSpriteNode {
   // constants for configuring a blocker
    private let blockerWidthPercentage = CGFloat(0.025)
    private let blocketHeightPercentage = CGFloat(0.125)
    private let blockerSpeed = CGFloat(5.0)
    private let blockerSize: BlockerSize
    
    // initializer
    init(sceneSize: CGSize, blockerSize: BlockerSize){
        self.blockerSize = blockerSize // done here to initialize the blockerSize property before the super.init() & prevent complie errors
        super.init(texture: SKTexture(imageNamed: "blocker"), color: nil, size: CGSizeMake(sceneSize.width * blockerWidthPercentage, sceneSize.height * blocketHeightPercentage * blockerSize.rawValue))
        // setup blockers physicsBody properties
        self.physicsBody = SKPhysicsBody(texture: self.texture, size: self.size)
        self.physicsBody?.friction = 0.0 // no friction
        self.physicsBody?.restitution = 1.0 // perfectly elastic
        self.physicsBody?.linearDamping = 0.0 // no air resistance
        self.physicsBody?.allowsRotation = true // object can rotate
        self.physicsBody?.usesPreciseCollisionDetection = true // needed for fast moving objects
        self.physicsBody?.categoryBitMask = CollisionCategory.Blocker
        self.physicsBody?.contactTestBitMask = CollisionCategory.Cannonball
    }
    
    // not called bu required if subclass defines an init()
    required init?(coder aDecoder: NSCoder){
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - StartMoving
    // applies impulse to the blocker
    func startMoving(velocityMultiplier: CGFloat){
        self.physicsBody?.applyImpulse(CGVectorMake(0.0, velocityMultiplier * blockerSpeed * blockerSize.rawValue))
    }
    
    // MARK: - PlayHitSound
    // plays the blocker hit
    func playHitSound(){
        blockerHitSound.play()
    }
    
    // MARK: - BlockerTimePenalty
    // returns time penalty based on blocker size
    func blockerTimePenalty() -> CFTimeInterval{
        return CFTimeInterval(BlockerSize.Small.rawValue)
    }
}
