//
//  GameViewController.swift
//  Cannon
//
//  Created by Allan Anderson on 2015-Feb-12.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import UIKit
import SpriteKit
import AVFoundation

// predefined sounds
var blockerHitSound: AVAudioPlayer!
var targetHitSound: AVAudioPlayer!
var cannonFireSound: AVAudioPlayer!

// the extension is removed as it will be generated programmtically
/*
extension SKNode {
    class func unarchiveFromFile(file : NSString) -> SKNode? {
        if let path = NSBundle.mainBundle().pathForResource(file, ofType: "sks") {
            var sceneData = NSData(contentsOfFile: path, options: .DataReadingMappedIfSafe, error: nil)!
            var archiver = NSKeyedUnarchiver(forReadingWithData: sceneData)
            
            archiver.setClass(self.classForKeyedUnarchiver(), forClassName: "SKScene")
            let scene = archiver.decodeObjectForKey(NSKeyedArchiveRootObjectKey) as GameScene
            archiver.finishDecoding()
            return scene
        } else {
            return nil
        }
    }
}
*/

class GameViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // load sounds
        blockerHitSound = AVAudioPlayer(contentsOfURL: NSURL(fileURLWithPath: NSBundle.mainBundle().pathForResource("blocker_hit", ofType: "wav")!), error: nil)
        targetHitSound = AVAudioPlayer(contentsOfURL: NSURL(fileURLWithPath: NSBundle.mainBundle().pathForResource("target_hit", ofType: "wav")!), error: nil)
        cannonFireSound = AVAudioPlayer(contentsOfURL: NSURL(fileURLWithPath: NSBundle.mainBundle().pathForResource("cannon_fire", ofType: "wav")!), error: nil)
        // programmtically create the scene
        let scene = GameScene(size: view.bounds.size) // create the scene but the signature does not appear by default
        scene.scaleMode = .AspectFill
        // create the SKView
        let skView = view as SKView
        skView.showsFPS = true
        skView.showsNodeCount = true
        skView.ignoresSiblingOrder = true // for SpriteKit optimization
        skView.presentScene(scene)
    }

    // the following methods are not necessary
    /*
    override func shouldAutorotate() -> Bool {
        return true // change this to false to prevent rotation of the game
    }

    override func supportedInterfaceOrientations() -> Int {
        if UIDevice.currentDevice().userInterfaceIdiom == .Phone {
            return Int(UIInterfaceOrientationMask.AllButUpsideDown.rawValue)
        } else {
            return Int(UIInterfaceOrientationMask.All.rawValue)
        }
    }
    
    override func prefersStatusBarHidden() -> Bool {
        return true
    }
    */

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Release any cached data, images, etc that aren't in use.
    }

    
}
