//
//  Cannon.swift
//  Cannon
//
//  Created by Allan Anderson on 2015-Feb-12.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import SpriteKit
import AVFoundation

class Cannon: SKNode {
   // constants
    private let cannonSizePercent = CGFloat(0.15)
    private let cannonballSizePercent = CGFloat(0.075)
    private let cannonbarrelWidthPercent = CGFloat(0.075)
    private let cannonBarrelLengthPercent = CGFloat(0.15)
    private let cannonballSpeed: CGFloat
    private let cannonballSpeedMultiplier = CGFloat(0.25)
    private let barrelLength :CGFloat
    private var barrelAngle = CGFloat(0.0)
    private var cannonball: SKSpriteNode!
    var cannonballOnScreen = false
    
    init(sceneSize : CGSize, velocityMultipler: CGFloat){
        cannonballSpeed = cannonballSpeedMultiplier * velocityMultipler
        barrelLength = sceneSize.height * cannonBarrelLengthPercent
        
        super.init()
        
        // configure cannon barrel
        let barrel = SKShapeNode(rectOfSize: CGSizeMake(barrelLength, sceneSize.height * cannonbarrelWidthPercent))
        barrel.fillColor = SKColor.blackColor()
        self.addChild(barrel)
        
        // configure the cannon base
        var cannonBase = SKSpriteNode(imageNamed: "base")
        cannonBase.size = CGSizeMake(sceneSize.height * cannonSizePercent, sceneSize.height * cannonSizePercent)
        self.addChild(cannonBase)
        
        // position the barrel
        barrel.position = CGPointMake(cannonBase.size.width / 2.0, 0.0)
    }
    
    // not called bu required if subclass defines an init()
    required init?(coder aDecoder: NSCoder){
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - RotateToPointAndFire
    func rotateToPointAndFire(point: CGPoint, scene: SKScene){
        // calculate barrel rotation angle
        let deltaX = point.x
        let deltaY = point.y - self.position.y
        barrelAngle = CGFloat(atan2(Float(deltaY), Float(deltaX)))
        // rotate the barrel to touch point, then fire
        let rotateAction = SKAction.rotateToAngle(barrelAngle, duration: 0.25, shortestUnitArc: true)
        // perform action, then call fireCannonball()
        self.runAction(rotateAction, completion: {
            if !self.cannonballOnScreen{
                self.fireCannonball(scene)
            }
        })
    }
    
    // MARK: - FireCannonball
    func fireCannonball(scene: SKScene){
        cannonballOnScreen = true
        // determine starting point for cannonball based on barrel length and current barrel angle
        let x = cos(barrelAngle) * barrelLength
        let y = sin(barrelAngle) * barrelLength
        let cannonball = createCannonball(scene.frame.size)
        cannonball.position = CGPointMake(x, self.position.y + y)
        // create based on barrel angle
        let velocityVector = CGVectorMake(x * cannonballSpeed, y * cannonballSpeed)
        // put the cannonball on screen, move it, and play fire sound
        scene.addChild(cannonball)
        cannonball.physicsBody?.applyImpulse(velocityVector)
        cannonFireSound.play()
    }
    
    // MARK: - CreateCannonball
    func createCannonball(sceneSize: CGSize) -> SKSpriteNode{
        cannonball = SKSpriteNode(imageNamed: "ball")
        cannonball.size = CGSizeMake(sceneSize.height * cannonballSizePercent, sceneSize.height * cannonballSizePercent)
        // setup physicsBody
        cannonball.physicsBody = SKPhysicsBody(circleOfRadius: cannonball.size.width / 2.0)
        cannonball.physicsBody?.friction = 0.0
        cannonball.physicsBody?.restitution = 1.0
        cannonball.physicsBody?.linearDamping = 0.0
        cannonball.physicsBody?.allowsRotation = true
        cannonball.physicsBody?.usesPreciseCollisionDetection = true
        cannonball.physicsBody?.categoryBitMask = CollisionCategory.Cannonball
        cannonball.physicsBody?.contactTestBitMask = CollisionCategory.Target | CollisionCategory.Blocker | CollisionCategory.Wall
        return cannonball
    }
}
