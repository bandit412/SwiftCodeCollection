//
//  GameOverScene.swift
//  Cannon
//
//  Created by Allan Anderson on 2015-Feb-12.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import SpriteKit

class GameOverScene: SKScene {
    // configure the GameOverScene
    init(size: CGSize, won: Bool, time: CFTimeInterval){
        super.init(size: size)
        self.backgroundColor = SKColor.whiteColor()
        let greenColor = SKColor(red: 0.0, green: 0.6, blue: 0.0, alpha: 1.0)
        let gameOverLabel = SKLabelNode(fontNamed: "Chalkduster")
        gameOverLabel.text = (won ? "You Win!" : "You Lost")
        gameOverLabel.fontSize = 60
        gameOverLabel.fontColor = (won ? greenColor : SKColor.redColor())
        gameOverLabel.position.x = size.width / 2.0
        gameOverLabel.position.y = size.height / 2.0 + gameOverLabel.fontSize
        self.addChild(gameOverLabel)
        
        let elapstedTimeLabel = SKLabelNode(fontNamed: "Chalkduster")
        elapstedTimeLabel.text = String(format: "Elapsed Time: %.1f seconds",time)
        elapstedTimeLabel.fontSize = 24
        elapstedTimeLabel.fontColor = SKColor.blueColor()
        elapstedTimeLabel.position.x = size.width / 2.0
        elapstedTimeLabel.position.y = size.height / 2.0
        self.addChild(elapstedTimeLabel)
        
        let newGameLabel = SKLabelNode(fontNamed: "Chalkduster")
        newGameLabel.text = "Begin New Game"
        newGameLabel.fontSize = 24
        newGameLabel.fontColor = greenColor
        newGameLabel.position.x = size.width / 2.0
        newGameLabel.position.y = size.height / 2.0 - gameOverLabel.fontSize
        self.addChild(newGameLabel)
    }
    
    // not called bu required if subclass defines an init()
    required init?(coder aDecoder: NSCoder){
        fatalError("init(coder:) has not been implemented")
    }
    
    override func touchesBegan(touches: NSSet, withEvent event: UIEvent) {
        let doorTransition = SKTransition.doorsOpenHorizontalWithDuration(1.0)
        let scene = GameScene(size: self.size)
        scene.scaleMode = .AspectFill
        self.view?.presentScene(scene, transition: doorTransition)
    }
}
