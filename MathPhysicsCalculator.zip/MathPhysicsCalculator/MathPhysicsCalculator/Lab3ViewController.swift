//
//  Lab3ViewController.swift
//  MathPhysicsCalculator
//
//  Created by Allan Anderson on 2015-May-08.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import UIKit

class Lab3ViewController: UIViewController {

    @IBOutlet var vcLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        if let label = self.vcLabel {
            label.text = "Lab 3"
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
