//
//  VectorData.swift
//  MathPhysicsCalculator
//
//  Created by Allan Anderson on 2015-May-08.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import Foundation
import UIKit

open class VectorData{
    var entry1: String
    var output: String
    
    init(){
        entry1 = ""
        output = ""
    }
    
    init(entry1: String, and output:String){
        self.entry1 = entry1
        self.output = output
    }
}
