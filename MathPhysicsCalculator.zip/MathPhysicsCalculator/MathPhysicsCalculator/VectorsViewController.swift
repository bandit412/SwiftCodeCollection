//
//  VectorsViewController.swift
//  MathPhysicsCalculator
//
//  Created by Allan Anderson on 2015-May-06.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import UIKit

class VectorsViewController: UIViewController {
    
    // MARK: 2D Vectors
    @IBOutlet var vcLabel: UILabel!
    @IBOutlet var tf_Ax: UITextField!
    @IBOutlet var tf_Ay: UITextField!
    @IBOutlet var tf_Bx: UITextField!
    @IBOutlet var tf_By: UITextField!
    @IBOutlet var tf_ABx: UITextField!
    @IBOutlet var tf_ABy: UITextField!
    @IBOutlet var tf_scale: UITextField!
    @IBOutlet var tf_AminusBx: UITextField!
    @IBOutlet var tf_AminusBy: UITextField!
    @IBOutlet var tf_BminusAx: UITextField!
    @IBOutlet var tf_BminusAy: UITextField!
    @IBOutlet var tf_sAx: UITextField!
    @IBOutlet var tf_sAy: UITextField!
    @IBOutlet var tf_sBx: UITextField!
    @IBOutlet var tf_sBy: UITextField!
    @IBOutlet var btn_export: UIButton!
    @IBOutlet var tf_dotP: UITextField!
    @IBOutlet var tf_magA: UITextField!
    @IBOutlet var tf_magB: UITextField!
    @IBOutlet var tf_normAx: UITextField!
    @IBOutlet var tf_normAy: UITextField!
    @IBOutlet var tf_normBx: UITextField!
    @IBOutlet var tf_normBy: UITextField!
    @IBOutlet var tf_thetaDeg: UITextField!
    @IBOutlet var tf_thetaRad: UITextField!
    
    @IBAction func btn_Calculate(_ sender: UIButton) {
        let s = (tf_scale.text! as NSString).doubleValue
        let A : Vector2D = Vector2D(x: (tf_Ax.text! as NSString).doubleValue, andY: (tf_Ay.text! as NSString).doubleValue)
        let B : Vector2D = Vector2D(x: (tf_Bx.text! as NSString).doubleValue, andY: (tf_By.text! as NSString).doubleValue)
        let AB = Calculator.addVector(vectA: A, vectB: B)
        let aMinusB = Calculator.subtractVector(vectA: A, minusVectB: B)
        let bMinusA = Calculator.subtractVector(vectA: B, minusVectB: A)
        let sA = Calculator.scaleVector(vectA: A, andScale: s)
        let sB = Calculator.scaleVector(vectA: B, andScale: s)
        let normA = Calculator.normalize(vector: A)
        let normB = Calculator.normalize(vector: B)
        let dotP = Calculator.dotProduct(vectA: A, vectB: B)
        let radians = Calculator.angleBetweenVector(vectA: A, andVectB: B)
        let degrees = Calculator.toDegrees(radians)
        tf_ABx.text = ("\(AB.x)")
        tf_ABy.text = ("\(AB.y)")
        tf_AminusBx.text = ("\(aMinusB.x)")
        tf_AminusBy.text = ("\(aMinusB.y)")
        tf_BminusAx.text = ("\(bMinusA.x)")
        tf_BminusAy.text = ("\(bMinusA.y)")
        tf_sAx.text = ("\(sA.x)")
        tf_sAy.text = ("\(sA.y)")
        tf_sBx.text = ("\(sB.x)")
        tf_sBy.text = ("\(sB.y)")
        tf_magA.text = ("\(round(100000 * A.magnitude) / 100000)")
        tf_magB.text = ("\(round(100000 * B.magnitude) / 100000)")
        tf_normAx.text = ("\(round(100000 * normA.x) / 100000)")
        tf_normAy.text = ("\(round(100000 * normA.y) / 100000)")
        tf_normBx.text = ("\(round(100000 * normB.x) / 100000)")
        tf_normBy.text = ("\(round(100000 * normB.y) / 10000)")
        tf_dotP.text = ("\(round(100000 * dotP) / 100000)")
        tf_thetaDeg.text = ("\(round(100000 * degrees) / 100000)")
        tf_thetaRad.text = ("\(round(100000 * radians) / 100000)")
        btn_export.isEnabled = true
    }
    
    @IBAction func btn_Reset(_ sender: UIButton) {
        tf_ABx.text = ""
        tf_ABy.text = ""
        tf_AminusBx.text = ""
        tf_AminusBy.text = ""
        tf_BminusAx.text = ""
        tf_BminusAy.text = ""
        tf_sAx.text = ""
        tf_sAy.text = ""
        tf_sBx.text = ""
        tf_sBy.text = ""
        tf_magA.text = ""
        tf_magB.text = ""
        tf_normAx.text = ""
        tf_normAy.text = ""
        tf_normBx.text = ""
        tf_normBy.text = ""
        tf_dotP.text = ""
        tf_thetaDeg.text = ""
        tf_thetaRad.text = ""
        tf_Ax.text = "0"
        tf_Ay.text = "0"
        tf_Bx.text = "0"
        tf_By.text = "0"
        tf_scale.text = "1"
        btn_export.isEnabled = false
    }
    
    @IBAction func btn_Export(_ sender: UIButton) {
        
    }
    
    // MARK: 3D Vectors
    @IBOutlet var vc3D_label: UILabel!
    @IBOutlet var tf_Ax3D: UITextField!
    @IBOutlet var tf_Ay3D: UITextField!
    @IBOutlet var tf_Az3D: UITextField!
    @IBOutlet var tf_Bx3D: UITextField!
    @IBOutlet var tf_By3D: UITextField!
    @IBOutlet var tf_Bz3D: UITextField!
    @IBOutlet var tf_scale3D: UITextField!
    @IBOutlet var tf_ABx3D: UITextField!
    @IBOutlet var tf_ABy3D: UITextField!
    @IBOutlet var tf_ABz3D: UITextField!
    @IBOutlet var tf_dot3D: UITextField!
    @IBOutlet var tf_AminusBx3D: UITextField!
    @IBOutlet var tf_AminusBy3D: UITextField!
    @IBOutlet var tf_AminusBz3D: UITextField!
    @IBOutlet var tf_BminusAx3D: UITextField!
    @IBOutlet var tf_BminusAy3D: UITextField!
    @IBOutlet var tf_BminusAz3D: UITextField!
    @IBOutlet var tf_sAx3D: UITextField!
    @IBOutlet var tf_sAy3D: UITextField!
    @IBOutlet var tf_sAz3D: UITextField!
    @IBOutlet var tf_sBx3D: UITextField!
    @IBOutlet var tf_sBy3D: UITextField!
    @IBOutlet var tf_sBz3D: UITextField!
    @IBOutlet var tf_magA3D: UITextField!
    @IBOutlet var tf_magB3D: UITextField!
    @IBOutlet var tf_normAx3D: UITextField!
    @IBOutlet var tf_normAy3D: UITextField!
    @IBOutlet var tf_normAz3D: UITextField!
    @IBOutlet var tf_normBx3D: UITextField!
    @IBOutlet var tf_normBy3D: UITextField!
    @IBOutlet var tf_normBz3D: UITextField!
    @IBOutlet var tf_thetaDeg3D: UITextField!
    @IBOutlet var tf_thetaRad3D: UITextField!
    @IBOutlet var tf_crossABx: UITextField!
    @IBOutlet var tf_crossABy: UITextField!
    @IBOutlet var tf_crossABz: UITextField!
    @IBOutlet var tf_crossBAx: UITextField!
    @IBOutlet var tf_crossBAy: UITextField!
    @IBOutlet var tf_crossBAz: UITextField!
    @IBOutlet var btn_export3D: UIButton!

    @IBAction func btn_calc3D(_ sender: UIButton) {
        let s = (tf_scale3D.text! as NSString).doubleValue
        let A = Vector3D(x: (tf_Ax3D.text! as NSString).doubleValue, andY: (tf_Ay3D.text! as NSString).doubleValue, andZ: (tf_Az3D.text! as NSString).doubleValue)
        let B = Vector3D(x: (tf_Bx3D.text! as NSString).doubleValue, andY: (tf_By3D.text! as NSString).doubleValue, andZ: (tf_Bz3D.text! as NSString).doubleValue)
        let AB = Calculator.addVector(vectA: A, vectB: B)
        let AminusB = Calculator.subtractVector(vectA: A, minusVectB: B)
        let BminusA = Calculator.subtractVector(vectA: B, minusVectB: A)
        let sA = Calculator.scaleVector(vectA: A, andScale: s)
        let sB = Calculator.scaleVector(vectA: B, andScale: s)
        let normA = Calculator.normalize(vector: A)
        let normB = Calculator.normalize(vector: B)
        let dotP = Calculator.dotProduct(vectA: A, vectB: B)
        let radians = Calculator.angleBetweenVector(vectA: A, andVectB: B)
        let degrees = Calculator.toDegrees(radians)
        let AcrossB = Calculator.crossProduct(vectA: A, vectB: B)
        let BcrossA = Calculator.crossProduct(vectA: B, vectB: A)
        tf_ABx3D.text = ("\(AB.x)")
        tf_ABy3D.text = ("\(AB.y)")
        tf_ABz3D.text = ("\(AB.z)")
        tf_AminusBx3D.text = ("\(AminusB.x)")
        tf_AminusBy3D.text = ("\(AminusB.x)")
        tf_AminusBz3D.text = ("\(AminusB.x)")
        tf_BminusAx3D.text = ("\(BminusA.x)")
        tf_BminusAy3D.text = ("\(BminusA.x)")
        tf_BminusAz3D.text = ("\(BminusA.x)")
        tf_sAx3D.text = ("\(sA.x)")
        tf_sAy3D.text = ("\(sA.y)")
        tf_sAz3D.text = ("\(sA.z)")
        tf_sBx3D.text = ("\(sB.x)")
        tf_sBy3D.text = ("\(sB.y)")
        tf_sBz3D.text = ("\(sB.z)")
        tf_dot3D.text = ("\(round(100000 * dotP) / 100000)")
        tf_magA3D.text = ("\(round(100000 * A.magnitude) / 100000)")
        tf_magB3D.text = ("\(round(100000 * B.magnitude) / 100000)")
        tf_normAx3D.text = ("\(round(100000 * normA.x) / 100000)")
        tf_normAy3D.text = ("\(round(100000 * normA.y) / 100000)")
        tf_normAz3D.text = ("\(round(100000 * normA.z) / 100000)")
        tf_normBx3D.text = ("\(round(100000 * normB.x) / 100000)")
        tf_normBy3D.text = ("\(round(100000 * normB.y) / 100000)")
        tf_normBz3D.text = ("\(round(100000 * normB.z) / 100000)")
        tf_thetaDeg3D.text = ("\(round(100000 * degrees) / 100000)")
        tf_thetaRad3D.text = ("\(round(100000 * radians) / 100000)")
        tf_crossABx.text = ("\(round(100000 * AcrossB.x) / 100000)")
        tf_crossABy.text = ("\(round(100000 * AcrossB.y) / 100000)")
        tf_crossABz.text = ("\(round(100000 * AcrossB.z) / 100000)")
        tf_crossBAx.text = ("\(round(100000 * BcrossA.x) / 100000)")
        tf_crossBAy.text = ("\(round(100000 * BcrossA.y) / 100000)")
        tf_crossBAz.text = ("\(round(100000 * BcrossA.z) / 100000)")
        btn_export3D.isEnabled = true
    }
 
    @IBAction func btn_reset3D(_ sender: UIButton) {
        tf_Ax3D.text = "0"
        tf_Ay3D.text = "0"
        tf_Az3D.text = "0"
        tf_Bx3D.text = "0"
        tf_By3D.text = "0"
        tf_Bz3D.text = "0"
        tf_scale3D.text = "1"
        tf_ABx3D.text = ""
        tf_ABy3D.text = ""
        tf_ABz3D.text = ""
        tf_AminusBx3D.text = ""
        tf_AminusBy3D.text = ""
        tf_AminusBz3D.text = ""
        tf_BminusAx3D.text = ""
        tf_BminusAy3D.text = ""
        tf_BminusAz3D.text = ""
        tf_dot3D.text = ""
        tf_magA3D.text = ""
        tf_magB3D.text = ""
        tf_normAx3D.text = ""
        tf_normAy3D.text = ""
        tf_normAz3D.text = ""
        tf_normBx3D.text = ""
        tf_normBy3D.text = ""
        tf_normBz3D.text = ""
        tf_thetaDeg3D.text = ""
        tf_thetaRad3D.text = ""
        tf_crossABx.text = ""
        tf_crossABy.text = ""
        tf_crossABz.text = ""
        tf_crossBAx.text = ""
        tf_crossBAy.text = ""
        tf_crossBAz.text = ""
        btn_export3D.isEnabled = false
    }
    
    @IBAction func btn_export3D(_ sender: UIButton) {
        
    }
    
    
    // MARK: Common
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using segue.destinationViewController.
    // Pass the selected object to the new view controller.
    }
    */
    
}
