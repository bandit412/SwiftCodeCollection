//
//  MatricesViewController.swift
//  MathPhysicsCalculator
//
//  Created by Allan Anderson on 2015-May-06.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import UIKit

class MatricesViewController: UIViewController, UIScrollViewDelegate {

    @IBOutlet var scrollView: UIScrollView!
    @IBOutlet var contentView: UIView!
    
    // MARK: 2x2 Matrices
    @IBOutlet var vcLabel: UILabel!
    @IBOutlet var tf_A_M11_2x2: UITextField!
    @IBOutlet var tf_A_M12_2x2: UITextField!
    @IBOutlet var tf_A_M21_2x2: UITextField!
    @IBOutlet var tf_A_M22_2x2: UITextField!
    @IBOutlet var tf_B_M11_2x2: UITextField!
    @IBOutlet var tf_B_M12_2x2: UITextField!
    @IBOutlet var tf_B_M21_2x2: UITextField!
    @IBOutlet var tf_B_M22_2x2: UITextField!
    @IBOutlet var tf_scale_2x2: UITextField!
    @IBOutlet var tf_sA_M11_2x2: UITextField!
    @IBOutlet var tf_sA_M12_2x2: UITextField!
    @IBOutlet var tf_sA_M21_2x2: UITextField!
    @IBOutlet var tf_sA_M22_2x2: UITextField!
    @IBOutlet var tf_sB_M11_2x2: UITextField!
    @IBOutlet var tf_sB_M12_2x2: UITextField!
    @IBOutlet var tf_sB_M21_2x2: UITextField!
    @IBOutlet var tf_sB_M22_2x2: UITextField!
    @IBOutlet var tf_AB_M11_2x2: UITextField!
    @IBOutlet var tf_AB_M12_2x2: UITextField!
    @IBOutlet var tf_AB_M21_2x2: UITextField!
    @IBOutlet var tf_AB_M22_2x2: UITextField!
    @IBOutlet var tf_BA_M11_2x2: UITextField!
    @IBOutlet var tf_BA_M12_2x2: UITextField!
    @IBOutlet var tf_BA_M21_2x2: UITextField!
    @IBOutlet var tf_BA_M22_2x2: UITextField!
    @IBOutlet var tf_invA_M11_2x2: UITextField!
    @IBOutlet var tf_invA_M12_2x2: UITextField!
    @IBOutlet var tf_invA_M21_2x2: UITextField!
    @IBOutlet var tf_invA_M22_2x2: UITextField!
    @IBOutlet var tf_invB_M11_2x2: UITextField!
    @IBOutlet var tf_invB_M12_2x2: UITextField!
    @IBOutlet var tf_invB_M21_2x2: UITextField!
    @IBOutlet var tf_invB_M22_2x2: UITextField!
    @IBOutlet var tf_detA_2x2: UITextField!
    @IBOutlet var tf_detB_2x2: UITextField!
    @IBOutlet var btn_export_2x2: UIButton!
    
    @IBAction func btn_calculate_2x2(_ sender: UIButton) {
        let aM11 = (tf_A_M11_2x2.text! as NSString).doubleValue
        let aM12 = (tf_A_M12_2x2.text! as NSString).doubleValue
        let aM21 = (tf_A_M21_2x2.text! as NSString).doubleValue
        let aM22 = (tf_A_M22_2x2.text! as NSString).doubleValue
        let bM11 = (tf_B_M11_2x2.text! as NSString).doubleValue
        let bM12 = (tf_B_M12_2x2.text! as NSString).doubleValue
        let bM21 = (tf_B_M21_2x2.text! as NSString).doubleValue
        let bM22 = (tf_B_M22_2x2.text! as NSString).doubleValue
        let s = (tf_scale_2x2.text! as NSString).doubleValue
        let A = Matrix2x2(m11: aM11, andM12: aM12, andM21: aM21, andM22: aM22)
        let B = Matrix2x2(m11: bM11, andM12: bM12, andM21: bM21, andM22: bM22)
        let sA = Calculator.scaleMatrix(matrixA: A, withScale: s)
        let sB = Calculator.scaleMatrix(matrixA: B, withScale: s)
        let AB = Calculator.multiplyMatrices(matrixA: A, andMatrixB: B)
        let BA = Calculator.multiplyMatrices(matrixA: B, andMatrixB: A)
        let detA = Calculator.determinant(matrix: A)
        let detB = Calculator.determinant(matrix: B)
        let iA = Calculator.inverse(matrix: A)
        let iB = Calculator.inverse(matrix: A)
        tf_sA_M11_2x2.text = ("\(sA.m11)")
        tf_sA_M12_2x2.text = ("\(sA.m12)")
        tf_sA_M21_2x2.text = ("\(sA.m21)")
        tf_sA_M22_2x2.text = ("\(sA.m22)")
        tf_sB_M11_2x2.text = ("\(sB.m11)")
        tf_sB_M12_2x2.text = ("\(sB.m12)")
        tf_sB_M21_2x2.text = ("\(sB.m21)")
        tf_sB_M22_2x2.text = ("\(sB.m22)")
        tf_AB_M11_2x2.text = ("\(AB.m11)")
        tf_AB_M12_2x2.text = ("\(AB.m12)")
        tf_AB_M21_2x2.text = ("\(AB.m21)")
        tf_AB_M22_2x2.text = ("\(AB.m22)")
        tf_BA_M11_2x2.text = ("\(BA.m11)")
        tf_BA_M12_2x2.text = ("\(BA.m12)")
        tf_BA_M21_2x2.text = ("\(BA.m21)")
        tf_BA_M22_2x2.text = ("\(BA.m22)")
        tf_invA_M11_2x2.text = ("\(round(100000 * iA.m11) / 100000)")
        tf_invA_M12_2x2.text = ("\(round(100000 * iA.m12) / 100000)")
        tf_invA_M21_2x2.text = ("\(round(100000 * iA.m21) / 100000)")
        tf_invA_M22_2x2.text = ("\(round(100000 * iA.m22) / 100000)")
        tf_invB_M11_2x2.text = ("\(round(100000 * iB.m11) / 100000)")
        tf_invB_M12_2x2.text = ("\(round(100000 * iB.m12) / 100000)")
        tf_invB_M21_2x2.text = ("\(round(100000 * iB.m21) / 100000)")
        tf_invB_M22_2x2.text = ("\(round(100000 * iB.m22) / 100000)")
        tf_detA_2x2.text = ("\(detA)")
        tf_detB_2x2.text = ("\(detB)")
        btn_export_2x2.isEnabled = true
    }
    
    @IBAction func btn_reset_2x2(_ sender: UIButton) {
        tf_A_M11_2x2.text = "0"
        tf_A_M12_2x2.text = "0"
        tf_A_M21_2x2.text = "0"
        tf_A_M22_2x2.text = "0"
        tf_B_M11_2x2.text = "0"
        tf_B_M12_2x2.text = "0"
        tf_B_M21_2x2.text = "0"
        tf_B_M22_2x2.text = "0"
        tf_scale_2x2.text = "1"
        tf_sA_M11_2x2.text = ""
        tf_sA_M12_2x2.text = ""
        tf_sA_M21_2x2.text = ""
        tf_sA_M22_2x2.text = ""
        tf_sB_M11_2x2.text = ""
        tf_sB_M12_2x2.text = ""
        tf_sB_M21_2x2.text = ""
        tf_sB_M22_2x2.text = ""
        tf_AB_M11_2x2.text = ""
        tf_AB_M12_2x2.text = ""
        tf_AB_M21_2x2.text = ""
        tf_AB_M22_2x2.text = ""
        tf_BA_M11_2x2.text = ""
        tf_BA_M12_2x2.text = ""
        tf_BA_M21_2x2.text = ""
        tf_BA_M22_2x2.text = ""
        tf_detA_2x2.text = ""
        tf_detB_2x2.text = ""
        tf_invA_M11_2x2.text = ""
        tf_invA_M12_2x2.text = ""
        tf_invA_M21_2x2.text = ""
        tf_invA_M22_2x2.text = ""
        tf_invB_M11_2x2.text = ""
        tf_invB_M12_2x2.text = ""
        tf_invB_M21_2x2.text = ""
        tf_invB_M22_2x2.text = ""
        btn_export_2x2.isEnabled = false
    }
    
    @IBAction func btn_export_2x2(_ sender: UIButton) {
        
    }
    
    //MARK: 3x3 Matrices
    @IBOutlet var tf_A_M11_3x3: UITextField!
    @IBOutlet var tf_A_M12_3x3: UITextField!
    @IBOutlet var tf_A_M13_3x3: UITextField!
    @IBOutlet var tf_A_M21_3x3: UITextField!
    @IBOutlet var tf_A_M22_3x3: UITextField!
    @IBOutlet var tf_A_M23_3x3: UITextField!
    @IBOutlet var tf_A_M31_3x3: UITextField!
    @IBOutlet var tf_A_M32_3x3: UITextField!
    @IBOutlet var tf_A_M33_3x3: UITextField!
    @IBOutlet var tf_B_M11_3x3: UITextField!
    @IBOutlet var tf_B_M12_3x3: UITextField!
    @IBOutlet var tf_B_M13_3x3: UITextField!
    @IBOutlet var tf_B_M21_3x3: UITextField!
    @IBOutlet var tf_B_M22_3x3: UITextField!
    @IBOutlet var tf_B_M23_3x3: UITextField!
    @IBOutlet var tf_B_M31_3x3: UITextField!
    @IBOutlet var tf_B_M32_3x3: UITextField!
    @IBOutlet var tf_B_M33_3x3: UITextField!
    @IBOutlet var tf_scale_3x3: UITextField!
    @IBOutlet var tf_sA_M11_3x3: UITextField!
    @IBOutlet var tf_sA_M12_3x3: UITextField!
    @IBOutlet var tf_sA_M13_3x3: UITextField!
    @IBOutlet var tf_sA_M21_3x3: UITextField!
    @IBOutlet var tf_sA_M22_3x3: UITextField!
    @IBOutlet var tf_sA_M23_3x3: UITextField!
    @IBOutlet var tf_sA_M31_3x3: UITextField!
    @IBOutlet var tf_sA_M32_3x3: UITextField!
    @IBOutlet var tf_sA_M33_3x3: UITextField!
    @IBOutlet var tf_sB_M11_3x3: UITextField!
    @IBOutlet var tf_sB_M12_3x3: UITextField!
    @IBOutlet var tf_sB_M13_3x3: UITextField!
    @IBOutlet var tf_sB_M21_3x3: UITextField!
    @IBOutlet var tf_sB_M22_3x3: UITextField!
    @IBOutlet var tf_sB_M23_3x3: UITextField!
    @IBOutlet var tf_sB_M31_3x3: UITextField!
    @IBOutlet var tf_sB_M32_3x3: UITextField!
    @IBOutlet var tf_sB_M33_3x3: UITextField!
    @IBOutlet var tf_AB_M11_3x3: UITextField!
    @IBOutlet var tf_AB_M12_3x3: UITextField!
    @IBOutlet var tf_AB_M13_3x3: UITextField!
    @IBOutlet var tf_AB_M21_3x3: UITextField!
    @IBOutlet var tf_AB_M22_3x3: UITextField!
    @IBOutlet var tf_AB_M23_3x3: UITextField!
    @IBOutlet var tf_AB_M31_3x3: UITextField!
    @IBOutlet var tf_AB_M32_3x3: UITextField!
    @IBOutlet var tf_AB_M33_3x3: UITextField!
    @IBOutlet var tf_BA_M11_3x3: UITextField!
    @IBOutlet var tf_BA_M12_3x3: UITextField!
    @IBOutlet var tf_BA_M13_3x3: UITextField!
    @IBOutlet var tf_BA_M21_3x3: UITextField!
    @IBOutlet var tf_BA_M22_3x3: UITextField!
    @IBOutlet var tf_BA_M23_3x3: UITextField!
    @IBOutlet var tf_BA_M31_3x3: UITextField!
    @IBOutlet var tf_BA_M32_3x3: UITextField!
    @IBOutlet var tf_BA_M33_3x3: UITextField!
    @IBOutlet var tf_detA_3x3: UITextField!
    @IBOutlet var tf_detB_3x3: UITextField!
    @IBOutlet var tf_invA_M11_3x3: UITextField!
    @IBOutlet var tf_invA_M12_3x3: UITextField!
    @IBOutlet var tf_invA_M13_3x3: UITextField!
    @IBOutlet var tf_invA_M21_3x3: UITextField!
    @IBOutlet var tf_invA_M22_3x3: UITextField!
    @IBOutlet var tf_invA_M23_3x3: UITextField!
    @IBOutlet var tf_invA_M31_3x3: UITextField!
    @IBOutlet var tf_invA_M32_3x3: UITextField!
    @IBOutlet var tf_invA_M33_3x3: UITextField!
    @IBOutlet var tf_invB_M11_3x3: UITextField!
    @IBOutlet var tf_invB_M12_3x3: UITextField!
    @IBOutlet var tf_invB_M13_3x3: UITextField!
    @IBOutlet var tf_invB_M21_3x3: UITextField!
    @IBOutlet var tf_invB_M22_3x3: UITextField!
    @IBOutlet var tf_invB_M23_3x3: UITextField!
    @IBOutlet var tf_invB_M31_3x3: UITextField!
    @IBOutlet var tf_invB_M32_3x3: UITextField!
    @IBOutlet var tf_invB_M33_3x3: UITextField!
    
    @IBOutlet var btn_export_3x3: UIButton!
    
    @IBAction func btn_calculate_3x3(_ sender: UIButton) {
        let aM11 = (tf_A_M11_3x3.text! as NSString).doubleValue
        let aM12 = (tf_A_M12_3x3.text! as NSString).doubleValue
        let aM13 = (tf_A_M13_3x3.text! as NSString).doubleValue
        let aM21 = (tf_A_M21_3x3.text! as NSString).doubleValue
        let aM22 = (tf_A_M22_3x3.text! as NSString).doubleValue
        let aM23 = (tf_A_M23_3x3.text! as NSString).doubleValue
        let aM31 = (tf_A_M31_3x3.text! as NSString).doubleValue
        let aM32 = (tf_A_M32_3x3.text! as NSString).doubleValue
        let aM33 = (tf_A_M33_3x3.text! as NSString).doubleValue
        let bM11 = (tf_B_M11_3x3.text! as NSString).doubleValue
        let bM12 = (tf_B_M12_3x3.text! as NSString).doubleValue
        let bM13 = (tf_B_M13_3x3.text! as NSString).doubleValue
        let bM21 = (tf_B_M21_3x3.text! as NSString).doubleValue
        let bM22 = (tf_B_M22_3x3.text! as NSString).doubleValue
        let bM23 = (tf_B_M23_3x3.text! as NSString).doubleValue
        let bM31 = (tf_B_M31_3x3.text! as NSString).doubleValue
        let bM32 = (tf_B_M32_3x3.text! as NSString).doubleValue
        let bM33 = (tf_B_M33_3x3.text! as NSString).doubleValue
        let s = (tf_scale_3x3.text! as NSString).doubleValue
        let A = Matrix3x3(m11: aM11, andM12: aM12, andM13: aM13, andM21: aM21, andM22: aM22, andM23: aM23, andM31: aM31, andM32: aM32, andM33: aM33)
        let B = Matrix3x3(m11: bM11, andM12: bM12, andM13: bM13, andM21: bM21, andM22: bM22, andM23: bM23, andM31: bM31, andM32: bM32, andM33: bM33)
        let sA = Calculator.scaleMatrix(matrixA: A, withScale: s)
        let sB = Calculator.scaleMatrix(matrixA: B, withScale: s)
        let AB = Calculator.multiplyMatrices(matrixA: A, andMatrixB: B)
        let BA = Calculator.multiplyMatrices(matrixA: B, andMatrixB: A)
        let detA = Calculator.determinant(matrix: A)
        let detB = Calculator.determinant(matrix: B)
        let invA = Calculator.inverse(matrix: A)
        let invB = Calculator.inverse(matrix: B)
        tf_sA_M11_3x3.text = ("\(sA.m11)")
        tf_sA_M12_3x3.text = ("\(sA.m12)")
        tf_sA_M13_3x3.text = ("\(sA.m13)")
        tf_sA_M21_3x3.text = ("\(sA.m21)")
        tf_sA_M22_3x3.text = ("\(sA.m22)")
        tf_sA_M23_3x3.text = ("\(sA.m23)")
        tf_sA_M31_3x3.text = ("\(sA.m31)")
        tf_sA_M32_3x3.text = ("\(sA.m32)")
        tf_sA_M33_3x3.text = ("\(sA.m33)")
        tf_sB_M11_3x3.text = ("\(sB.m11)")
        tf_sB_M12_3x3.text = ("\(sB.m12)")
        tf_sB_M13_3x3.text = ("\(sB.m13)")
        tf_sB_M21_3x3.text = ("\(sB.m21)")
        tf_sB_M22_3x3.text = ("\(sB.m22)")
        tf_sB_M23_3x3.text = ("\(sB.m23)")
        tf_sB_M31_3x3.text = ("\(sB.m31)")
        tf_sB_M32_3x3.text = ("\(sB.m32)")
        tf_sB_M33_3x3.text = ("\(sB.m33)")
        tf_AB_M11_3x3.text = ("\(AB.m11)")
        tf_AB_M12_3x3.text = ("\(AB.m12)")
        tf_AB_M13_3x3.text = ("\(AB.m13)")
        tf_AB_M21_3x3.text = ("\(AB.m21)")
        tf_AB_M22_3x3.text = ("\(AB.m22)")
        tf_AB_M23_3x3.text = ("\(AB.m23)")
        tf_AB_M31_3x3.text = ("\(AB.m31)")
        tf_AB_M32_3x3.text = ("\(AB.m32)")
        tf_AB_M33_3x3.text = ("\(AB.m33)")
        tf_BA_M11_3x3.text = ("\(BA.m11)")
        tf_BA_M12_3x3.text = ("\(BA.m12)")
        tf_BA_M13_3x3.text = ("\(BA.m13)")
        tf_BA_M21_3x3.text = ("\(BA.m21)")
        tf_BA_M22_3x3.text = ("\(BA.m22)")
        tf_BA_M23_3x3.text = ("\(BA.m23)")
        tf_BA_M31_3x3.text = ("\(BA.m31)")
        tf_BA_M32_3x3.text = ("\(BA.m32)")
        tf_BA_M33_3x3.text = ("\(BA.m33)")
        tf_detA_3x3.text = ("\(detA)")
        tf_detB_3x3.text = ("\(detB)")
        tf_invA_M11_3x3.text = ("\(round(100000 * invA.m11) / 100000)")
        tf_invA_M12_3x3.text = ("\(round(100000 * invA.m12) / 100000)")
        tf_invA_M13_3x3.text = ("\(round(100000 * invA.m13) / 100000)")
        tf_invA_M21_3x3.text = ("\(round(100000 * invA.m21) / 100000)")
        tf_invA_M22_3x3.text = ("\(round(100000 * invA.m22) / 100000)")
        tf_invA_M23_3x3.text = ("\(round(100000 * invA.m23) / 100000)")
        tf_invA_M31_3x3.text = ("\(round(100000 * invA.m31) / 100000)")
        tf_invA_M32_3x3.text = ("\(round(100000 * invA.m32) / 100000)")
        tf_invA_M33_3x3.text = ("\(round(100000 * invA.m33) / 100000)")
        tf_invB_M11_3x3.text = ("\(round(100000 * invB.m11) / 100000)")
        tf_invB_M12_3x3.text = ("\(round(100000 * invB.m12) / 100000)")
        tf_invB_M13_3x3.text = ("\(round(100000 * invB.m13) / 100000)")
        tf_invB_M21_3x3.text = ("\(round(100000 * invB.m21) / 100000)")
        tf_invB_M22_3x3.text = ("\(round(100000 * invB.m22) / 100000)")
        tf_invB_M23_3x3.text = ("\(round(100000 * invB.m23) / 100000)")
        tf_invB_M31_3x3.text = ("\(round(100000 * invB.m31) / 100000)")
        tf_invB_M32_3x3.text = ("\(round(100000 * invB.m32) / 100000)")
        tf_invB_M33_3x3.text = ("\(round(100000 * invB.m33) / 100000)")
        btn_export_3x3.isEnabled = true
    }
    
    @IBAction func btn_reset_3x3(_ sender: UIButton) {
        btn_export_3x3.isEnabled = false
        tf_A_M11_3x3.text = "0"
        tf_A_M12_3x3.text = "0"
        tf_A_M13_3x3.text = "0"
        tf_A_M21_3x3.text = "0"
        tf_A_M22_3x3.text = "0"
        tf_A_M23_3x3.text = "0"
        tf_A_M31_3x3.text = "0"
        tf_A_M32_3x3.text = "0"
        tf_A_M33_3x3.text = "0"
        tf_B_M11_3x3.text = "0"
        tf_B_M12_3x3.text = "0"
        tf_B_M13_3x3.text = "0"
        tf_B_M21_3x3.text = "0"
        tf_B_M22_3x3.text = "0"
        tf_B_M23_3x3.text = "0"
        tf_B_M31_3x3.text = "0"
        tf_B_M32_3x3.text = "0"
        tf_B_M33_3x3.text = "0"
        tf_scale_3x3.text = "1"
        tf_sA_M11_3x3.text = ""
        tf_sA_M12_3x3.text = ""
        tf_sA_M13_3x3.text = ""
        tf_sA_M21_3x3.text = ""
        tf_sA_M22_3x3.text = ""
        tf_sA_M23_3x3.text = ""
        tf_sA_M31_3x3.text = ""
        tf_sA_M32_3x3.text = ""
        tf_sA_M33_3x3.text = ""
        tf_sB_M11_3x3.text = ""
        tf_sB_M12_3x3.text = ""
        tf_sB_M13_3x3.text = ""
        tf_sB_M21_3x3.text = ""
        tf_sB_M22_3x3.text = ""
        tf_sB_M23_3x3.text = ""
        tf_sB_M31_3x3.text = ""
        tf_sB_M32_3x3.text = ""
        tf_sB_M33_3x3.text = ""
        tf_AB_M11_3x3.text = ""
        tf_AB_M12_3x3.text = ""
        tf_AB_M13_3x3.text = ""
        tf_AB_M21_3x3.text = ""
        tf_AB_M22_3x3.text = ""
        tf_AB_M23_3x3.text = ""
        tf_AB_M31_3x3.text = ""
        tf_AB_M32_3x3.text = ""
        tf_AB_M33_3x3.text = ""
        tf_BA_M11_3x3.text = ""
        tf_BA_M12_3x3.text = ""
        tf_BA_M13_3x3.text = ""
        tf_BA_M21_3x3.text = ""
        tf_BA_M22_3x3.text = ""
        tf_BA_M23_3x3.text = ""
        tf_BA_M31_3x3.text = ""
        tf_BA_M32_3x3.text = ""
        tf_BA_M33_3x3.text = ""
        tf_invA_M11_3x3.text = ""
        tf_invA_M12_3x3.text = ""
        tf_invA_M13_3x3.text = ""
        tf_invA_M21_3x3.text = ""
        tf_invA_M22_3x3.text = ""
        tf_invA_M23_3x3.text = ""
        tf_invA_M31_3x3.text = ""
        tf_invA_M32_3x3.text = ""
        tf_invA_M33_3x3.text = ""
        tf_invB_M11_3x3.text = ""
        tf_invB_M12_3x3.text = ""
        tf_invB_M13_3x3.text = ""
        tf_invB_M21_3x3.text = ""
        tf_invB_M22_3x3.text = ""
        tf_invB_M23_3x3.text = ""
        tf_invB_M31_3x3.text = ""
        tf_invB_M32_3x3.text = ""
        tf_invB_M33_3x3.text = ""
        tf_detA_3x3.text = ""
        tf_detB_3x3.text = ""
    }
    
    @IBAction func btn_export_3x3(_ sender: UIButton) {
        
    }
    
    //MARK: 4x4 Matrices
    @IBOutlet var tf_A_M11_4x4: UITextField!
    @IBOutlet var tf_A_M12_4x4: UITextField!
    @IBOutlet var tf_A_M13_4x4: UITextField!
    @IBOutlet var tf_A_M14_4x4: UITextField!
    @IBOutlet var tf_A_M21_4x4: UITextField!
    @IBOutlet var tf_A_M22_4x4: UITextField!
    @IBOutlet var tf_A_M23_4x4: UITextField!
    @IBOutlet var tf_A_M24_4x4: UITextField!
    @IBOutlet var tf_A_M31_4x4: UITextField!
    @IBOutlet var tf_A_M32_4x4: UITextField!
    @IBOutlet var tf_A_M33_4x4: UITextField!
    @IBOutlet var tf_A_M34_4x4: UITextField!
    @IBOutlet var tf_A_M41_4x4: UITextField!
    @IBOutlet var tf_A_M42_4x4: UITextField!
    @IBOutlet var tf_A_M43_4x4: UITextField!
    @IBOutlet var tf_A_M44_4x4: UITextField!
    @IBOutlet var tf_B_M11_4x4: UITextField!
    @IBOutlet var tf_B_M12_4x4: UITextField!
    @IBOutlet var tf_B_M13_4x4: UITextField!
    @IBOutlet var tf_B_M14_4x4: UITextField!
    @IBOutlet var tf_B_M21_4x4: UITextField!
    @IBOutlet var tf_B_M22_4x4: UITextField!
    @IBOutlet var tf_B_M23_4x4: UITextField!
    @IBOutlet var tf_B_M24_4x4: UITextField!
    @IBOutlet var tf_B_M31_4x4: UITextField!
    @IBOutlet var tf_B_M32_4x4: UITextField!
    @IBOutlet var tf_B_M33_4x4: UITextField!
    @IBOutlet var tf_B_M34_4x4: UITextField!
    @IBOutlet var tf_B_M41_4x4: UITextField!
    @IBOutlet var tf_B_M42_4x4: UITextField!
    @IBOutlet var tf_B_M43_4x4: UITextField!
    @IBOutlet var tf_B_M44_4x4: UITextField!
    @IBOutlet var tf_scale_4x4: UITextField!
    @IBOutlet var btn_export_4x4: UIButton!
    @IBOutlet var tf_sA_M11_4x4: UITextField!
    @IBOutlet var tf_sA_M12_4x4: UITextField!
    @IBOutlet var tf_sA_M13_4x4: UITextField!
    @IBOutlet var tf_sA_M14_4x4: UITextField!
    @IBOutlet var tf_sA_M21_4x4: UITextField!
    @IBOutlet var tf_sA_M22_4x4: UITextField!
    @IBOutlet var tf_sA_M23_4x4: UITextField!
    @IBOutlet var tf_sA_M24_4x4: UITextField!
    @IBOutlet var tf_sA_M31_4x4: UITextField!
    @IBOutlet var tf_sA_M32_4x4: UITextField!
    @IBOutlet var tf_sA_M33_4x4: UITextField!
    @IBOutlet var tf_sA_M34_4x4: UITextField!
    @IBOutlet var tf_sA_M41_4x4: UITextField!
    @IBOutlet var tf_sA_M42_4x4: UITextField!
    @IBOutlet var tf_sA_M43_4x4: UITextField!
    @IBOutlet var tf_sA_M44_4x4: UITextField!
    @IBOutlet var tf_sB_M11_4x4: UITextField!
    @IBOutlet var tf_sB_M12_4x4: UITextField!
    @IBOutlet var tf_sB_M13_4x4: UITextField!
    @IBOutlet var tf_sB_M14_4x4: UITextField!
    @IBOutlet var tf_sB_M21_4x4: UITextField!
    @IBOutlet var tf_sB_M22_4x4: UITextField!
    @IBOutlet var tf_sB_M23_4x4: UITextField!
    @IBOutlet var tf_sB_M24_4x4: UITextField!
    @IBOutlet var tf_sB_M31_4x4: UITextField!
    @IBOutlet var tf_sB_M32_4x4: UITextField!
    @IBOutlet var tf_sB_M33_4x4: UITextField!
    @IBOutlet var tf_sB_M34_4x4: UITextField!
    @IBOutlet var tf_sB_M41_4x4: UITextField!
    @IBOutlet var tf_sB_M42_4x4: UITextField!
    @IBOutlet var tf_sB_M43_4x4: UITextField!
    @IBOutlet var tf_sB_M44_4x4: UITextField!
    @IBOutlet var tf_AB_M11_4x4: UITextField!
    @IBOutlet var tf_AB_M12_4x4: UITextField!
    @IBOutlet var tf_AB_M13_4x4: UITextField!
    @IBOutlet var tf_AB_M14_4x4: UITextField!
    @IBOutlet var tf_AB_M21_4x4: UITextField!
    @IBOutlet var tf_AB_M22_4x4: UITextField!
    @IBOutlet var tf_AB_M23_4x4: UITextField!
    @IBOutlet var tf_AB_M24_4x4: UITextField!
    @IBOutlet var tf_AB_M31_4x4: UITextField!
    @IBOutlet var tf_AB_M32_4x4: UITextField!
    @IBOutlet var tf_AB_M33_4x4: UITextField!
    @IBOutlet var tf_AB_M34_4x4: UITextField!
    @IBOutlet var tf_AB_M41_4x4: UITextField!
    @IBOutlet var tf_AB_M42_4x4: UITextField!
    @IBOutlet var tf_AB_M43_4x4: UITextField!
    @IBOutlet var tf_AB_M44_4x4: UITextField!
    @IBOutlet var tf_BA_M11_4x4: UITextField!
    @IBOutlet var tf_BA_M12_4x4: UITextField!
    @IBOutlet var tf_BA_M13_4x4: UITextField!
    @IBOutlet var tf_BA_M14_4x4: UITextField!
    @IBOutlet var tf_BA_M21_4x4: UITextField!
    @IBOutlet var tf_BA_M22_4x4: UITextField!
    @IBOutlet var tf_BA_M23_4x4: UITextField!
    @IBOutlet var tf_BA_M24_4x4: UITextField!
    @IBOutlet var tf_BA_M31_4x4: UITextField!
    @IBOutlet var tf_BA_M32_4x4: UITextField!
    @IBOutlet var tf_BA_M33_4x4: UITextField!
    @IBOutlet var tf_BA_M34_4x4: UITextField!
    @IBOutlet var tf_BA_M41_4x4: UITextField!
    @IBOutlet var tf_BA_M42_4x4: UITextField!
    @IBOutlet var tf_BA_M43_4x4: UITextField!
    @IBOutlet var tf_BA_M44_4x4: UITextField!
    @IBOutlet var tf_detA_4x4: UITextField!
    @IBOutlet var tf_detB_4x4: UITextField!
    @IBOutlet var tf_invA_M11_4x4: UITextField!
    @IBOutlet var tf_invA_M12_4x4: UITextField!
    @IBOutlet var tf_invA_M13_4x4: UITextField!
    @IBOutlet var tf_invA_M14_4x4: UITextField!
    @IBOutlet var tf_invA_M21_4x4: UITextField!
    @IBOutlet var tf_invA_M22_4x4: UITextField!
    @IBOutlet var tf_invA_M23_4x4: UITextField!
    @IBOutlet var tf_invA_M24_4x4: UITextField!
    @IBOutlet var tf_invA_M31_4x4: UITextField!
    @IBOutlet var tf_invA_M32_4x4: UITextField!
    @IBOutlet var tf_invA_M33_4x4: UITextField!
    @IBOutlet var tf_invA_M34_4x4: UITextField!
    @IBOutlet var tf_invA_M41_4x4: UITextField!
    @IBOutlet var tf_invA_M42_4x4: UITextField!
    @IBOutlet var tf_invA_M43_4x4: UITextField!
    @IBOutlet var tf_invA_M44_4x4: UITextField!
    @IBOutlet var tf_invB_M11_4x4: UITextField!
    @IBOutlet var tf_invB_M12_4x4: UITextField!
    @IBOutlet var tf_invB_M13_4x4: UITextField!
    @IBOutlet var tf_invB_M14_4x4: UITextField!
    @IBOutlet var tf_invB_M21_4x4: UITextField!
    @IBOutlet var tf_invB_M22_4x4: UITextField!
    @IBOutlet var tf_invB_M23_4x4: UITextField!
    @IBOutlet var tf_invB_M24_4x4: UITextField!
    @IBOutlet var tf_invB_M31_4x4: UITextField!
    @IBOutlet var tf_invB_M32_4x4: UITextField!
    @IBOutlet var tf_invB_M33_4x4: UITextField!
    @IBOutlet var tf_invB_M34_4x4: UITextField!
    @IBOutlet var tf_invB_M41_4x4: UITextField!
    @IBOutlet var tf_invB_M42_4x4: UITextField!
    @IBOutlet var tf_invB_M43_4x4: UITextField!
    @IBOutlet var tf_invB_M44_4x4: UITextField!
    
    @IBAction func btn_calculate_4x4(_ sender: UIButton) {
        let aM11 = (tf_A_M11_4x4.text! as NSString).doubleValue
        let aM12 = (tf_A_M12_4x4.text! as NSString).doubleValue
        let aM13 = (tf_A_M13_4x4.text! as NSString).doubleValue
        let aM14 = (tf_A_M14_4x4.text! as NSString).doubleValue
        let aM21 = (tf_A_M21_4x4.text! as NSString).doubleValue
        let aM22 = (tf_A_M22_4x4.text! as NSString).doubleValue
        let aM23 = (tf_A_M23_4x4.text! as NSString).doubleValue
        let aM24 = (tf_A_M24_4x4.text! as NSString).doubleValue
        let aM31 = (tf_A_M31_4x4.text! as NSString).doubleValue
        let aM32 = (tf_A_M32_4x4.text! as NSString).doubleValue
        let aM33 = (tf_A_M33_4x4.text! as NSString).doubleValue
        let aM34 = (tf_A_M34_4x4.text! as NSString).doubleValue
        let aM41 = (tf_A_M41_4x4.text! as NSString).doubleValue
        let aM42 = (tf_A_M42_4x4.text! as NSString).doubleValue
        let aM43 = (tf_A_M43_4x4.text! as NSString).doubleValue
        let aM44 = (tf_A_M44_4x4.text! as NSString).doubleValue
        let bM11 = (tf_B_M11_4x4.text! as NSString).doubleValue
        let bM12 = (tf_B_M12_4x4.text! as NSString).doubleValue
        let bM13 = (tf_B_M13_4x4.text! as NSString).doubleValue
        let bM14 = (tf_B_M14_4x4.text! as NSString).doubleValue
        let bM21 = (tf_B_M21_4x4.text! as NSString).doubleValue
        let bM22 = (tf_B_M22_4x4.text! as NSString).doubleValue
        let bM23 = (tf_B_M23_4x4.text! as NSString).doubleValue
        let bM24 = (tf_B_M24_4x4.text! as NSString).doubleValue
        let bM31 = (tf_B_M31_4x4.text! as NSString).doubleValue
        let bM32 = (tf_B_M32_4x4.text! as NSString).doubleValue
        let bM33 = (tf_B_M33_4x4.text! as NSString).doubleValue
        let bM34 = (tf_B_M34_4x4.text! as NSString).doubleValue
        let bM41 = (tf_B_M41_4x4.text! as NSString).doubleValue
        let bM42 = (tf_B_M42_4x4.text! as NSString).doubleValue
        let bM43 = (tf_B_M43_4x4.text! as NSString).doubleValue
        let bM44 = (tf_B_M44_4x4.text! as NSString).doubleValue
        let s = (tf_scale_4x4.text! as NSString).doubleValue
        let A = Matrix4x4(m11: aM11, andM12: aM12, andM13: aM13, andM14: aM14, andM21: aM21, andM22: aM22, andM23: aM23, andM24: aM24, andM31: aM31, andM32: aM32, andM33: aM33, andM34: aM34, andM41: aM41, andM42: aM42, andM43: aM43, andM44: aM44)
        let B = Matrix4x4(m11: bM11, andM12: bM12, andM13: bM13, andM14: bM14, andM21: bM21, andM22: bM22, andM23: bM23, andM24: bM24, andM31: bM31, andM32: bM32, andM33: bM33, andM34: bM34, andM41: bM41, andM42: bM42, andM43: bM43, andM44: bM44)
        let sA = Calculator.scaleMatrix(matrixA: A, withScale: s)
        let sB = Calculator.scaleMatrix(matrixA: B, withScale: s)
        let AB = Calculator.multiplyMatrices(matrixA: A, andMatrixB: B)
        let BA = Calculator.multiplyMatrices(matrixA: B, andMatrixB: A)
        let detA = Calculator.determinant(matrix: A)
        let detB = Calculator.determinant(matrix: B)
        let invA = Calculator.inverse(matrix: A)
        let invB = Calculator.inverse(matrix: B)
        tf_sA_M11_4x4.text = ("\(sA.m11)")
        tf_sA_M12_4x4.text = ("\(sA.m12)")
        tf_sA_M13_4x4.text = ("\(sA.m13)")
        tf_sA_M14_4x4.text = ("\(sA.m14)")
        tf_sA_M21_4x4.text = ("\(sA.m21)")
        tf_sA_M22_4x4.text = ("\(sA.m22)")
        tf_sA_M23_4x4.text = ("\(sA.m23)")
        tf_sA_M24_4x4.text = ("\(sA.m24)")
        tf_sA_M31_4x4.text = ("\(sA.m31)")
        tf_sA_M32_4x4.text = ("\(sA.m32)")
        tf_sA_M33_4x4.text = ("\(sA.m33)")
        tf_sA_M34_4x4.text = ("\(sA.m34)")
        tf_sA_M41_4x4.text = ("\(sA.m41)")
        tf_sA_M42_4x4.text = ("\(sA.m42)")
        tf_sA_M43_4x4.text = ("\(sA.m43)")
        tf_sA_M44_4x4.text = ("\(sA.m44)")
        tf_sB_M11_4x4.text = ("\(sB.m11)")
        tf_sB_M12_4x4.text = ("\(sB.m12)")
        tf_sB_M13_4x4.text = ("\(sB.m13)")
        tf_sB_M14_4x4.text = ("\(sB.m14)")
        tf_sB_M21_4x4.text = ("\(sB.m21)")
        tf_sB_M22_4x4.text = ("\(sB.m22)")
        tf_sB_M23_4x4.text = ("\(sB.m23)")
        tf_sB_M24_4x4.text = ("\(sB.m24)")
        tf_sB_M31_4x4.text = ("\(sB.m31)")
        tf_sB_M32_4x4.text = ("\(sB.m32)")
        tf_sB_M33_4x4.text = ("\(sB.m33)")
        tf_sB_M34_4x4.text = ("\(sB.m34)")
        tf_sB_M41_4x4.text = ("\(sB.m41)")
        tf_sB_M42_4x4.text = ("\(sB.m42)")
        tf_sB_M43_4x4.text = ("\(sB.m43)")
        tf_sB_M44_4x4.text = ("\(sB.m44)")
        tf_AB_M11_4x4.text = ("\(AB.m11)")
        tf_AB_M12_4x4.text = ("\(AB.m12)")
        tf_AB_M13_4x4.text = ("\(AB.m13)")
        tf_AB_M14_4x4.text = ("\(AB.m14)")
        tf_AB_M21_4x4.text = ("\(AB.m21)")
        tf_AB_M22_4x4.text = ("\(AB.m22)")
        tf_AB_M23_4x4.text = ("\(AB.m23)")
        tf_AB_M24_4x4.text = ("\(AB.m24)")
        tf_AB_M31_4x4.text = ("\(AB.m31)")
        tf_AB_M32_4x4.text = ("\(AB.m32)")
        tf_AB_M33_4x4.text = ("\(AB.m33)")
        tf_AB_M34_4x4.text = ("\(AB.m34)")
        tf_AB_M41_4x4.text = ("\(AB.m41)")
        tf_AB_M42_4x4.text = ("\(AB.m42)")
        tf_AB_M43_4x4.text = ("\(AB.m43)")
        tf_AB_M44_4x4.text = ("\(AB.m44)")
        tf_BA_M11_4x4.text = ("\(BA.m11)")
        tf_BA_M12_4x4.text = ("\(BA.m12)")
        tf_BA_M13_4x4.text = ("\(BA.m13)")
        tf_BA_M14_4x4.text = ("\(BA.m14)")
        tf_BA_M21_4x4.text = ("\(BA.m21)")
        tf_BA_M22_4x4.text = ("\(BA.m22)")
        tf_BA_M23_4x4.text = ("\(BA.m23)")
        tf_BA_M24_4x4.text = ("\(BA.m24)")
        tf_BA_M31_4x4.text = ("\(BA.m31)")
        tf_BA_M32_4x4.text = ("\(BA.m32)")
        tf_BA_M33_4x4.text = ("\(BA.m33)")
        tf_BA_M34_4x4.text = ("\(BA.m34)")
        tf_BA_M41_4x4.text = ("\(BA.m41)")
        tf_BA_M42_4x4.text = ("\(BA.m42)")
        tf_BA_M43_4x4.text = ("\(BA.m43)")
        tf_BA_M44_4x4.text = ("\(BA.m44)")
        tf_detA_4x4.text = ("\(detA)")
        tf_detB_4x4.text = ("\(detB)")
        tf_invA_M11_4x4.text = ("\(round(100000 * invA.m11) / 100000)")
        tf_invA_M12_4x4.text = ("\(round(100000 * invA.m12) / 100000)")
        tf_invA_M13_4x4.text = ("\(round(100000 * invA.m13) / 100000)")
        tf_invA_M14_4x4.text = ("\(round(100000 * invA.m14) / 100000)")
        tf_invA_M21_4x4.text = ("\(round(100000 * invA.m21) / 100000)")
        tf_invA_M22_4x4.text = ("\(round(100000 * invA.m22) / 100000)")
        tf_invA_M23_4x4.text = ("\(round(100000 * invA.m23) / 100000)")
        tf_invA_M24_4x4.text = ("\(round(100000 * invA.m24) / 100000)")
        tf_invA_M31_4x4.text = ("\(round(100000 * invA.m31) / 100000)")
        tf_invA_M32_4x4.text = ("\(round(100000 * invA.m32) / 100000)")
        tf_invA_M33_4x4.text = ("\(round(100000 * invA.m33) / 100000)")
        tf_invA_M34_4x4.text = ("\(round(100000 * invA.m34) / 100000)")
        tf_invA_M41_4x4.text = ("\(round(100000 * invA.m41) / 100000)")
        tf_invA_M42_4x4.text = ("\(round(100000 * invA.m42) / 100000)")
        tf_invA_M43_4x4.text = ("\(round(100000 * invA.m43) / 100000)")
        tf_invA_M44_4x4.text = ("\(round(100000 * invA.m44) / 100000)")
        tf_invB_M11_4x4.text = ("\(round(100000 * invB.m11) / 100000)")
        tf_invB_M12_4x4.text = ("\(round(100000 * invB.m12) / 100000)")
        tf_invB_M13_4x4.text = ("\(round(100000 * invB.m13) / 100000)")
        tf_invB_M14_4x4.text = ("\(round(100000 * invB.m14) / 100000)")
        tf_invB_M21_4x4.text = ("\(round(100000 * invB.m21) / 100000)")
        tf_invB_M22_4x4.text = ("\(round(100000 * invB.m22) / 100000)")
        tf_invB_M23_4x4.text = ("\(round(100000 * invB.m23) / 100000)")
        tf_invB_M24_4x4.text = ("\(round(100000 * invB.m24) / 100000)")
        tf_invB_M31_4x4.text = ("\(round(100000 * invB.m31) / 100000)")
        tf_invB_M32_4x4.text = ("\(round(100000 * invB.m32) / 100000)")
        tf_invB_M33_4x4.text = ("\(round(100000 * invB.m33) / 100000)")
        tf_invB_M34_4x4.text = ("\(round(100000 * invB.m34) / 100000)")
        tf_invB_M41_4x4.text = ("\(round(100000 * invB.m41) / 100000)")
        tf_invB_M42_4x4.text = ("\(round(100000 * invB.m42) / 100000)")
        tf_invB_M43_4x4.text = ("\(round(100000 * invB.m43) / 100000)")
        tf_invB_M44_4x4.text = ("\(round(100000 * invB.m44) / 100000)")
    }
    
    @IBAction func btn_reset_4x4(_ sender: UIButton) {
        
    }
    
    @IBAction func btn_export_4x4(_ sender: UIButton) {
        
    }
    
    
    //MARK: Common
    override func viewDidLoad() {
        super.viewDidLoad()
        scrollView.contentSize = CGSize(width: 1024, height: 2500)
        scrollView.showsVerticalScrollIndicator = true
        scrollView.isScrollEnabled = true
        scrollView.indicatorStyle = UIScrollViewIndicatorStyle.black
        self.view.addSubview(scrollView)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
