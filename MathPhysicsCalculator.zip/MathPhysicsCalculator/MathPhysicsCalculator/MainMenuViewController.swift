//
//  MainMenuViewController.swift
//  MathPhysicsCalculator
//
//  Created by Allan Anderson on 2015-May-06.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import UIKit

class MainMenuViewController: UITableViewController {

    let menuItems = ["Vectors", "Matrices", "Motion", "Forces", "Lab 1", "Lab 2", "Lab 3", "Lab 4"]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menuItems.count
    }

   // MARK: TableViewDelegate Methods
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("mainMenuIdentifier", forIndexPath: indexPath) as! UITableViewCell
        cell.textLabel?.text = menuItems[indexPath.row]
        return cell
    }
   
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        // select the correct cell and display the appropriate controls on the detail view
        switch indexPath.row{
        case 0:
            // VectorsViewController
            self.performSegueWithIdentifier("showVectorsViewController", sender: self)
        case 1:
            // MatricesViewController
            self.performSegueWithIdentifier("showMatricesViewController", sender: self)
        case 2:
            // MotionViewController
            self.performSegueWithIdentifier("showMotionViewController", sender: self)
        case 3:
            // ForcesViewController
            self.performSegueWithIdentifier("showForcesViewController", sender: self)
        case 4:
            // Lab1ViewController
            self.performSegueWithIdentifier("showLab1ViewController", sender: self)
        case 5:
            // Lab2ViewController
            self.performSegueWithIdentifier("showLab2ViewController", sender: self)
        case 6:
            // Lab3ViewController
            self.performSegueWithIdentifier("showLab3ViewController", sender: self)
        case 7:
            // Lab4ViewController
            self.performSegueWithIdentifier("showLab4ViewController", sender: self)
        default:
            // GenericViewController
            self.performSegueWithIdentifier("showGenericViewController", sender: self)
        }
    }

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "showVectorsViewController" {
            if let indexPath = self.tableView.indexPathForSelectedRow() {
                let controller = (segue.destinationViewController as! UINavigationController).topViewController as! VectorsViewController
                controller.navigationItem.leftBarButtonItem = self.splitViewController?.displayModeButtonItem()
                controller.navigationItem.leftItemsSupplementBackButton = true
            } else if segue.identifier == "showMatricesViewController" {
                let controller = (segue.destinationViewController as! UINavigationController).topViewController as! MatricesViewController
                controller.navigationItem.leftBarButtonItem = self.splitViewController?.displayModeButtonItem()
                controller.navigationItem.leftItemsSupplementBackButton = true
            } else if segue.identifier == "showMotionViewController" {
                let controller = (segue.destinationViewController as! UINavigationController).topViewController as! MotionViewController
                controller.navigationItem.leftBarButtonItem = self.splitViewController?.displayModeButtonItem()
                controller.navigationItem.leftItemsSupplementBackButton = true
            } else if segue.identifier == "showForcesViewController" {
                let controller = (segue.destinationViewController as! UINavigationController).topViewController as! ForcesViewController
                controller.navigationItem.leftBarButtonItem = self.splitViewController?.displayModeButtonItem()
                controller.navigationItem.leftItemsSupplementBackButton = true
            } else if segue.identifier == "showLab1ViewController" {
                let controller = (segue.destinationViewController as! UINavigationController).topViewController as! Lab1ViewController
                controller.navigationItem.leftBarButtonItem = self.splitViewController?.displayModeButtonItem()
                controller.navigationItem.leftItemsSupplementBackButton = true
            } else if segue.identifier == "showLab2ViewController" {
                let controller = (segue.destinationViewController as! UINavigationController).topViewController as! Lab2ViewController
                controller.navigationItem.leftBarButtonItem = self.splitViewController?.displayModeButtonItem()
                controller.navigationItem.leftItemsSupplementBackButton = true
            } else if segue.identifier == "showLab3ViewController" {
                let controller = (segue.destinationViewController as! UINavigationController).topViewController as! Lab3ViewController
                controller.navigationItem.leftBarButtonItem = self.splitViewController?.displayModeButtonItem()
                controller.navigationItem.leftItemsSupplementBackButton = true
            } else if segue.identifier == "showLab4ViewController" {
                let controller = (segue.destinationViewController as! UINavigationController).topViewController as! Lab4ViewController
                controller.navigationItem.leftBarButtonItem = self.splitViewController?.displayModeButtonItem()
                controller.navigationItem.leftItemsSupplementBackButton = true
            } else if segue.identifier == "showGenericViewController" {
                let controller = (segue.destinationViewController as! UINavigationController).topViewController as! GenericViewController
                controller.navigationItem.leftBarButtonItem = self.splitViewController?.displayModeButtonItem()
                controller.navigationItem.leftItemsSupplementBackButton = true
            }
        }
    }
}
