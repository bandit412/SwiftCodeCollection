//
//  Matrix2x2.swift
//  MathPhysicsCalculator
//
//  Created by Allan Anderson on 2015-Apr-23.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import Foundation
open class Matrix2x2{
    // MARK : Properties
    var m11:Double
    var m12:Double
    var m21:Double
    var m22:Double
    
    // MARK: Init
    init(){
        m11 = 0
        m12 = 0
        m21 = 0
        m22 = 0
    }
    init(m11:Double, andM12 m12:Double, andM21 m21:Double, andM22 m22:Double){
        self.m11 = m11
        self.m12 = m12
        self.m21 = m21
        self.m22 = m22
    }
    init(p:Vector2D, and q:Vector2D){
        // this is a Column Major matrix
        m11 = p.x
        m12 = p.y
        m21 = q.x
        m22 = q.y
    }
}
