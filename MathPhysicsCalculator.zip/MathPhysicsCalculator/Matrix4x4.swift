//
//  Matrix4x4.swift
//  MathPhysicsCalculator
//
//  Created by Allan Anderson on 2015-Apr-23.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import Foundation

open class Matrix4x4{
    // MARK : Properties
    var m11:Double
    var m12:Double
    var m13:Double
    var m14:Double
    var m21:Double
    var m22:Double
    var m23:Double
    var m24:Double
    var m31:Double
    var m32:Double
    var m33:Double
    var m34:Double
    var m41:Double
    var m42:Double
    var m43:Double
    var m44:Double
    
    // MARK: Init
    init(){
        m11 = 0
        m12 = 0
        m13 = 0
        m14 = 0
        m21 = 0
        m22 = 0
        m23 = 0
        m24 = 0
        m31 = 0
        m32 = 0
        m33 = 0
        m34 = 0
        m41 = 0
        m42 = 0
        m43 = 0
        m44 = 0
    }
    init(m11:Double, andM12 m12:Double, andM13 m13:Double, andM14 m14:Double,
        andM21 m21:Double, andM22 m22:Double, andM23 m23:Double, andM24 m24:Double,
        andM31 m31:Double, andM32 m32:Double, andM33 m33:Double, andM34 m34:Double,
        andM41 m41:Double, andM42 m42:Double, andM43 m43:Double, andM44 m44:Double){
            self.m11 = m11
            self.m12 = m12
            self.m13 = m13
            self.m14 = m14
            self.m21 = m21
            self.m22 = m22
            self.m23 = m23
            self.m24 = m24
            self.m31 = m31
            self.m32 = m32
            self.m33 = m33
            self.m34 = m34
            self.m41 = m41
            self.m42 = m42
            self.m43 = m43
            self.m44 = m44
    }
    init(matrix3x3 m:Matrix3x3){
        m11 = m.m11
        m12 = m.m12
        m13 = m.m13
        m14 = 0
        m21 = m.m21
        m22 = m.m22
        m23 = m.m23
        m24 = 0
        m31 = m.m31
        m32 = m.m32
        m33 = m.m33
        m34 = 0
        m41 = 0
        m42 = 0
        m43 = 0
        m44 = 1
    }

}
