//
//  Force3D.swift
//  MathPhysicsCalculator
//
//  Created by Allan Anderson on 2015-Apr-24.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import Foundation

open class Force3D{
    // MARK: Properties
    var g:Vector3D
    var m:Double
    var appliedForce:Vector3D
    var mu:Double
    
    // MARK: Init
    init(){
        g = Vector3D(x: 0, andY: -9.81, andZ: 0)
        m = 0
        appliedForce = Vector3D()
        mu = 0
    }
    init(gravity:Vector3D, andMass mass:Double, withAppliedForce applied:Vector3D, andMu mu:Double){
        g = gravity
        m = mass
        appliedForce = applied
        self.mu = mu
    }
    // MARK: Private Methods
}
