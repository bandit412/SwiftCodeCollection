//
//  Matrix4x1.swift
//  MathPhysicsCalculator
//
//  Created by Allan Anderson on 2015-Apr-23.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import Foundation

open class Matrix4x1{
    // MARK : Properties
    var m11:Double
    var m21:Double
    var m31:Double
    var m41:Double = 1
    
    // MARK: Init
    init(){
        m11 = 0
        m21 = 0
        m31 = 0
    }
    init(m11:Double, andM21 m21:Double, andM31 m31:Double){
        self.m11 = m11
        self.m21 = m21
        self.m31 = m31
    }
    init(vector3:Vector3D){
        m11 = vector3.x
        m21 = vector3.y
        m31 = vector3.z
    }
    init(vector4:Vector4D){
        m11 = vector4.x
        m21 = vector4.y
        m31 = vector4.z
    }
    init(quat:Quaternion){
        m11 = quat.qW
        m21 = quat.qX
        m31 = quat.qY
        m41 = quat.qZ
    }
}
