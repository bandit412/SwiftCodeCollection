//
//  Vector4D.swift
//  MathPhysicsCalculator
//
//  Created by Allan Anderson on 2015-Apr-23.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import Foundation

open class Vector4D{
    // MARK: Properties
    var x:Double
    var y:Double
    var z:Double
    var w:Double = 1
    var magnitude:Double
    
    // MARK: Init
    init(){
        x = 0
        y = 0
        z = 0
        magnitude = 0
    }
    init(x:Double, andY y:Double, andY z:Double){
        self.x = x
        self.y = y
        self.z = z
        self.magnitude = sqrt(x * x + y * y + z * z)
    }
    init(x:Double, andY y:Double, andZ z:Double, andW w:Double){
        self.x = x
        self.y = y
        self.z = z
        self.w = w
        self.magnitude = sqrt(x * x + y * y + z * z + w * w)
    }
    init(vector3:Vector3D){
        self.x = vector3.x
        self.y = vector3.y
        self.z = vector3.z
        self.magnitude = vector3.magnitude
    }
}
