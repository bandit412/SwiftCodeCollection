//
//  Point3D.swift
//  MathPhysicsCalculator
//
//  Created by Allan Anderson on 2015-Apr-23.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import Foundation

open class Point3D{
    // MARK: Properties
    var x:Double
    var y:Double
    var z:Double
    
    // MARK: Init
    init(){
        x = 0
        y = 0
        z = 0
    }
    init(x:Double, andY y:Double, andZ z:Double){
        self.x = x
        self.y = y
        self.z = z
    }

}
