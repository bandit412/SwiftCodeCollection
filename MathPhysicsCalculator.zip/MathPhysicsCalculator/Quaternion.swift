//
//  Quaternion.swift
//  MathPhysicsCalculator
//
//  Created by Allan Anderson on 2015-Apr-23.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import Foundation

open class Quaternion{
    // MARK: Properties
    var qW:Double
    var qX:Double
    var qY:Double
    var qZ:Double
    
    // MARK: Init
    init(){
        qW = 0
        qX = 0
        qY = 0
        qZ = 0
    }
    init(qW:Double, andX qX:Double, andY qY:Double, andZ qZ:Double){
        self.qW = qW
        self.qX = qX
        self.qY = qY
        self.qZ = qZ
    }
    init(rollDegrees:Double, and pitchDegrees:Double, and yawDegrees:Double){
        qW = 0
        qX = 0
        qY = 0
        qZ = 0
        let values: (c1:Double, c2:Double, c3:Double, s1:Double, s2:Double, s3:Double) = setValues(rollDegrees, andPitch: pitchDegrees, andYaw: yawDegrees)
        // this is z-axis heading version
        qW = values.c1 * values.c2 * values.c3 + values.s1 * values.s2 * values.s3
        qX = values.c1 * values.s2 * values.c3 + values.s1 * values.c2 * values.s3
        qY = values.s1 * values.c2 * values.c3 - values.c1 * values.s2 * values.s3
        qZ = values.c1 * values.c2 * values.s3 - values.s1 * values.s2 * values.c3
        /*
        // this is x-axis heading version
        qW = values.c1 * values.c2 * values.c3 - values.s1 * values.s2 * values.s3
        qX = values.s1 * values.s2 * values.c3 + values.c1 * values.c2 * values.s3
        qY = values.s1 * values.c2 * values.c3 + values.c1 * values.s2 * values.s3
        qZ = values.c1 * values.s2 * values.c3 - values.s1 * values.c2 * values.s3
        */
    }
    
    // MARK: Functions
    func setValues(_ roll:Double, andPitch pitch:Double, andYaw yaw:Double)->(c1:Double, c2:Double, c3:Double, s1:Double, s2:Double, s3:Double){
        let rollR = Calculator.toRadians(roll)
        let pitchR = Calculator.toRadians(pitch)
        let yawR = Calculator.toRadians(yaw)
        let c1 = cos(yawR / 2)
        let c2 = cos(pitchR / 2)
        let c3 = cos(rollR / 2)
        let s1 = sin(yawR / 2)
        let s2 = sin(pitchR / 2)
        let s3 = sin(rollR / 2)
        return (c1, c2, c3, s1, s2, s3)
    }
}
