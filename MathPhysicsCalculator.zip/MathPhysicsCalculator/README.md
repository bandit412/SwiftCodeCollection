# MathPhysicsCalculator
iPad Calculator for PHYS1521

This is a private project. I am converting a Windows Form application written in C# to Swift.

## Project Update - November 8, 2016
I recently upgraded to the latest version of Xcode. As a result this project has been updated to the latest version of Swift, which is Swift 3.

## Project Update - September 24, 2016
This project is not being actively developed. I am needing to make a decision as to whether to proceed with this project or focus on the OS X version of the calculator.
