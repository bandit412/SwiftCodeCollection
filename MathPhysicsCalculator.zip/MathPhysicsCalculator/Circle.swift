//
//  Circle.swift
//  MathPhysicsCalculator
//
//  Created by Allan Anderson on 2016-Mar-30.
//  Copyright © 2016 Allan Anderson. All rights reserved.
//

import Foundation

open class Circle{
    // MARK: Properties
    var h:Double
    var k:Double
    var r:Double
    // MARK: init
    init(){
        h = 0
        k = 0
        r = 0
    }
    init(h:Double, k:Double, r:Double){
        self.h = h
        self.k = k
        self.r = r
    }
}
