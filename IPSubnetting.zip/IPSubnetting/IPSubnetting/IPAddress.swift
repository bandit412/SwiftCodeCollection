//
//  IPAddress.swift
//  IPSubnetting
//
//  Created by Allan Anderson on 2015-Jan-13.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import Foundation
class IPAddress {
    var octet1:Int
    var octet2:Int
    var octet3:Int
    var octet4:Int
    var cidr: Int
    var ipString:String = ""
    var maskString:String = ""
    var subnetMask:String = ""
    
    init(){
        octet1 = 1
        octet2 = 0
        octet3 = 0
        octet4 = 0
        cidr = 1
        ipString = createIPString()
        maskString = createMaskString()
        subnetMask = createSubnetMask()
    }
    
    // MARK: - CreateIPString
    func createIPString()->String{
        return padZeros(decimalToBinary(octet1), numZeros: 8) + padZeros(decimalToBinary(octet2), numZeros: 8) + padZeros(decimalToBinary(octet3), numZeros: 8) + padZeros(decimalToBinary(octet4), numZeros: 8)
    }
    
    // MARK: - CreateIPString
    func createMaskString()->String{
        var mask = ""
        for var i = 1; i <= cidr; i = i + 1{
            mask = mask + "1"
        }
        mask = padRight(mask, numZeros: 32)
        return mask
    }
    
    // MARK: - CreateSubnetMask
    func createSubnetMask()->String{
        var subnet = ""
        var mask = maskString
        var octet:String
        var base10:Int
        while count(mask) > 0{
            octet = mask.substringToIndex(advance(mask.startIndex, 8))
            base10 = binaryToDecimal(octet)
            subnet = subnet + "\(padZeros(String(base10), numZeros: 3))."
            mask = mask.substringFromIndex(advance(mask.startIndex, 8))
        }
        subnet = subnet.substringToIndex(advance(subnet.startIndex,count(subnet) - 1))
        return subnet
    }
    
    // MARK: - CreateDottedIP
    func createDottedIP(var binaryString:String)->String{
        var subnet = ""
        var octet:String
        var base10:Int
        while count(binaryString) > 0{
            octet = binaryString.substringToIndex(advance(binaryString.startIndex, 8))
            base10 = binaryToDecimal(octet)
            subnet = subnet + "\(padZeros(String(base10), numZeros: 3))."
            binaryString = binaryString.substringFromIndex(advance(binaryString.startIndex, 8))
        }
        subnet = subnet.substringToIndex(advance(subnet.startIndex,count(subnet) - 1))
        return subnet
    }
    
    // MARK: - NetworkID
    func networkID()->String{
        return bitwiseAND(ipString, andMask: maskString)
    }
    
    // MARK: - BroadcastID
    func broadcastID()->String{
        return bitwiseOR(ipString, andMask: invertBits(maskString))
    }
    
    // MARK: - NetworkHosts
    func networkHosts()->Int{
        let ones = 32 - cidr
        return Int(pow(2, Double(ones)) - 2)
    }
    
    // MARK: - TotalSubnets
    func totalSubnets()->Int{
        var lastOctets = ipString.substringFromIndex(advance(ipString.startIndex, 16))
        let ones = countOnes(lastOctets)
        return Int(pow(2, Double(ones)))
    }
    
    // MARK: - NetworkClass
    func networkClass()->String{
        var netClass:String
        if octet1 <= 126{
            netClass = "A"
        } else if octet1 == 127 || octet1 == 0{
            netClass = "Loopback & diagnostics"
        } else  if octet1 <= 191{
            netClass = "B"
        } else if octet1 <= 223{
            netClass = "C"
        } else if octet1 <= 239 {
            netClass = "D"
        } else {
            netClass = "E"
        }
        // now check for PRIVATE networks
        if (octet1 == 10) || (octet1 == 172 && octet2 >= 16 && octet2 <= 31) || (octet1 == 192 && octet2 == 168) {
            netClass += ": Private"
        }
        return netClass
    }
    
}
