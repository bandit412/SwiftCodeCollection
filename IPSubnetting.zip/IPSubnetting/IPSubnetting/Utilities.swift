//
//  Utilities.swift
//  IPSubnetting
//
//  Created by Allan Anderson on 2015-Jan-13.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import Foundation

// MARK: - DecimalToBinary
func decimalToBinary(var base10:Int)->String{
    var remainder = 0
    var binary:String = ""
    while (base10 != 0){
        remainder = base10 % 2
        base10 = base10 / 2
        binary = "\(remainder)" + binary
    }
    return binary
}

// MARK: - DecimalToHex
func decimalToHex(var base10:Int)->String{
    var remainder = 0
    var remainderString = ""
    var hex = ""
    while (base10 != 0){
        remainder = base10 % 16
        switch(remainder){
        case 10:
            remainderString = "A"
        case 11:
            remainderString = "B"
        case 12:
            remainderString = "C"
        case 13:
            remainderString = "D"
        case 14:
            remainderString = "E"
        case 15:
            remainderString = "F"
        default:
            remainderString = "\(remainder)"
        }
        hex = remainderString + hex
        base10 /= 16
    }
    return hex
}
// MARK: - BinarytoDecimal
func binaryToDecimal(binary:String)->Int{
    var digit:Int
    var subTotal = 0
    for letter in binary{
        //println(letter)
        digit = String(letter).toInt()!
        subTotal = subTotal * 2 + digit
    }
    return subTotal
}
// MARK: - HexToDecimal
func hexToDecimal(hex:String)->Int{
    var digitString:String
    var digit:Int
    var subTotal = 0
    for letter in hex{
        digitString = String(letter)
        switch(digitString){
        case "A":
            digit = 10
        case "B":
            digit = 11
        case "C":
            digit = 12
        case "D":
            digit = 13
        case "E":
            digit = 14
        case "F":
            digit = 15
        default:
            digit = digitString.toInt()!
        }
        subTotal = subTotal * 16 + digit
    }
    return subTotal
}

// MARK: - PadZeros
func padZeros(var binString:String, numZeros size:Int)->String{
    while(count(binString) < size){
        binString = "0" + binString
    }
    return binString
}
func padRight(var binString:String, numZeros size:Int)->String{
    while(count(binString) < size){
        binString = binString + "0"
    }
    return binString
}
// MARK: - PadSpaces

// MARK: - InvertBits
func invertBits(binString:String)->String{
    var inverted:String = ""
    for digit in binString{
        if (digit == "0"){
            inverted = inverted + "1"
        } else {
            inverted = inverted + "0"
        }
    }
    return inverted
}
// MARK: - BitwiseAnd
func bitwiseAND(bin1:String, andMask bin2:String)->String{
    var andString = ""
    let binDigits1 = Array(bin1)
    let binDigits2 = Array(bin2)
    for var i = 0; i < count(bin1); i = i + 1{
        if binDigits1[i] == binDigits2[i]{
            andString = andString + "\(binDigits1[i])"
        } else {
            andString = andString + "0"
        }
    }
    return andString
}
// MARK: - BitwiseOr
func bitwiseOR(bin1:String, andMask bin2:String)->String{
    var orString = ""
    let binDigits1 = Array(bin1)
    let binDigits2 = Array(bin2)
    for var i = 0; i < count(bin1); i = i + 1{
        if binDigits1[i] == "1" || binDigits2[i] == "1"{
            orString = orString + "1"
        } else {
            orString = orString + "0"
        }
    }
    return orString
}

// MARK: - CountOnes
func countOnes(binString:String)->Int{
    var count = 0
    for digit in binString{
        if digit == "1"{
            count = count + 1
        }
    }
    return count
}

// MARK: - FormatBinaryString
func formatBinaryString(var binString:String)->String{
    var binary:String = ""
    var octet:String
    while count(binString) > 0{
        octet = binString.substringToIndex(advance(binString.startIndex, 8))
        binary = binary + octet + " "
        binString = binString.substringFromIndex(advance(binString.startIndex, 8))
    }
    binary = binary.substringToIndex(advance(binary.startIndex, count(binary) - 1))
    return binary
}

