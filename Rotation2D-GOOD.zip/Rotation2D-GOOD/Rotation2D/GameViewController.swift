//
//  GameViewController.swift
//  Rotation2D
//
//  Created by Allan Anderson on 2015-Feb-27.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import UIKit
import SpriteKit

class GameViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // create the scene
        let scene = GameScene(size: view.bounds.size)
        scene.scaleMode = .AspectFill
        // create the SKView
        let skView = view as! SKView
        skView.showsFPS = true
        skView.showsNodeCount = true
        skView.ignoresSiblingOrder = false
        skView.showsDrawCount = true
        skView.presentScene(scene)
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Release any cached data, images, etc that aren't in use.
    }

}
