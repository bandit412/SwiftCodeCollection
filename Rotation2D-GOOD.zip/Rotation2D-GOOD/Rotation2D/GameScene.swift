//
//  GameScene.swift
//  Rotation2D
//
//  Created by Allan Anderson on 2015-Feb-27.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import SpriteKit

class GameScene: SKScene , SKPhysicsContactDelegate{
    let origin = CGPointMake(10.0, 10.0)
    let housePosition = CGPointMake(120.0, 80.0)
    var rPoint:SKShapeNode! = nil
    var graphPaper: SKSpriteNode! = nil
    var pointNode: SKShapeNode! = nil
    var house :SKSpriteNode! = nil
    override init(size: CGSize) {
        super.init(size: size)
    }
    
    override func didMoveToView(view: SKView) {
        self.backgroundColor = SKColor.whiteColor()
        self.physicsWorld.gravity = CGVectorMake(0.0, 0.0)
        self.physicsWorld.contactDelegate = self
        createSceneContents()
    }
    
    //MARK: - Create Scene Contents
    func createSceneContents(){
        
        graphPaper = SKSpriteNode(imageNamed: "2D_GraphPaper")
        graphPaper.position = CGPoint(x: self.size.width / 2, y: self.size.height / 2)
        graphPaper.size = CGSize(width: self.size.width, height: self.size.height)
        graphPaper.name = "graphPaper"
        self.addChild(graphPaper)
        
        rPoint = createRotationPoint()
        rPoint.position = origin
        graphPaper.addChild(rPoint)
        pointNode = createPointNode()
        pointNode.position = rPoint.position
        graphPaper.addChild(pointNode)
        
        house = House(sceneSize: self.frame.size)
        house.position = housePosition
        pointNode.addChild(house)
        createLabels()
        rotateHouse()
    }
    
    // MARK: - Create shapes & labels
    func createLabels(){
        // constants related to displaying text
        let edgeDistance = CGFloat(20.0)
        //let labelSpacing = CGFloat(5.0)
        let fontSize = CGFloat(28.0)
        let infoLabel = SKLabelNode(fontNamed: "Chalkduster")
        infoLabel.text = "2D Rotation Demo"
        infoLabel.fontSize = fontSize
        infoLabel.fontColor = SKColor.blackColor()
        infoLabel.horizontalAlignmentMode = .Left
        let y = self.frame.height - infoLabel.fontSize - edgeDistance
        infoLabel.position = CGPointMake(edgeDistance, y)
        self.addChild(infoLabel)
        let rpLabel = SKLabelNode(fontNamed: "Courier")
        rpLabel.fontColor = SKColor.blueColor()
        rpLabel.fontSize = CGFloat(22.0)
        rpLabel.horizontalAlignmentMode = .Left
        rpLabel.text = "Rotation Point: (\(rPoint.position.x - 10), \(rPoint.position.y - 10))"
        rpLabel.position = CGPointMake(edgeDistance, infoLabel.position.y - infoLabel.fontSize)
        rpLabel.name = "rpLabel"
        self.addChild(rpLabel)
    }

    func createRotationPoint() -> SKShapeNode{
        let pointColor = SKColor.blueColor()
        //let alphaValue = 1.0
        let radius = CGFloat(5.0)
        let rotationPoint = SKShapeNode(circleOfRadius: radius)
        rotationPoint.fillColor = pointColor
        rotationPoint.lineWidth = 0.0
        rotationPoint.position = CGPoint(x: self.size.width / 2 + radius * 2, y: self.size.height / 2 + radius * 2)
        rotationPoint.name = "RotationPoint"
        return rotationPoint
    }
    
    func createPointNode() -> SKShapeNode{
        let point = SKShapeNode(circleOfRadius: 0.0)
        point.name = "pointNode"
        point.fillColor = SKColor.clearColor()
        return point
    }
    
    // MARK: - Methods & Actions
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        /* Called when a touch begins */
        
        for touch: AnyObject in touches {
            let location = touch.locationInNode(self)
            // get touch point
            let x = location.x - graphPaper.position.x
            let y = location.y - graphPaper.position.y
            // remove house from parent node
            house.removeFromParent()
            // get house point
            //var hp = house.position
            // calculate deltas
            let deltaRPx = x - origin.x
            let deltaRPy = y - origin.y
            // set new rPoint position
            rPoint.position = CGPointMake(x, y)
            // reposition roation point
            pointNode.position = location
            // add house to rotation point node
            pointNode.addChild(house)
            // set house point
            house.position = CGPointMake(housePosition.x - deltaRPx, housePosition.y - deltaRPy)
            let move = SKAction.moveTo(CGPointMake(x, y), duration: 0.0)
            rPoint.runAction(move)
            pointNode.runAction(move)
            rotateHouse()
        }
    }
   
    override func update(currentTime: CFTimeInterval) {
        /* Called before each frame is rendered */
        let label = childNodeWithName("rpLabel") as! SKLabelNode
        label.text = "Rotation Point: (\(rPoint.position.x - 10), \(rPoint.position.y - 10))"
    }
    
    func rotateHouse(){
        let rotateAction = SKAction.rotateByAngle(CGFloat(M_PI) * 2, duration: 2.0)
        pointNode.runAction(rotateAction)
    }
    
    // not called but required if subclass defines an init()
    required init?(coder aDecoder: NSCoder){
        fatalError("init(coder:) has not been implemented")
    }
}
