//
//  House.swift
//  Rotation2D
//
//  Created by Allan Anderson on 2015-Mar-06.
//  Copyright (c) 2015 Allan Anderson. All rights reserved.
//

import UIKit
import SpriteKit

let height:CGFloat = 75.0
let width:CGFloat = 77.0

class House: SKSpriteNode {
    init(sceneSize:CGSize){
        super.init(texture: SKTexture(imageNamed: "house-small"), color:UIColor.clearColor(), size: CGSizeMake(width, height))
        self.physicsBody = SKPhysicsBody(texture: self.texture!, size: self.size)
        self.physicsBody?.friction = 0.0
        self.physicsBody?.angularDamping = 0.0
        self.physicsBody?.allowsRotation = true
        self.anchorPoint = CGPoint(x: 0.0, y: 0.0)
        self.alpha = CGFloat(0.8)
        self.name = "house"
    }
    
    // not called but required if subclass defines an init()
    required init?(coder aDecoder: NSCoder){
        fatalError("init(coder:) has not been implemented")
    }
}
